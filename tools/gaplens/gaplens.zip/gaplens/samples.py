"""Ready-made example data sets with a known truth, for trying the tool and for the tests.

    s = sample("rainfall_network")
    s["df"]         table with a date index (gaps included)
    s["settings"]   what to pass to build_task: target, variable, driver, precip, product, latitude ...
    s["truth"]      the complete target series (never shown to a method)
    s["gaugings"], s["stations"]  optional extra tables

Every example is synthetic. The generators are in gaplens.synth and the gap recipes in gaplens.gaps.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import gaps, synth
from .context import gauge_precip

NAMES = {
    "rainfall_network": "Daily rainfall at six stations; the target has short runs and two long blocks, and a gridded product is attached",
    "streamflow_gauges": "Daily discharge at four gauges; the target has short runs, long blocks and gaps next to floods; areal rainfall is attached",
    "temperature_network": "Daily mean temperature at five stations with different elevations",
    "tide_hourly": "Hourly tide gauge record for one year with a 12-day and a 40-day outage and river discharge as a covariate",
    "groundwater_logger": "Daily groundwater head with logger failures; rainfall is attached",
    "sediment_samples": "Weekly suspended-sediment samples with continuous discharge and turbidity",
    "rating_curve": "Daily discharge from stage through a changing rating, with gaugings and long outage",
}


def _light(truth: pd.DataFrame, seed: int, frac: float = 0.01) -> pd.DataFrame:
    return gaps.simulate(truth, [("G2", {"frac": frac, "mean_len": 3})], seed=seed).observed


def sample(name: str, seed: int = 1) -> dict:
    b = synth.build_basin(seed=seed)
    out = dict(name=name, note=NAMES.get(name, ""), gaugings=None, stations=None)
    if name == "rainfall_network":
        truth = b["rainfall"].truth
        tgt = "R01"
        obs = _light(truth.drop(columns=[tgt]), seed + 1)
        t = gaps.simulate(truth[[tgt]], [("G2", {"frac": 0.04, "mean_len": 3}), ("G3", {"lengths": [45, 120]})], seed=seed + 2).observed[tgt]
        prod = synth.rain_product(truth, tgt, seed=seed + 11)
        df = pd.concat([t, obs, prod], axis=1)
        st = b["rainfall"].extras["stations"][["x_km", "y_km"]].copy()
        st.index.name = "station"
        out.update(df=df, truth=truth[tgt], stations=st, settings=dict(target=tgt, variable="rainfall", product=[prod.name]))
    elif name == "temperature_network":
        truth = b["temperature"].truth
        tgt = "T02"
        obs = _light(truth.drop(columns=[tgt]), seed + 1)
        t = gaps.simulate(truth[[tgt]], [("G2", {"frac": 0.03, "mean_len": 4}), ("G3", {"lengths": [60]})], seed=seed + 2).observed[tgt]
        st = b["temperature"].extras["stations"][["elevation_m"]].copy()
        st.index.name = "station"
        out.update(df=pd.concat([t, obs], axis=1), truth=truth[tgt], stations=st, settings=dict(target=tgt, variable="temperature"))
    elif name == "streamflow_gauges":
        truth = b["streamflow"].truth
        tgt = "Q02"
        obs = _light(truth.drop(columns=[tgt]), seed + 1)
        t = gaps.simulate(truth[[tgt]], [("G2", {"frac": 0.02}), ("G3", {"lengths": [30, 120]}), ("G10", {"frac": 0.03})], seed=seed + 2).observed[tgt]
        p = gauge_precip(b, tgt)
        out.update(df=pd.concat([t, obs, p], axis=1), truth=truth[tgt], settings=dict(target=tgt, variable="streamflow", precip=p.name))
    elif name == "tide_hourly":
        truth = b["tide"].truth[["level_m"]]
        tgt = "level_m"
        q = b["streamflow"].truth["Q04"]
        qh = q.reindex(q.index.union(truth.index)).interpolate("time").reindex(truth.index).ffill().bfill().rename("river_q")
        t = gaps.simulate(truth, [("G2", {"frac": 0.02, "mean_len": 5}), ("G3", {"lengths": [24 * 12, 24 * 40]})], seed=seed + 2).observed[tgt]
        out.update(df=pd.concat([t, qh], axis=1), truth=truth[tgt], settings=dict(target=tgt, variable="tide", driver="river_q", latitude=22.0))
    elif name == "groundwater_logger":
        truth = b["groundwater"].truth[["head_m"]]
        rain = b["rainfall"].truth.mean(axis=1).reindex(truth.index).rename("rain_areal")
        t = gaps.simulate(truth, [("G2", {"frac": 0.01}), ("G3", {"lengths": [60, 180]})], seed=seed + 2).observed["head_m"]
        out.update(df=pd.concat([t, rain], axis=1), truth=truth["head_m"], settings=dict(target="head_m", variable="groundwater", driver="rain_areal", precip="rain_areal"))
    elif name == "sediment_samples":
        truth = b["sediment"].truth
        t = gaps.simulate(truth[["concentration_mgl"]], [("G15", {"schedule": "weekly", "columns": ["concentration_mgl"]})], seed=seed + 2).observed["concentration_mgl"]
        df = pd.concat([t, truth[["discharge_m3s", "turbidity_ntu"]]], axis=1)
        out.update(df=df, truth=truth["concentration_mgl"], settings=dict(target="concentration_mgl", variable="sediment", driver="discharge_m3s", surrogate="turbidity_ntu"))
    elif name == "rating_curve":
        truth = b["rating"].truth
        t = gaps.simulate(truth[["discharge_m3s"]], [("G3", {"lengths": [90, 200]}), ("G2", {"frac": 0.01})], seed=seed + 2).observed["discharge_m3s"]
        g = b["rating"].extras["gaugings"][["date", "stage_m", "discharge_m3s", "u_rel"]].copy()
        out.update(df=pd.concat([t, truth[["stage_m"]]], axis=1), truth=truth["discharge_m3s"], gaugings=g, settings=dict(target="discharge_m3s", variable="streamflow", driver="stage_m"))
    else:
        raise KeyError(f"unknown sample {name!r}; choose from {sorted(NAMES)}")
    out["df"].index.name = "date"
    return out
