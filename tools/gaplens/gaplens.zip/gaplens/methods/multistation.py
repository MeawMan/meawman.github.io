"""Multi-station and multivariate methods (catalog 3.3).

Donors are the columns of `others`. Only donors that overlap the target and correlate with it are used.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import optimize

from .base import calendar_features, register, usable_donors


# ---------------------------------------------------------------------------------- shared tools


def donor_stats(series: pd.Series, others: pd.DataFrame, donors: list) -> pd.DataFrame:
    rows = []
    for c in donors:
        pair = pd.concat([series, others[c]], axis=1).dropna()
        rows.append(
            dict(donor=c, n=len(pair), r=float(pair.iloc[:, 0].corr(pair.iloc[:, 1])), mean_y=float(pair.iloc[:, 0].mean()), mean_x=float(pair.iloc[:, 1].mean()),
                 sd_y=float(pair.iloc[:, 0].std()), sd_x=float(pair.iloc[:, 1].std()))
        )
    return pd.DataFrame(rows).set_index("donor")


def distances(series_name, donors, ctx, st: pd.DataFrame | None = None) -> pd.Series:
    """Euclidean distance (km) from the target to each donor; if coordinates are missing, a correlation distance."""
    if ctx.coords is not None and {"x_km", "y_km"} <= set(ctx.coords.columns) and series_name in ctx.coords.index and all(d in ctx.coords.index for d in donors):
        t = ctx.coords.loc[series_name, ["x_km", "y_km"]].to_numpy(float)
        d = {c: float(np.hypot(*(ctx.coords.loc[c, ["x_km", "y_km"]].to_numpy(float) - t))) for c in donors}
        return pd.Series(d)
    if st is None:
        raise ValueError("need coordinates or donor statistics")
    return pd.Series({c: float(np.sqrt(2.0 * max(1.0 - st.loc[c, "r"], 1e-6))) * 100.0 for c in donors})


def _donors(ctx, series, others, min_overlap=30, min_corr=0.2):
    """Station donors only: products listed in ctx.meta['product'] are excluded."""
    if others is None:
        return []
    return usable_donors(series, others, min_overlap=min_overlap, min_corr=min_corr, exclude=ctx.meta.get("product", []))


def _stations(ctx, series, others, min_overlap=30, min_corr=0.2):
    """Neighbouring stations of the same quantity: products and covariates (driver, surrogate, rainfall forcing, PET) are
    excluded. Used by the methods that copy or average neighbours, where a stage or a rainfall series is not a stand-in."""
    if others is None:
        return []
    skip = list(ctx.meta.get("product", [])) + list(ctx.meta.get("covariates", []))
    return usable_donors(series, others, min_overlap=min_overlap, min_corr=min_corr, exclude=skip)


# ---------------------------------------------------------------------------------- simple donor methods


def _scaled(series, others, st, c, adjust):
    """Donor c put on the target's level: ratio of the means (non-negative quantities such as flow or rain, where a
    bigger catchment or wetter gauge differs by a factor) or difference of the means (levels, temperature)."""
    x = others[c]
    if adjust == "none":
        return x
    if adjust == "auto":
        adjust = "ratio" if (series.min() >= 0 and x.min() >= 0) else "diff"
    if adjust == "ratio":
        mx = st.loc[c, "mean_x"]
        return x * (st.loc[c, "mean_y"] / mx) if mx and np.isfinite(mx) and mx != 0 else x
    return x + (st.loc[c, "mean_y"] - st.loc[c, "mean_x"])


@register("nearest_neighbor", "Nearest-neighbour substitution (scaled to the target's mean)", "multistation", needs=("series", "stations"), best_for=("G1", "G2", "G3", "G6"), library="numpy", section="3.3", transform="none",
          limits="the donor's values are scaled by the ratio (or difference) of the means; timing and shape are the donor's")
def nearest_neighbor(series, others, ctx, min_corr=0.2, adjust="auto"):
    donors = _stations(ctx, series, others, min_corr=min_corr)
    if not donors:
        return series
    st = donor_stats(series, others, donors)
    d = distances(ctx.target, donors, ctx, st).sort_values()
    out = series.copy()
    for c in d.index:
        out = out.fillna(_scaled(series, others, st, c, adjust))
    return out


@register("idw", "Inverse-distance weighting (donors scaled to the target's mean)", "multistation", needs=("series", "stations"), best_for=("G1", "G2", "G3"), library="numpy", section="3.3", transform="none")
def idw(series, others, ctx, power=2.0, adjust="auto", max_donors=6):
    donors = _stations(ctx, series, others)
    if not donors:
        return series
    st = donor_stats(series, others, donors)
    d = distances(ctx.target, donors, ctx, st).sort_values().iloc[:max_donors]
    X = others[list(d.index)].copy()
    if adjust == "auto":
        adjust = "ratio" if (series.min() >= 0 and float(np.nanmin(X.to_numpy(float))) >= 0) else "diff"
    if adjust == "ratio":
        X = X * (st.loc[d.index, "mean_y"] / st.loc[d.index, "mean_x"].replace(0, np.nan)).fillna(1.0)
    elif adjust == "diff":
        X = X + (st.loc[d.index, "mean_y"] - st.loc[d.index, "mean_x"])
    w = 1.0 / np.maximum(d.to_numpy(), 1e-6) ** power
    V = X.to_numpy(float)
    W = np.where(np.isfinite(V), w[None, :], 0.0)
    num = np.nansum(np.where(np.isfinite(V), V, 0.0) * W, axis=1)
    den = W.sum(axis=1)
    est = pd.Series(np.where(den > 0, num / np.where(den > 0, den, 1.0), np.nan), index=series.index)
    return series.where(series.notna(), est)


@register("normal_ratio", "Normal-ratio method", "multistation", needs=("series", "stations"), best_for=("G1", "G2", "G3"), library="numpy", section="3.3", transform="none")
def normal_ratio(series, others, ctx, k=5, weight="equal"):
    donors = _stations(ctx, series, others)
    if not donors:
        return series
    st = donor_stats(series, others, donors)
    pick = list(st.sort_values("r", ascending=False).index[:k])
    mu_y = float(series.mean())
    ratios = pd.Series({c: mu_y / max(float(others[c].mean()), 1e-9) for c in pick})
    V = others[pick].to_numpy(float) * ratios.to_numpy()[None, :]
    w = np.ones(len(pick)) if weight == "equal" else np.maximum(st.loc[pick, "r"].to_numpy() ** 2, 1e-6)
    W = np.where(np.isfinite(V), w[None, :], 0.0)
    num = np.nansum(np.where(np.isfinite(V), V, 0.0) * W, axis=1)
    den = W.sum(axis=1)
    est = pd.Series(np.where(den > 0, num / np.where(den > 0, den, 1.0), np.nan), index=series.index)
    return series.where(series.notna(), est)


@register("linear_regression", "Linear regression on one or several donors", "multistation", needs=("series", "neighbors"), best_for=("G3", "G5", "G6"), library="numpy", section="3.3")
def linear_regression(series, others, ctx, max_donors=3, residual="none", min_pairs=30):
    donors = _donors(ctx, series, others)
    if not donors:
        return series
    st = donor_stats(series, others, donors)
    order = list(st.sort_values("r", ascending=False).index)
    y = series.to_numpy(float)
    V = others[order].to_numpy(float)
    miss = ~np.isfinite(y)
    est = np.full(len(y), np.nan)
    rng = ctx.rng(11)
    cache = {}
    for i in np.flatnonzero(miss):
        avail = tuple(j for j in range(len(order)) if np.isfinite(V[i, j]))[:max_donors]
        if not avail:
            continue
        if avail not in cache:
            ok = np.isfinite(y) & np.all(np.isfinite(V[:, avail]), axis=0 if False else 1)
            sel = avail
            while ok.sum() < min_pairs and len(sel) > 1:
                sel = sel[:-1]
                ok = np.isfinite(y) & np.all(np.isfinite(V[:, sel]), axis=1)
            if ok.sum() < min_pairs:
                cache[avail] = None
            else:
                A = np.column_stack([np.ones(ok.sum()), V[ok][:, sel]])
                beta, *_ = np.linalg.lstsq(A, y[ok], rcond=None)
                resid = y[ok] - A @ beta
                cache[avail] = (sel, beta, resid)
        c = cache[avail]
        if c is None:
            continue
        sel, beta, resid = c
        if not all(np.isfinite(V[i, j]) for j in sel):
            continue
        val = beta[0] + float(np.dot(beta[1:], V[i, list(sel)]))
        if residual == "resample":
            val += float(rng.choice(resid))
        est[i] = val
    return series.where(series.notna(), pd.Series(est, index=series.index))


@register("linear_regression_resid", "Linear regression with resampled residuals", "multistation", needs=("series", "neighbors"), best_for=("G3", "G5", "G6"), library="numpy", section="3.3")
def linear_regression_resid(series, others, ctx, max_donors=3):
    return linear_regression(series, others, ctx, max_donors=max_donors, residual="resample")


# ---------------------------------------------------------------------------------- kriging


def _exp_variogram(h, c0, a):
    return c0 + (1.0 - c0) * (1.0 - np.exp(-h / np.maximum(a, 1e-6)))


@register("kriging", "Ordinary kriging of standardised values", "multistation", needs=("series", "stations>=2", "coords"), best_for=("G3", "G8"), library="numpy", section="3.3")
def kriging(series, others, ctx, min_overlap=30):
    donors = _stations(ctx, series, others, min_overlap=min_overlap, min_corr=0.0)
    if len(donors) < 2:
        return series
    names = [ctx.target] + donors
    frame = pd.concat([series.rename(ctx.target), others[donors]], axis=1)
    mu, sd = frame.mean(), frame.std().replace(0, 1.0)
    Z = ((frame - mu) / sd)
    xy = ctx.coords.loc[names, ["x_km", "y_km"]].to_numpy(float)
    D = np.sqrt(((xy[:, None, :] - xy[None, :, :]) ** 2).sum(-1))
    R = Z.corr(min_periods=min_overlap).to_numpy()
    iu = np.triu_indices(len(names), 1)
    h, g = D[iu], 1.0 - R[iu]
    ok = np.isfinite(g)
    try:
        popt, _ = optimize.curve_fit(_exp_variogram, h[ok], g[ok], p0=[0.1, max(np.median(h[ok]), 1.0)], bounds=([0.0, 1.0], [0.9, 1e4]))
    except Exception:
        popt = [0.1, max(float(np.median(h)), 1.0)]
    c0, a = popt
    gam = lambda d: _exp_variogram(d, c0, a)  # noqa: E731
    Zv = Z.iloc[:, 1:].to_numpy(float)
    Dd = D[1:, 1:]
    d0 = D[0, 1:]
    est = np.full(len(series), np.nan)
    cache = {}
    for i in np.flatnonzero(series.isna().to_numpy()):
        avail = tuple(np.flatnonzero(np.isfinite(Zv[i])))
        if not avail:
            continue
        if avail not in cache:
            idx = list(avail)
            k = len(idx)
            G = gam(Dd[np.ix_(idx, idx)])
            np.fill_diagonal(G, 0.0)
            A = np.ones((k + 1, k + 1))
            A[:k, :k] = G
            A[k, k] = 0.0
            b = np.append(gam(d0[idx]), 1.0)
            try:
                w = np.linalg.solve(A + 1e-9 * np.eye(k + 1), b)[:k]
            except np.linalg.LinAlgError:
                w = np.ones(k) / k
            cache[avail] = (idx, w)
        idx, w = cache[avail]
        est[i] = float(np.dot(w, Zv[i, idx]))
    out = est * sd.iloc[0] + mu.iloc[0]
    return series.where(series.notna(), pd.Series(out, index=series.index))


# ---------------------------------------------------------------------------------- multivariate normal EM and relatives


def em_mvn(X: np.ndarray, max_iter=100, tol=1e-5, ridge=1e-6):
    """EM for a multivariate normal with missing values. Returns (mu, Sigma, X_imputed, n_iter)."""
    X = np.asarray(X, float)
    n, p = X.shape
    obs = np.isfinite(X)
    mu = np.nanmean(X, axis=0)
    mu = np.where(np.isfinite(mu), mu, 0.0)
    Sigma = np.diag(np.nan_to_num(np.nanvar(X, axis=0), nan=1.0) + ridge)
    patterns = {}
    for i in range(n):
        patterns.setdefault(obs[i].tobytes(), []).append(i)
    pat = [(np.frombuffer(k, dtype=bool), np.array(v)) for k, v in patterns.items()]
    Xf = np.where(obs, X, mu)
    it = 0
    for it in range(1, max_iter + 1):
        s1 = np.zeros(p)
        s2 = np.zeros((p, p))
        for o, rows in pat:
            m = ~o
            Xr = X[rows]
            filled = np.empty((len(rows), p))
            C = np.zeros((p, p))
            if m.any() and o.any():
                Soo = Sigma[np.ix_(o, o)]
                Smo = Sigma[np.ix_(m, o)]
                K = np.linalg.solve(Soo, Smo.T).T  # Smo Soo^-1
                filled[:, o] = Xr[:, o]
                filled[:, m] = mu[m] + (Xr[:, o] - mu[o]) @ K.T
                C[np.ix_(m, m)] = Sigma[np.ix_(m, m)] - K @ Smo.T
            elif m.any():
                filled[:, :] = mu
                C = Sigma.copy()
            else:
                filled[:, :] = Xr
            s1 += filled.sum(axis=0)
            s2 += filled.T @ filled + len(rows) * C
            Xf[rows] = filled
        mu_new = s1 / n
        Sigma_new = s2 / n - np.outer(mu_new, mu_new) + ridge * np.eye(p)
        delta = max(np.max(np.abs(mu_new - mu)), np.max(np.abs(Sigma_new - Sigma)))
        mu, Sigma = mu_new, Sigma_new
        if delta < tol * max(1.0, np.max(np.abs(Sigma))):
            break
    return mu, Sigma, Xf, it


def _matrix(series, others, donors, ctx):
    return pd.concat([series.rename("__target__"), others[donors]], axis=1)


@register("em_mvn", "Expectation-maximisation (multivariate normal)", "multistation", needs=("series", "neighbors"), best_for=("G1", "G2", "G3", "G6"), library="numpy", section="3.3", cost="medium")
def em_mvn_fill(series, others, ctx, max_donors=6, max_iter=60):
    donors = _donors(ctx, series, others)[:max_donors]
    if not donors:
        return series
    M = _matrix(series, others, donors, ctx)
    mu, Sigma, Xf, _ = em_mvn(M.to_numpy(float), max_iter=max_iter)
    return series.where(series.notna(), pd.Series(Xf[:, 0], index=series.index))


@register("pca_iterative", "Iterative PCA (EOF) filling", "multistation", needs=("series", "neighbors"), best_for=("G2", "G3", "G6", "G7"), library="numpy", section="3.3")
def pca_iterative(series, others, ctx, var_frac=0.85, max_iter=200, tol=1e-5, max_donors=10):
    donors = _donors(ctx, series, others, min_corr=0.0)[:max_donors]
    if not donors:
        return series
    M = _matrix(series, others, donors, ctx).to_numpy(float)
    obs = np.isfinite(M)
    mu = np.nanmean(M, axis=0)
    sd = np.where(np.nanstd(M, axis=0) > 0, np.nanstd(M, axis=0), 1.0)
    Z = (M - mu) / sd
    X = np.where(obs, Z, 0.0)
    for _ in range(max_iter):
        U, S, Vt = np.linalg.svd(X, full_matrices=False)
        var = S**2 / np.sum(S**2)
        k = int(min(max(1, len(S) // 2), np.searchsorted(np.cumsum(var), var_frac) + 1))
        R = (U[:, :k] * S[:k]) @ Vt[:k]
        new = np.where(obs, Z, R)
        if np.sqrt(np.mean((new[~obs] - X[~obs]) ** 2)) < tol if (~obs).any() else True:
            X = new
            break
        X = new
    out = X[:, 0] * sd[0] + mu[0]
    return series.where(series.notna(), pd.Series(out, index=series.index))


@register("matrix_completion", "Low-rank matrix completion (soft-impute)", "multistation", needs=("series", "neighbors"), best_for=("G6", "G7"), library="numpy", section="3.3")
def matrix_completion(series, others, ctx, shrink=0.05, max_iter=300, tol=1e-5, max_donors=10):
    donors = _donors(ctx, series, others, min_corr=0.0)[:max_donors]
    if not donors:
        return series
    M = _matrix(series, others, donors, ctx).to_numpy(float)
    obs = np.isfinite(M)
    mu = np.nanmean(M, axis=0)
    sd = np.where(np.nanstd(M, axis=0) > 0, np.nanstd(M, axis=0), 1.0)
    Z = (M - mu) / sd
    X = np.where(obs, Z, 0.0)
    lam = shrink * np.linalg.svd(X, compute_uv=False)[0]
    for _ in range(max_iter):
        U, S, Vt = np.linalg.svd(X, full_matrices=False)
        R = (U * np.maximum(S - lam, 0.0)) @ Vt
        new = np.where(obs, Z, R)
        d = np.sqrt(np.sum((new - X) ** 2) / max(np.sum(X**2), 1e-12))
        X = new
        if d < tol:
            break
    out = X[:, 0] * sd[0] + mu[0]
    return series.where(series.notna(), pd.Series(out, index=series.index))


@register("mice", "Multiple imputation by chained equations", "multistation", needs=("series", "neighbors"), best_for=("G1", "G2", "G3"), library="scikit-learn", section="3.3", uncertainty=True, cost="medium")
def mice(series, others, ctx, m=1, max_iter=10, max_donors=6):
    from sklearn.experimental import enable_iterative_imputer  # noqa: F401
    from sklearn.impute import IterativeImputer
    from sklearn.linear_model import BayesianRidge

    donors = _donors(ctx, series, others, min_corr=0.0)[:max_donors]
    if not donors:
        return series
    cal = calendar_features(series.index)[["doy_sin", "doy_cos"]]
    M = pd.concat([series.rename("__target__"), others[donors], cal], axis=1).to_numpy(float)
    draws = []
    for k in range(max(1, m)):
        imp = IterativeImputer(estimator=BayesianRidge(), max_iter=max_iter, sample_posterior=m > 1, random_state=ctx.seed + k, initial_strategy="mean", skip_complete=True)
        draws.append(imp.fit_transform(M)[:, 0])
    D = np.vstack(draws)
    est = pd.Series(D.mean(axis=0), index=series.index)
    if m > 1:
        return est, pd.Series(np.quantile(D, 0.025, axis=0), index=series.index), pd.Series(np.quantile(D, 0.975, axis=0), index=series.index)
    return est


@register("analog_knn", "Analog days (k-nearest neighbours)", "multistation", needs=("series", "neighbors", "years>=3"), best_for=("G2", "G3", "G4"), library="scikit-learn", section="3.3")
def analog_knn(series, others, ctx, k=5, season_weight=0.5, max_donors=6):
    from sklearn.neighbors import KNeighborsRegressor

    donors = _donors(ctx, series, others)[:max_donors]
    if not donors:
        return series
    X = others[donors].interpolate(limit_direction="both")
    X = (X - X.mean()) / X.std().replace(0, 1.0)
    X = X.fillna(0.0)
    cal = calendar_features(series.index)[["doy_sin", "doy_cos"]] * season_weight
    F = pd.concat([X, cal], axis=1).to_numpy(float)
    ok = series.notna().to_numpy()
    if ok.sum() < k + 2:
        return series
    knn = KNeighborsRegressor(n_neighbors=k, weights="distance")
    knn.fit(F[ok], series.to_numpy(float)[ok])
    est = pd.Series(knn.predict(F), index=series.index)
    return series.where(series.notna(), est)
