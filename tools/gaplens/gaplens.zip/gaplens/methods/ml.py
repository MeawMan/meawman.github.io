"""Machine learning methods (catalog 3.4): forests, boosting, SVR, neural network, with donor and gap-edge features."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import calendar_features, gap_edges, register, usable_donors

import sys as _sys

N_JOBS = 1 if _sys.platform == "emscripten" else -1  # the browser build (Pyodide) has no worker processes


def feature_frame(series, others, ctx, lags=(-1, 0, 1), use_calendar=True, max_donors=6):
    """Donor features (interpolated, with lags) and calendar terms for every step."""
    cols = []
    donors = usable_donors(series, others, min_corr=0.0)[:max_donors] if others is not None else []  # products count as predictors
    for c in donors:
        x = others[c].interpolate(limit_direction="both")
        x = x.fillna(x.mean())
        for L in lags:
            cols.append(x.shift(-L).rename(f"{c}_l{L}"))
    if use_calendar:
        cols.append(calendar_features(series.index))
    F = pd.concat(cols, axis=1) if cols else pd.DataFrame(index=series.index)
    return F.ffill().bfill().fillna(0.0), donors


def _train_features(series, others, ctx, lags, use_edges, use_calendar, max_donors, rng):
    """Training rows are observed steps. Edge features need gaps around them, so they are computed on a copy of the
    series in which each training value is hidden together with a random gap length."""
    F, donors = feature_frame(series, others, ctx, lags, use_calendar, max_donors)
    if not use_edges:
        return F, F, donors
    y = series.to_numpy(float)
    n = len(y)
    obs = np.isfinite(y)
    # edge features for prediction (real gaps)
    e_pred = gap_edges(series)
    # edge features for training: pretend a gap of random length around each observed value
    pos = np.flatnonzero(obs)
    gap_len = rng.geometric(0.08, size=len(pos)).clip(1, 120)  # steps hidden around the training point
    prev_val = np.full(len(pos), np.nan)
    next_val = np.full(len(pos), np.nan)
    d_prev = np.zeros(len(pos))
    d_next = np.zeros(len(pos))
    split = rng.integers(0, 2, size=len(pos))
    left = np.where(split == 0, gap_len // 2 + 1, gap_len - gap_len // 2)
    right = gap_len + 1 - left
    ov = y[pos]
    for k, p in enumerate(pos):
        lo = p - left[k]
        hi = p + right[k]
        # nearest observed value at or before lo, at or after hi
        j = np.searchsorted(pos, lo, side="right") - 1
        l = np.searchsorted(pos, hi, side="left")
        if j >= 0 and pos[j] != p:
            prev_val[k], d_prev[k] = ov[j], p - pos[j]
        if l < len(pos) and pos[l] != p:
            next_val[k], d_next[k] = ov[l], pos[l] - p
    tr = pd.DataFrame({"prev_val": prev_val, "next_val": next_val, "d_prev": d_prev, "d_next": d_next}, index=series.index[pos])
    mean = float(np.nanmean(y))
    for df in (tr,):
        df["prev_val"] = df["prev_val"].fillna(mean)
        df["next_val"] = df["next_val"].fillna(mean)
        df["d_prev"] = np.log1p(df["d_prev"].replace(0, 1e4))
        df["d_next"] = np.log1p(df["d_next"].replace(0, 1e4))
    ep = e_pred.copy()
    ep["prev_val"] = ep["prev_val"].fillna(mean)
    ep["next_val"] = ep["next_val"].fillna(mean)
    ep["d_prev"] = np.log1p(ep["d_prev"].fillna(1e4))
    ep["d_next"] = np.log1p(ep["d_next"].fillna(1e4))
    F_train = pd.concat([F.iloc[pos].reset_index(drop=True), tr.reset_index(drop=True)], axis=1)
    F_train.index = series.index[pos]
    F_pred = pd.concat([F, ep], axis=1)
    return F_train, F_pred, donors


def _ml_fill(series, others, ctx, make_model, lags=(-1, 0, 1), use_edges=True, use_calendar=True, max_donors=6, max_train=6000, scale=False):
    rng = ctx.rng(5)
    F_train, F_pred, donors = _train_features(series, others, ctx, lags, use_edges, use_calendar, max_donors, rng)
    y = series.dropna()
    if len(y) < 30:
        return series
    Xtr = F_train.loc[y.index]
    if len(Xtr) > max_train:
        sel = rng.choice(len(Xtr), size=max_train, replace=False)
        Xtr, y = Xtr.iloc[sel], y.iloc[sel]
    Xp = F_pred
    if scale:
        mu, sd = Xtr.mean(), Xtr.std().replace(0, 1.0)
        Xtr, Xp = (Xtr - mu) / sd, (Xp - mu) / sd
    model = make_model()
    model.fit(Xtr.to_numpy(float), y.to_numpy(float))
    est = pd.Series(model.predict(Xp.to_numpy(float)), index=series.index)
    return series.where(series.notna(), est)


@register("random_forest", "Random forest", "ml", needs=("series",), best_for=("G3", "G4", "G5", "G6"), library="scikit-learn", section="3.4", cost="medium")
def random_forest(series, others, ctx, n_estimators=100, min_leaf=3, **kw):
    from sklearn.ensemble import RandomForestRegressor

    return _ml_fill(series, others, ctx, lambda: RandomForestRegressor(n_estimators=n_estimators, min_samples_leaf=min_leaf, n_jobs=N_JOBS, random_state=ctx.seed), **kw)


@register("extra_trees", "Extra trees", "ml", needs=("series",), best_for=("G3", "G4", "G5", "G6"), library="scikit-learn", section="3.4", cost="medium")
def extra_trees(series, others, ctx, n_estimators=100, min_leaf=3, **kw):
    from sklearn.ensemble import ExtraTreesRegressor

    return _ml_fill(series, others, ctx, lambda: ExtraTreesRegressor(n_estimators=n_estimators, min_samples_leaf=min_leaf, n_jobs=N_JOBS, random_state=ctx.seed), **kw)


@register("hist_gradient_boosting", "Gradient boosting (scikit-learn)", "ml", needs=("series",), best_for=("G3", "G4", "G5", "G6"), library="scikit-learn", section="3.4", cost="medium")
def hist_gradient_boosting(series, others, ctx, max_iter=200, learning_rate=0.06, **kw):
    from sklearn.ensemble import HistGradientBoostingRegressor

    return _ml_fill(series, others, ctx, lambda: HistGradientBoostingRegressor(max_iter=max_iter, learning_rate=learning_rate, random_state=ctx.seed), **kw)


@register("xgboost", "Gradient boosting (XGBoost)", "ml", needs=("series",), best_for=("G3", "G4", "G5", "G6"), library="xgboost", section="3.4", cost="medium")
def xgboost_fill(series, others, ctx, n_estimators=300, learning_rate=0.05, max_depth=5, **kw):
    from xgboost import XGBRegressor

    return _ml_fill(series, others, ctx, lambda: XGBRegressor(n_estimators=n_estimators, learning_rate=learning_rate, max_depth=max_depth, subsample=0.8, random_state=ctx.seed, n_jobs=N_JOBS, verbosity=0), **kw)


@register("lightgbm", "Gradient boosting (LightGBM)", "ml", needs=("series",), best_for=("G3", "G4", "G5", "G6"), library="lightgbm", section="3.4", cost="medium")
def lightgbm_fill(series, others, ctx, n_estimators=300, learning_rate=0.05, num_leaves=31, **kw):
    from lightgbm import LGBMRegressor

    return _ml_fill(series, others, ctx, lambda: LGBMRegressor(n_estimators=n_estimators, learning_rate=learning_rate, num_leaves=num_leaves, subsample=0.8, subsample_freq=1, random_state=ctx.seed, n_jobs=N_JOBS, verbose=-1), **kw)


# XGBoost and LightGBM are optional: without the package (for example in the browser with Pyodide) they are listed as
# unavailable instead of being offered and then failing.
import importlib.util as _iu  # noqa: E402

from .base import REGISTRY as _REG  # noqa: E402

for _mid, _pkg in (("xgboost", "xgboost"), ("lightgbm", "lightgbm")):
    if _iu.find_spec(_pkg) is None:
        _REG[_mid].info.status = "unavailable"


@register("svr", "Support vector regression", "ml", needs=("series",), best_for=("G3", "G5"), library="scikit-learn", section="3.4", cost="medium")
def svr(series, others, ctx, C=3.0, epsilon=0.05, max_train=2500, **kw):
    from sklearn.svm import SVR

    return _ml_fill(series, others, ctx, lambda: SVR(C=C, epsilon=epsilon, gamma="scale"), max_train=max_train, scale=True, **kw)


@register("mlp", "Feed-forward neural network", "ml", needs=("series",), best_for=("G3", "G4", "G5", "G6"), library="scikit-learn", section="3.4", cost="medium")
def mlp(series, others, ctx, hidden=(64, 32), max_iter=300, **kw):
    from sklearn.neural_network import MLPRegressor

    return _ml_fill(series, others, ctx, lambda: MLPRegressor(hidden_layer_sizes=hidden, max_iter=max_iter, early_stopping=True, random_state=ctx.seed), scale=True, **kw)
