"""Rating-curve methods (catalog section 8).

R1  discharge missing, stage present       -> `rating_*` methods (target = discharge, driver = stage)
R2  stage missing, discharge present       -> `rating_inv_*` methods (target = stage, driver = discharge)
R5  stage beyond the highest gauging       -> flagged by `RatingFit.flags` and scored by the "extrapolation" metric group

The user supplies the gaugings in `ctx.meta["gaugings"]` (columns date, stage, discharge and optionally u_rel, the relative
standard uncertainty) and the name of the stage (or discharge) column of `others` in `ctx.meta["driver"]`.

Curve forms: single power law Q = a (h - h0)^b, two-segment power law (continuous at the breakpoint hb), step shifts of h0
(scour or fill) found from the gaugings, Jones-type hysteresis, a local fit on the concurrent record, and a LOWESS curve.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import optimize

from .base import register, steps_per_day

EPS = 1e-9

# ----------------------------------------------------------------------------- gaugings


def _pick(df: pd.DataFrame, names) -> str | None:
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n in low:
            return low[n]
    for c in df.columns:
        if any(c.lower().startswith(n) for n in names):
            return c
    return None


def normalise_gaugings(g: pd.DataFrame) -> pd.DataFrame:
    """Return a table with columns date, h, q, u (sorted by date, finite values only)."""
    cd = _pick(g, ("date", "time", "datetime"))
    ch = _pick(g, ("stage", "h", "level", "gauge_height"))
    cq = _pick(g, ("discharge", "q", "flow"))
    cu = _pick(g, ("u_rel", "u", "uncertainty"))
    if cd is None or ch is None or cq is None:
        raise ValueError("gaugings need date, stage and discharge columns")
    out = pd.DataFrame({"date": pd.to_datetime(g[cd]), "h": g[ch].astype(float), "q": g[cq].astype(float)})
    out["u"] = g[cu].astype(float) if cu is not None else 0.05
    out = out[np.isfinite(out["h"]) & np.isfinite(out["q"]) & (out["q"] > 0)].sort_values("date").reset_index(drop=True)
    out["u"] = out["u"].clip(lower=0.01).fillna(0.05)
    return out


# ----------------------------------------------------------------------------- the curve


@dataclass
class RatingFit:
    """Fitted rating: lnQ = ln a + b1 ln(h - h0_p) (below hb) or the second segment above hb; h0 may change by period p."""

    ln_a: float
    b1: float
    h0: np.ndarray  # one zero-flow stage per period
    breaks: np.ndarray  # period start times (datetime64), len = len(h0) - 1
    b2: float | None = None
    hb: float | None = None
    beta: float = 0.0  # hysteresis coefficient (Jones): Q = Q_steady sqrt(1 + beta dh/dt)
    h_min: float = np.nan  # gauged range
    h_max: float = np.nan
    q_min: float = np.nan
    q_max: float = np.nan
    n: int = 0
    rmse_ln: float = np.nan
    kind: str = ""
    notes: list = field(default_factory=list)

    # -- period lookup
    def period(self, times) -> np.ndarray:
        if len(self.breaks) == 0:
            return np.zeros(len(times), dtype=int)
        t = pd.DatetimeIndex(times).to_numpy("datetime64[ns]")
        return np.searchsorted(self.breaks.astype("datetime64[ns]"), t, side="right")

    def _lnq(self, h, h0):
        d = np.maximum(h - h0, EPS)
        low = self.ln_a + self.b1 * np.log(d)
        if self.b2 is None or self.hb is None:
            return low
        db = np.maximum(self.hb - h0, EPS)
        high = self.ln_a + self.b1 * np.log(db) + self.b2 * np.log(d / db)
        return np.where(h <= self.hb, low, high)

    def steady(self, h, times) -> np.ndarray:
        h = np.asarray(h, float)
        h0 = self.h0[self.period(times)]
        q = np.exp(self._lnq(h, h0))
        return np.where(h > h0, q, 0.0)

    def discharge(self, stage: pd.Series, dh_dt: np.ndarray | None = None) -> pd.Series:
        q = self.steady(stage.to_numpy(float), stage.index)
        if self.beta != 0.0 and dh_dt is not None:
            q = q * np.sqrt(np.clip(1.0 + self.beta * dh_dt, 0.3, 3.0))
        return pd.Series(q, index=stage.index)

    def stage_of(self, q, times) -> np.ndarray:
        """Inverse rating (steady). Hysteresis is not inverted."""
        q = np.maximum(np.asarray(q, float), EPS)
        h0 = self.h0[self.period(times)]
        lq = np.log(q)
        if self.b2 is None or self.hb is None:
            return h0 + np.exp((lq - self.ln_a) / self.b1)
        db = np.maximum(self.hb - h0, EPS)
        ln_qb = self.ln_a + self.b1 * np.log(db)
        d_low = np.exp((lq - self.ln_a) / self.b1)
        d_high = db * np.exp((lq - ln_qb) / self.b2)
        return h0 + np.where(lq <= ln_qb, d_low, d_high)

    def flags(self, stage: pd.Series) -> pd.DataFrame:
        """Where predictions leave the gauged range (R5): never silent."""
        h = stage.to_numpy(float)
        return pd.DataFrame({"above_highest_gauging": h > self.h_max, "below_lowest_gauging": h < self.h_min}, index=stage.index)


def _wls(x, y, w):
    X = np.column_stack([np.ones_like(x), x])
    sw = np.sqrt(w)
    beta, *_ = np.linalg.lstsq(X * sw[:, None], y * sw, rcond=None)
    r = y - X @ beta
    return beta, float((w * r**2).sum()), r


def fit_single(h, lq, w):
    """Power law with unknown h0 by a 1-D search over h0 (the log-log fit is exact for each h0)."""
    hmin, hmax = float(h.min()), float(h.max())
    span = max(hmax - hmin, 0.1)
    lo, hi = hmin - 2.0 * span, hmin - 1e-3 * span

    def sse(h0):
        return _wls(np.log(h - h0), lq, w)[1]

    grid = np.linspace(lo, hi, 60)
    vals = [sse(g) for g in grid]
    k = int(np.argmin(vals))
    a, b = grid[max(k - 1, 0)], grid[min(k + 1, len(grid) - 1)]
    res = optimize.minimize_scalar(sse, bounds=(a, b), method="bounded", options={"xatol": 1e-5})
    h0 = float(res.x)
    beta, s, r = _wls(np.log(h - h0), lq, w)
    return dict(ln_a=float(beta[0]), b1=float(beta[1]), h0=h0, sse=s)


def _model_lnq(theta, h, per, P, segmented):
    ln_a, b1 = theta[0], theta[1]
    if segmented:
        b2, hb = theta[2], theta[3]
        h0 = theta[4 : 4 + P][per]
        d = np.maximum(h - h0, EPS)
        db = np.maximum(hb - h0, EPS)
        low = ln_a + b1 * np.log(d)
        high = ln_a + b1 * np.log(db) + b2 * np.log(d / db)
        return np.where(h <= hb, low, high)
    h0 = theta[2 : 2 + P][per]
    return ln_a + b1 * np.log(np.maximum(h - h0, EPS))


def _fit_general(h, lq, w, per, P, segmented, init, hb_start=None):
    """Weighted least squares in log space for shared (a, b1[, b2, hb]) and one h0 per period."""
    hmin, hmax = float(h.min()), float(h.max())
    span = max(hmax - hmin, 0.1)
    h0_lo, h0_hi = hmin - 2.0 * span, hmin - 1e-3 * span
    sw = np.sqrt(w)

    def resid(theta):
        return (lq - _model_lnq(theta, h, per, P, segmented)) * sw

    if segmented:
        x0 = np.concatenate([[init["ln_a"], init["b1"], max(init["b1"] + 0.3, 1.0), hb_start], np.full(P, init["h0"])])
        lb = np.concatenate([[-20.0, 0.3, 0.3, hmin + 0.25 * span], np.full(P, h0_lo)])
        ub = np.concatenate([[20.0, 5.0, 6.0, hmax - 0.05 * span], np.full(P, h0_hi)])
    else:
        x0 = np.concatenate([[init["ln_a"], init["b1"]], np.full(P, init["h0"])])
        lb = np.concatenate([[-20.0, 0.3], np.full(P, h0_lo)])
        ub = np.concatenate([[20.0, 5.0], np.full(P, h0_hi)])
    x0 = np.clip(x0, lb + 1e-9, ub - 1e-9)
    res = optimize.least_squares(resid, x0, bounds=(lb, ub), method="trf", max_nfev=200)
    return res.x, float((res.fun**2).sum())


def _bic(sse, n, k):
    return n * np.log(max(sse, 1e-12) / n) + k * np.log(n)


def _detect_shifts(g, h, lq, w, segmented, init, hb_start, max_shifts=4, min_seg=6, min_gain=12.0):
    """Greedy search for step changes of h0 between gaugings. Returns (theta, per, break dates)."""
    n = len(h)
    cuts = []  # indices where a new period starts
    per = np.zeros(n, dtype=int)
    theta, sse = _fit_general(h, lq, w, per, 1, segmented, init, hb_start)
    best_bic = _bic(sse, n, len(theta) + 1)
    step = max(1, n // 50)
    for _ in range(max_shifts):
        cand = None
        bounds = [0] + sorted(cuts) + [n]
        for k in range(min_seg, n - min_seg + 1, step):
            if any(abs(k - c) < min_seg for c in cuts):
                continue
            new_cuts = sorted(cuts + [k])
            per_k = np.zeros(n, dtype=int)
            for c in new_cuts:
                per_k[c:] += 1
            P = len(new_cuts) + 1
            # the periods must each hold enough gaugings
            if np.bincount(per_k, minlength=P).min() < min_seg:
                continue
            init_k = dict(init)
            th, s = _fit_general(h, lq, w, per_k, P, segmented, init_k, hb_start)
            b = _bic(s, n, len(th) + P - 1 + 1)
            if cand is None or b < cand[0]:
                cand = (b, k, th, per_k)
        if cand is None or best_bic - cand[0] < min_gain:
            break
        best_bic, k, theta, per = cand
        cuts = sorted(cuts + [k])
    # refine cut positions to the stage-independent midpoint between the two neighbouring gaugings
    dates = g["date"].to_numpy("datetime64[ns]")
    breaks = np.array([dates[c - 1] + (dates[c] - dates[c - 1]) // 2 for c in cuts], dtype="datetime64[ns]")
    return theta, per, breaks


_CACHE: dict = {}


def fit_rating(gaugings: pd.DataFrame, segmented: bool = False, shifts: bool = False, weighted: bool = True, hysteresis_stage: pd.Series | None = None, max_shifts: int = 4) -> RatingFit:
    """Fit a rating to gaugings. `hysteresis_stage` (continuous stage) switches on the Jones factor."""
    g = normalise_gaugings(gaugings)
    key = (g["h"].round(5).sum(), g["q"].round(5).sum(), len(g), segmented, shifts, weighted, max_shifts, None if hysteresis_stage is None else (len(hysteresis_stage), float(hysteresis_stage.sum())))
    if key in _CACHE:
        return _CACHE[key]
    if len(g) < 8:
        raise ValueError("fewer than 8 usable gaugings")
    h, q = g["h"].to_numpy(), g["q"].to_numpy()
    lq = np.log(q)
    w = 1.0 / g["u"].to_numpy() ** 2 if weighted else np.ones(len(g))
    w = w / w.mean()
    single = fit_single(h, lq, w)
    notes = []
    hmin, hmax = float(h.min()), float(h.max())
    seg_ok = False
    hb_start = None
    if segmented:
        # breakpoint search over quantiles of the gauged stage; need at least 4 gaugings above and below
        best = None
        for qq in (0.55, 0.7, 0.8, 0.9):
            hb0 = float(np.quantile(h, qq))
            if (h > hb0).sum() < 4 or (h <= hb0).sum() < 4:
                continue
            try:
                th, s = _fit_general(h, lq, w, np.zeros(len(h), int), 1, True, single, hb0)
            except Exception:
                continue
            if best is None or s < best[1]:
                best = (hb0, s)
        if best is not None and (h > best[0]).sum() >= 4:
            hb_start = best[0]
            seg_ok = True
        else:
            notes.append("too few gaugings above the breakpoint: single power law used")
    segmented = segmented and seg_ok
    if shifts:
        if len(g) < 30:
            notes.append("fewer than 30 gaugings: shift search skipped")
            theta, sse = _fit_general(h, lq, w, np.zeros(len(h), int), 1, segmented, single, hb_start)
            per, breaks = np.zeros(len(h), int), np.array([], dtype="datetime64[ns]")
        else:
            theta, per, breaks = _detect_shifts(g, h, lq, w, segmented, single, hb_start, max_shifts=max_shifts)
    else:
        theta, sse = _fit_general(h, lq, w, np.zeros(len(h), int), 1, segmented, single, hb_start)
        per, breaks = np.zeros(len(h), int), np.array([], dtype="datetime64[ns]")
    P = len(breaks) + 1
    if segmented:
        fit = RatingFit(ln_a=float(theta[0]), b1=float(theta[1]), b2=float(theta[2]), hb=float(theta[3]), h0=np.asarray(theta[4 : 4 + P], float), breaks=breaks)
    else:
        fit = RatingFit(ln_a=float(theta[0]), b1=float(theta[1]), h0=np.asarray(theta[2 : 2 + P], float), breaks=breaks)
    fit.h_min, fit.h_max, fit.q_min, fit.q_max, fit.n = hmin, hmax, float(q.min()), float(q.max()), len(g)
    r = lq - _model_lnq(theta, h, per, P, segmented)
    fit.rmse_ln = float(np.sqrt(np.mean(r**2)))
    fit.kind = ("segmented" if segmented else "single") + ("+shifts" if P > 1 else "")
    fit.notes = notes
    if hysteresis_stage is not None:
        fit.beta = _fit_hysteresis(fit, g, hysteresis_stage, w)
    _CACHE[key] = fit
    if len(_CACHE) > 64:
        _CACHE.pop(next(iter(_CACHE)))
    return fit


def stage_rate(stage: pd.Series) -> np.ndarray:
    """dh/dt in m per day (central differences)."""
    spd = steps_per_day(stage.index)
    return np.gradient(stage.interpolate(limit_direction="both").to_numpy(float)) * spd


def _fit_hysteresis(fit: RatingFit, g: pd.DataFrame, stage: pd.Series, w) -> float:
    dh = pd.Series(stage_rate(stage), index=stage.index)
    pos = stage.index.get_indexer(pd.DatetimeIndex(g["date"]), method="nearest")
    ok = pos >= 0
    d = dh.to_numpy()[pos[ok]]
    qs = fit.steady(g["h"].to_numpy()[ok], pd.DatetimeIndex(g["date"])[ok])
    good = qs > 0
    if good.sum() < 20:
        return 0.0
    y = np.log(g["q"].to_numpy()[ok][good]) - np.log(qs[good])
    d, ww = d[good], w[ok][good]

    def sse(beta):
        return float((ww * (y - 0.5 * np.log(np.clip(1.0 + beta * d, 0.3, 3.0))) ** 2).sum())

    res = optimize.minimize_scalar(sse, bounds=(-1.5, 1.5), method="bounded")
    return float(res.x) if sse(0.0) - res.fun > 1e-3 * sse(0.0) else 0.0


# ----------------------------------------------------------------------------- method wrappers


def _driver(others, ctx) -> pd.Series:
    return others[ctx.meta["driver"]]


def _forward(series, others, ctx, segmented, shifts, hysteresis=False, weighted=True):
    stage = _driver(others, ctx)
    fit = fit_rating(ctx.meta["gaugings"], segmented=segmented, shifts=shifts, weighted=weighted, hysteresis_stage=stage if hysteresis else None)
    dh = stage_rate(stage) if hysteresis else None
    q = fit.discharge(stage, dh)
    q[stage.isna()] = np.nan
    return series.where(series.notna(), q)


def _inverse(series, others, ctx, segmented, shifts):
    """Stage from discharge: the rating is fitted as stage -> discharge on the gaugings, then inverted."""
    q = _driver(others, ctx)
    fit = fit_rating(ctx.meta["gaugings"], segmented=segmented, shifts=shifts)
    h = pd.Series(fit.stage_of(q.to_numpy(float), q.index), index=q.index)
    h[q.isna() | (q <= 0)] = np.nan
    return series.where(series.notna(), h)


KW = dict(needs=("gaugings", "driver"), library="scipy", transform="none")


@register("rating_power", "Single power-law rating from gaugings", "rating", variables=("streamflow", "discharge"), best_for=("R1", "G3"), section="8.2", **KW)
def rating_power(series, others, ctx):
    return _forward(series, others, ctx, False, False)


@register("rating_segmented", "Two-segment power-law rating", "rating", variables=("streamflow", "discharge"), best_for=("R1", "G3"), section="8.2", **KW)
def rating_segmented(series, others, ctx):
    return _forward(series, others, ctx, True, False)


@register("rating_shift_power", "Power-law rating with detected shifts of h0", "rating", variables=("streamflow", "discharge"), best_for=("R1", "G3"), section="8.3", cost="medium", **KW)
def rating_shift_power(series, others, ctx):
    return _forward(series, others, ctx, False, True)


@register("rating_shift_segmented", "Two-segment rating with detected shifts", "rating", variables=("streamflow", "discharge"), best_for=("R1", "G3"), section="8.3", cost="medium", **KW)
def rating_shift_segmented(series, others, ctx):
    return _forward(series, others, ctx, True, True)


@register("rating_shift_hysteresis", "Two-segment rating with shifts and Jones hysteresis factor", "rating", variables=("streamflow", "discharge"), best_for=("R1", "G3"), section="8.3", cost="medium", **KW)
def rating_shift_hysteresis(series, others, ctx):
    return _forward(series, others, ctx, True, True, hysteresis=True)


@register("rating_local_pairs", "Local power-law rating from the concurrent record around each gap", "rating", variables=("streamflow", "discharge"), needs=("series", "driver"), best_for=("R1", "G2", "G3"), section="8.3", library="scipy", transform="none", cost="medium")
def rating_local_pairs(series, others, ctx, min_pairs=60, window_days=90, max_window_days=720):
    stage = _driver(others, ctx)
    spd = steps_per_day(series.index)
    miss = series.isna() & stage.notna()
    if not miss.any():
        return series
    out = series.copy()
    obs = series.notna() & stage.notna()
    pos = np.flatnonzero(miss.to_numpy())
    # contiguous gap runs
    splits = np.flatnonzero(np.diff(pos) > 1) + 1
    for run in np.split(pos, splits):
        w = window_days
        while True:
            lo, hi = run[0] - int(w * spd), run[-1] + int(w * spd)
            sl = slice(max(lo, 0), min(hi, len(series) - 1) + 1)
            sel = obs.iloc[sl]
            if sel.sum() >= min_pairs or w >= max_window_days:
                break
            w *= 2
        h = stage.iloc[sl][sel].to_numpy()
        qv = series.iloc[sl][sel].to_numpy()
        ok = qv > 0
        if ok.sum() < 20 or np.ptp(h[ok]) < 1e-6:
            continue
        f = fit_single(h[ok], np.log(qv[ok]), np.ones(ok.sum()))
        hh = stage.iloc[run].to_numpy()
        est = np.where(hh > f["h0"], np.exp(f["ln_a"] + f["b1"] * np.log(np.maximum(hh - f["h0"], EPS))), 0.0)
        out.iloc[run] = est
    return out


@register("rating_loess", "LOWESS rating curve in log-log space with power-law extension", "rating", variables=("streamflow", "discharge"), best_for=("R1",), section="8.2", **KW)
def rating_loess(series, others, ctx, frac=0.5):
    stage = _driver(others, ctx)
    g = normalise_gaugings(ctx.meta["gaugings"])
    fit = fit_rating(ctx.meta["gaugings"], segmented=False, shifts=False)
    h0 = float(fit.h0[0])
    x = np.log(np.maximum(g["h"].to_numpy() - h0, EPS))
    y = np.log(g["q"].to_numpy())
    grid = np.linspace(x.min(), x.max(), 120)
    k = max(int(frac * len(x)), 8)
    est = np.empty_like(grid)
    for i, x0 in enumerate(grid):
        d = np.abs(x - x0)
        hbw = np.sort(d)[k - 1] + 1e-9
        wt = np.clip(1 - (d / hbw) ** 3, 0, None) ** 3
        sw = np.sqrt(wt)
        X = np.column_stack([np.ones_like(x), x - x0])
        beta, *_ = np.linalg.lstsq(X * sw[:, None], y * sw, rcond=None)
        est[i] = beta[0]
    sl_lo = (est[3] - est[0]) / (grid[3] - grid[0])
    sl_hi = (est[-1] - est[-4]) / (grid[-1] - grid[-4])
    hv = stage.to_numpy(float)
    xv = np.log(np.maximum(hv - h0, EPS))
    q = np.interp(xv, grid, est)
    q = np.where(xv < grid[0], est[0] + sl_lo * (xv - grid[0]), q)
    q = np.where(xv > grid[-1], est[-1] + sl_hi * (xv - grid[-1]), q)
    qv = np.where(hv > h0, np.exp(q), 0.0)
    qv[np.isnan(hv)] = np.nan
    return series.where(series.notna(), pd.Series(qv, index=series.index))


# ----- year-by-year rating (alluvial channels: a new curve each hydrological year, as BWDB does)
#
# ctx.meta["yearly_rating"] = {"start_month": 4, "min_n": 8, "min_span": 0.3, "rule": "nearest" | "previous" | "interpolate", "mode": "shared" | "free", "segments": 1 | 2}
# A year gets its own single power law when it has at least min_n gaugings covering at least min_span of the whole gauged
# stage range. Other years borrow: from the nearest fitted year (earlier one on a tie), from the previous fitted year
# (the curve stays in force until a new one), or by interpolating ln Q between the fitted years before and after.

YEARLY_DEFAULTS = dict(start_month=1, min_n=8, min_span=0.3, rule="nearest", mode="shared", segments=1)
# mode "free": C, e, n fitted for each year. mode "shared": C and n fitted on all years together and e for each year
# (the zero-flow stage that scour and siltation move); one parameter per year, so fewer gaugings are needed (half of min_n,
# at least 3) and the high-flow shape comes from all years instead of one year's few floods.
# segments 2: a second, continuous segment above a break stage. Shared mode: one break and one pair of exponents for all
# years (the break is usually a fixed feature such as bank-full level), e per year. Free mode: each year looks for its own
# break and keeps it only when its gaugings support it (BIC lower by 6 or more), otherwise one segment.
# Every row carries "segments" ([{h_from, a, h0, b}, ...], the editor's format); a, h0, b repeat the lowest segment.


def hydro_year(dates, start_month: int = 1) -> np.ndarray:
    d = pd.DatetimeIndex(dates)
    return np.where(d.month >= int(start_month), d.year, d.year - 1).astype(int)


def _row(y, s, status="fitted"):
    return dict(year=int(y), n=int(len(s)), h_min=float(s["h"].min()), h_max=float(s["h"].max()), segments=None, a=None, h0=None, b=None, b2=None, hb=None,
                se_pct=None, bias_pct=None, status=status, note="")


def _segs(ln_a, b1, h0, b2=None, hb=None) -> list:
    """Segments of a continuous rating: Q = a (h - h0)^b1 below hb, and the second segment through the same point at hb."""
    a = float(np.exp(ln_a))
    out = [dict(h_from=None, a=a, h0=float(h0), b=float(b1))]
    if b2 is not None and hb is not None:
        out.append(dict(h_from=float(hb), a=float(a * max(hb - h0, EPS) ** (b1 - b2)), h0=float(h0), b=float(b2)))
    return out


def _finish(row, segs, s):
    """Fill a row from its segments and score them on the year's own gaugings (percent deviation (Qg - Qc) / Qc)."""
    qc = manual_discharge(s["h"].to_numpy(float), normalise_manual(segs))
    dev = s["q"].to_numpy(float) / np.maximum(qc, EPS) - 1.0
    row.update(segments=segs, a=segs[0]["a"], h0=segs[0]["h0"], b=segs[0]["b"], b2=segs[1]["b"] if len(segs) > 1 else None, hb=segs[1]["h_from"] if len(segs) > 1 else None,
               se_pct=float(100 * np.sqrt(np.mean(dev**2))), bias_pct=float(100 * np.mean(dev)))
    return row


def _sse_ln(segs, h, lq):
    q = manual_discharge(h, normalise_manual(segs))
    r = lq - np.log(np.maximum(q, EPS))
    return float((r**2).sum())


def _fit_yearly_shared(g, yr, min_n, weighted, segments):
    need = max(3, int(min_n) // 2)
    years = sorted(set(yr.tolist()))
    keep = [y for y in years if int((yr == y).sum()) >= need]
    info = dict(mode="shared", need=need)
    if not keep:
        return [_row(y, g[yr == y], f"too few gaugings ({int((yr == y).sum())} < {need})") for y in years], info
    sel = np.isin(yr, keep)
    h, lq = g["h"].to_numpy(float)[sel], np.log(g["q"].to_numpy(float))[sel]
    w = 1.0 / g["u"].to_numpy(float)[sel] ** 2 if weighted else np.ones(int(sel.sum()))
    w = w / w.mean()
    P, n = len(keep), len(h)
    per = np.searchsorted(np.array(keep), yr[sel])
    init = fit_single(h, lq, w)
    fits = {1: _fit_general(h, lq, w, per, P, False, init)}
    if int(segments) >= 2:
        best = None
        for qq in np.linspace(0.30, 0.96, 14):  # starting points for the break across the gauged range; the fit moves it
            hb0 = float(np.quantile(h, qq))
            if (h > hb0).sum() < 6 or (h <= hb0).sum() < 6:
                continue
            try:
                th, s_ = _fit_general(h, lq, w, per, P, True, init, hb0)
            except Exception:
                continue
            if best is None or s_ < best[1]:
                best = (th, s_)
        if best is not None:
            fits[2] = best
    bic = {k: float(_bic(s_, n, (2 if k == 1 else 4) + P)) for k, (th, s_) in fits.items()}
    k = 2 if 2 in fits else 1
    info.update(segments_used=k, bic=bic, supported=2 if (2 in bic and bic[2] <= bic[1] - 6) else 1)
    theta = fits[k][0]
    if k == 2:
        info["hb"] = float(theta[3])
    rows = []
    for y in years:
        s = g[yr == y]
        if y not in keep:
            rows.append(_row(y, s, f"too few gaugings ({len(s)} < {need})"))
            continue
        i = keep.index(y)
        segs = _segs(theta[0], theta[1], theta[4 + i], theta[2], theta[3]) if k == 2 else _segs(theta[0], theta[1], theta[2 + i])
        rows.append(_finish(_row(y, s), segs, s))
    return rows, info


def _fit_yearly_free(g, yr, min_n, min_span, weighted, segments):
    span_all = max(float(g["h"].max() - g["h"].min()), 0.1)
    rows, info = [], dict(mode="free")
    for y in sorted(set(yr.tolist())):
        s = g[yr == y]
        row = _row(y, s)
        if len(s) < min_n:
            row["status"] = f"too few gaugings ({len(s)} < {int(min_n)})"
        elif row["h_max"] - row["h_min"] < float(min_span) * span_all:
            row["status"] = f"stage range too narrow ({100 * (row['h_max'] - row['h_min']) / span_all:.0f} % of all gaugings)"
        else:
            h, lq = s["h"].to_numpy(float), np.log(s["q"].to_numpy(float))
            w = 1.0 / s["u"].to_numpy(float) ** 2 if weighted else np.ones(len(s))
            f = fit_single(h, lq, w / w.mean())
            if not (0.8 <= f["b1"] <= 4.5):
                row["status"] = f"exponent n = {f['b1']:.2f} is not physical"
                rows.append(row)
                continue
            segs = _segs(f["ln_a"], f["b1"], f["h0"])
            if int(segments) >= 2:
                note = "one segment: too few gaugings above a break"
                if (h > np.quantile(h, 0.5)).sum() >= 6:
                    try:
                        fr = fit_rating(s[["date", "h", "q", "u"]], segmented=True)
                        if fr.b2 is not None and fr.hb is not None and 0.8 <= fr.b1 <= 4.5 and 0.8 <= fr.b2 <= 4.5:
                            s2 = _segs(fr.ln_a, fr.b1, float(fr.h0[0]), fr.b2, fr.hb)
                            n_ = len(h)
                            b1_, b2_ = _bic(_sse_ln(segs, h, lq), n_, 3), _bic(_sse_ln(s2, h, lq), n_, 5)
                            if b2_ <= b1_ - 6:
                                segs, note = s2, ""
                            else:
                                note = "one segment: a break does not improve the fit enough (BIC)"
                    except Exception:
                        pass
                row["note"] = note
            _finish(row, segs, s)
        rows.append(row)
    return rows, info


def fit_yearly_info(gaugings: pd.DataFrame, start_month=1, min_n=8, min_span=0.3, weighted=True, mode="shared", segments=1, **_):
    """Curves per hydrological year and information on the fit (mode, BIC of 1 and 2 segments in shared mode)."""
    g = normalise_gaugings(gaugings)
    yr = hydro_year(g["date"], start_month)
    if mode == "shared":
        return _fit_yearly_shared(g, yr, min_n, weighted, segments)
    return _fit_yearly_free(g, yr, min_n, min_span, weighted, segments)


def fit_yearly(gaugings: pd.DataFrame, **opt) -> list:
    return fit_yearly_info(gaugings, **opt)[0]


def _q_of(r, h):
    return manual_discharge(np.asarray(h, float), normalise_manual(r["segments"]))


def yearly_discharge(stage: pd.Series, rows, start_month=1, rule="nearest", **_):
    """Discharge from stage with the curve of each step's hydrological year. Returns (Series, {year: source})."""
    fitted = {r["year"]: r for r in rows if r["status"] == "fitted"}
    if not fitted:
        raise ValueError("no year has enough gaugings for a curve of its own")
    fy = np.array(sorted(fitted))
    h = stage.to_numpy(float)
    yrs = hydro_year(stage.index, start_month)
    q = np.full(len(h), np.nan)
    source = {}
    for y in np.unique(yrs):
        m = yrs == y
        y = int(y)
        if y in fitted:
            q[m] = _q_of(fitted[y], h[m])
            source[y] = "own curve"
            continue
        prev, nxt = fy[fy < y], fy[fy > y]
        if rule == "interpolate" and len(prev) and len(nxt):
            p, nn = int(prev[-1]), int(nxt[0])
            wgt = (y - p) / (nn - p)
            qp, qn = _q_of(fitted[p], h[m]), _q_of(fitted[nn], h[m])
            both = (qp > 0) & (qn > 0)
            q[m] = np.where(both, np.exp((1 - wgt) * np.log(np.maximum(qp, EPS)) + wgt * np.log(np.maximum(qn, EPS))), (1 - wgt) * qp + wgt * qn)
            source[y] = f"interpolated {p}-{nn}"
        else:
            use = int(prev[-1]) if (rule == "previous" and len(prev)) else int(fy[np.argmin(np.abs(fy - y) + (fy > y) * 1e-6)])
            q[m] = _q_of(fitted[use], h[m])
            source[y] = f"curve of {use}"
    q[np.isnan(h)] = np.nan
    return pd.Series(q, index=stage.index), source


@register("rating_yearly", "Year-by-year rating (a curve per hydrological year; other years borrow)", "rating", variables=("streamflow", "discharge"),
          needs=("gaugings", "driver"), best_for=("R1", "G3"), section="8.3", library="scipy", transform="none",
          limits="a year needs enough gaugings; others use the nearest, previous or interpolated curve")
def rating_yearly(series, others, ctx):
    opt = {**YEARLY_DEFAULTS, **(ctx.meta.get("yearly_rating") or {})}
    stage = _driver(others, ctx)
    rows = fit_yearly(ctx.meta["gaugings"], **opt)
    q, _ = yearly_discharge(stage, rows, **opt)
    return series.where(series.notna(), q)


# ----- manual rating (set by the user in the rating-curve editor)
#
# ctx.meta["manual_rating"] = {"segments": [{"h_from": None, "a": C, "h0": e, "b": n}, {"h_from": 3.2, ...}]}
# Segment i applies from its h_from up to the next segment's h_from (the first one from the lowest stage).
# Q = a (h - h0)^b inside a segment, 0 at or below its h0.


def normalise_manual(spec) -> list:
    segs = spec.get("segments") if isinstance(spec, dict) else spec
    out = []
    for s in segs or []:
        a, h0, b = float(s["a"]), float(s["h0"]), float(s["b"])
        if not (a > 0 and b > 0 and np.isfinite(a) and np.isfinite(b) and np.isfinite(h0)):
            raise ValueError("each rating segment needs C > 0, n > 0 and a finite e")
        hf = s.get("h_from")
        out.append(dict(h_from=-np.inf if hf in (None, "") else float(hf), a=a, h0=h0, b=b))
    if not out:
        raise ValueError("the manual rating has no segments")
    out.sort(key=lambda s: s["h_from"])
    out[0]["h_from"] = -np.inf
    return out


def manual_discharge(h, segs) -> np.ndarray:
    h = np.asarray(h, float)
    q = np.full(h.shape, np.nan)
    for i, s in enumerate(segs):
        top = segs[i + 1]["h_from"] if i + 1 < len(segs) else np.inf
        m = (h >= s["h_from"]) & (h < top)
        d = h[m] - s["h0"]
        q[m] = np.where(d > 0, s["a"] * np.power(np.maximum(d, 0.0), s["b"]), 0.0)
    return q


def manual_stage(q, segs, h_lo, h_hi) -> np.ndarray:
    """Inverse of the manual rating on the stage range [h_lo, h_hi] (monotone part only; outside it NaN)."""
    grid = np.linspace(h_lo, h_hi, 6000)
    qq = np.maximum.accumulate(np.nan_to_num(manual_discharge(grid, segs), nan=0.0))
    keep = np.r_[True, np.diff(qq) > 0]
    return np.interp(np.asarray(q, float), qq[keep], grid[keep], left=np.nan, right=np.nan)


KWM = dict(library="numpy", transform="none", section="8.2")


@register("rating_manual", "Manual rating from the rating-curve editor (segments of Q = C (h - e)^n)", "rating", variables=("streamflow", "discharge"),
          needs=("manual_rating", "driver"), best_for=("R1", "G3"), limits="only as good as the curve you set; check it against the gaugings", **KWM)
def rating_manual(series, others, ctx):
    stage = _driver(others, ctx)
    segs = normalise_manual(ctx.meta["manual_rating"])
    q = pd.Series(manual_discharge(stage.to_numpy(float), segs), index=series.index)
    q[stage.isna()] = np.nan
    return series.where(series.notna(), q)


@register("rating_inv_manual", "Inverse of the manual rating (stage from discharge)", "rating", variables=("stage",),
          needs=("manual_rating", "driver"), best_for=("R2",), limits="no stage beyond the range the curve covers", **KWM)
def rating_inv_manual(series, others, ctx):
    q = _driver(others, ctx)
    segs = normalise_manual(ctx.meta["manual_rating"])
    obs = series.dropna()
    lo = min(s["h0"] for s in segs)
    hi = (float(obs.max()) + 0.5 * float(obs.max() - obs.min())) if len(obs) else lo + 50.0
    h = pd.Series(manual_stage(q.to_numpy(float), segs, lo, hi), index=series.index)
    h[q.isna() | (q <= 0)] = np.nan
    return series.where(series.notna(), h)


# ----- inverse rating (R2)

KWI = dict(needs=("gaugings", "driver"), library="scipy", transform="none")


@register("rating_inv_power", "Inverse single power-law rating (stage from discharge)", "rating", variables=("stage",), best_for=("R2",), section="7", **KWI)
def rating_inv_power(series, others, ctx):
    return _inverse(series, others, ctx, False, False)


@register("rating_inv_segmented", "Inverse two-segment rating", "rating", variables=("stage",), best_for=("R2",), section="7", **KWI)
def rating_inv_segmented(series, others, ctx):
    return _inverse(series, others, ctx, True, False)


@register("rating_inv_shift", "Inverse two-segment rating with detected shifts", "rating", variables=("stage",), best_for=("R2",), section="7", cost="medium", **KWI)
def rating_inv_shift(series, others, ctx):
    return _inverse(series, others, ctx, True, True)
