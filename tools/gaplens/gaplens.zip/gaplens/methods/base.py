"""Method registry: every fill method is a function registered with its catalog metadata.

A method function has the signature
    fn(series, others, ctx, **params) -> Series | (Series, lo, hi)
and returns the series with its NaN positions filled where the method can fill them
(positions it cannot fill stay NaN). Observed values are never changed.

    series   target Series with NaN gaps
    others   DataFrame of other stations / covariates on the same index (or None)
    ctx      Ctx: variable, target name, coordinates, metadata, seed
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class Ctx:
    variable: str = "generic"
    target: str | None = None
    coords: pd.DataFrame | None = None  # index = station name; columns x_km, y_km, optional elevation_m
    meta: dict = field(default_factory=dict)  # areas_km2 {name: km2}, products [column names], precip, pet, accumulated_events ...
    seed: int = 0
    wet_threshold: float = 0.1
    lower: float | None = None  # physical lower bound; None = 0 for rainfall, streamflow, sediment, otherwise none
    upper: float | None = None

    def rng(self, offset: int = 0):
        return np.random.default_rng(self.seed + offset)


@dataclass
class MethodInfo:
    id: str
    name: str
    family: str  # temporal, timeseries, multistation, ml, rainfall, temperature, streamflow, waterlevel, rating, sediment, tidal, groundwater
    variables: tuple = ("any",)
    needs: tuple = ("series",)
    best_for: tuple = ()
    limits: str = ""
    library: str = ""
    section: str = ""
    status: str = "implemented"  # implemented | planned | unavailable
    uncertainty: bool = False
    transform: str = "auto"  # auto: log for streamflow/sediment; none: method handles its own scale
    cost: str = "low"  # low | medium | high


@dataclass
class FillOutput:
    values: pd.Series
    lo: pd.Series | None = None
    hi: pd.Series | None = None
    seconds: float = 0.0


REGISTRY: dict = {}


def steps_per_day(index: pd.DatetimeIndex) -> float:
    if len(index) < 2:
        return 1.0
    step = pd.Series(index).diff().median()
    return float(pd.Timedelta(days=1) / step)


# ------------------------------------------------------------------------------- transforms


class Transform:
    """log(x + c) or sqrt, remembered so that results can be mapped back."""

    def __init__(self, kind: str, ref: pd.Series | None = None):
        self.kind = kind
        self.c = 0.0
        if kind == "log" and ref is not None:
            pos = ref[ref > 0]
            self.c = float(0.01 * pos.mean()) if len(pos) else 1e-3

    def fwd(self, x):
        if self.kind == "none":
            return x
        if self.kind == "log":
            return np.log(np.maximum(x, 0.0) + self.c)
        if self.kind == "sqrt":
            return np.sqrt(np.maximum(x, 0.0))
        raise ValueError(self.kind)

    def inv(self, y):
        if self.kind == "none":
            return y
        if self.kind == "log":
            return np.maximum(np.exp(y) - self.c, 0.0)
        if self.kind == "sqrt":
            return np.square(np.maximum(y, 0.0))
        raise ValueError(self.kind)


NONNEG = ("rainfall", "streamflow", "sediment", "discharge")


def auto_transform(variable: str) -> str:
    return "log" if variable in ("streamflow", "sediment", "discharge") else "none"


# ------------------------------------------------------------------------------- requirements


def overlap_counts(series: pd.Series, others: pd.DataFrame | None) -> pd.Series:
    if others is None or others.shape[1] == 0:
        return pd.Series(dtype=int)
    obs = series.notna()
    return others.notna().mul(obs, axis=0).sum()


def usable_donors(series: pd.Series, others: pd.DataFrame | None, min_overlap: int = 30, min_corr: float = 0.2, exclude=()) -> list:
    """Other columns that share at least `min_overlap` observed steps with the target and correlate with it.

    `exclude` lists columns that are gridded products or covariates, not station donors.
    """
    if others is None or others.shape[1] == 0:
        return []
    out = []
    for c in others.columns:
        if c in exclude:
            continue
        pair = pd.concat([series, others[c]], axis=1).dropna()
        if len(pair) >= min_overlap and pair.iloc[:, 0].std() > 0 and pair.iloc[:, 1].std() > 0:
            r = pair.iloc[:, 0].corr(pair.iloc[:, 1])
            if np.isfinite(r) and r >= min_corr:
                out.append(c)
    return out


def check_needs(needs, series: pd.Series, others: pd.DataFrame | None, ctx: Ctx) -> list:
    """Return the list of unmet requirements (empty list = method can run)."""
    problems = []
    obs = series.dropna()
    for need in needs:
        if need == "series":
            if len(obs) < 10:
                problems.append("fewer than 10 observed values")
        elif need.startswith("years>="):
            k = float(need.split(">=")[1])
            step = pd.Series(obs.index).diff().median() if len(obs) > 2 else pd.Timedelta(0)
            span = ((obs.index[-1] - obs.index[0]) + step).total_seconds() / (365.25 * 86400.0) if len(obs) > 1 else 0  # the span counts the last step, so that 731 daily or hourly days are two years
            if span < k - 0.005:
                problems.append(f"needs {k:g} years of record, has {span:.1f}")
        elif need in ("neighbors", "covariate", "donor"):
            if len(usable_donors(series, others, exclude=ctx.meta.get("product", []))) < 1:
                problems.append("no donor series with enough overlap")
        elif need == "neighbors>=2":
            if len(usable_donors(series, others, exclude=ctx.meta.get("product", []))) < 2:
                problems.append("needs at least two donor series")
        elif need == "coords":
            names = [c for c in (others.columns if others is not None else []) if c not in ctx.meta.get("product", [])]
            if ctx.coords is None or not {"x_km", "y_km"} <= set(ctx.coords.columns) or ctx.target not in ctx.coords.index or not all(n in ctx.coords.index for n in names):
                problems.append("station coordinates missing")
        elif need == "areas":
            if "areas_km2" not in ctx.meta:
                problems.append("catchment areas missing")
        elif need == "product":
            if not ctx.meta.get("product"):
                problems.append("no gridded or reanalysis product supplied")
        elif need == "forcing":
            if "precip" not in ctx.meta:
                problems.append("no rainfall forcing supplied")
        elif need == "elevation":
            if ctx.coords is None or "elevation_m" not in ctx.coords.columns:
                problems.append("station elevations missing")
        elif need == "gaugings":
            if "gaugings" not in ctx.meta:
                problems.append("no gaugings supplied")
        elif need in ("stations", "stations>=2"):
            skip = list(ctx.meta.get("product", [])) + list(ctx.meta.get("covariates", []))
            k = 2 if need.endswith("2") else 1
            if len(usable_donors(series, others, exclude=skip)) < k:
                problems.append("needs a neighbouring station of the same quantity" if k == 1 else "needs at least two neighbouring stations of the same quantity")
        elif need == "manual_rating":
            if not ctx.meta.get("manual_rating"):
                problems.append("no manual rating set (Rating curve page)")
        elif need == "driver":
            d = ctx.meta.get("driver")
            if d is None or others is None or d not in others.columns:
                problems.append("no driver series (stage, discharge, turbidity ...) supplied")
        elif need == "surrogate":
            d = ctx.meta.get("surrogate")
            if d is None or others is None or d not in others.columns:
                problems.append("no surrogate series (for example turbidity) supplied")
        elif need == "pair":
            if others is None or others.shape[1] == 0:
                problems.append("no paired series supplied")
    return problems


class Method:
    def __init__(self, info: MethodInfo, fn):
        self.info = info
        self.fn = fn

    def check(self, series, others=None, ctx=None) -> list:
        ctx = ctx or Ctx()
        if self.info.status != "implemented":
            return [f"status: {self.info.status}"]
        if "any" not in self.info.variables and ctx.variable not in self.info.variables and ctx.variable != "generic":
            return [f"not designed for {ctx.variable}"]
        return check_needs(self.info.needs, series, others, ctx)

    def run(self, series: pd.Series, others: pd.DataFrame | None = None, ctx: Ctx | None = None, **params) -> FillOutput:
        ctx = ctx or Ctx()
        t0 = time.time()
        kind = params.pop("transform", None)
        if kind is None:
            kind = auto_transform(ctx.variable) if self.info.transform == "auto" else "none"
        tf = Transform(kind, series)
        y = tf.fwd(series) if kind != "none" else series
        x = others
        if others is not None and kind != "none":
            x = others.apply(lambda col: tf.fwd(col))
        res = self.fn(y, x, ctx, **params)
        lo = hi = None
        if isinstance(res, tuple):
            res, lo, hi = res
        res = pd.Series(res, index=series.index, dtype=float)
        if kind != "none":
            res = pd.Series(tf.inv(res.to_numpy()), index=series.index)
            if lo is not None:
                lo = pd.Series(tf.inv(np.asarray(lo, float)), index=series.index)
                hi = pd.Series(tf.inv(np.asarray(hi, float)), index=series.index)
        lb = ctx.lower if ctx.lower is not None else (0.0 if ctx.variable in NONNEG else None)
        if lb is not None or ctx.upper is not None:
            res = res.clip(lower=lb, upper=ctx.upper)
            if lo is not None:
                lo, hi = lo.clip(lower=lb, upper=ctx.upper), hi.clip(lower=lb, upper=ctx.upper)
        res = series.where(series.notna(), res)  # never change observed values
        return FillOutput(res, lo, hi, time.time() - t0)

    def __call__(self, series, others=None, ctx=None, **params) -> pd.Series:
        return self.run(series, others, ctx, **params).values


def register(id, name, family, variables=("any",), needs=("series",), best_for=(), limits="", library="", section="",
             status="implemented", uncertainty=False, transform="auto", cost="low"):
    def deco(fn):
        info = MethodInfo(id, name, family, tuple(variables), tuple(needs), tuple(best_for), limits, library, section, status, uncertainty, transform, cost)
        REGISTRY[id] = Method(info, fn)
        return fn

    return deco


def register_planned(id, name, family, variables=("any",), best_for=(), limits="", library="", section="", status="planned"):
    REGISTRY[id] = Method(MethodInfo(id, name, family, tuple(variables), (), tuple(best_for), limits, library, section, status), None)


def get(id: str) -> Method:
    return REGISTRY[id]


def list_methods(variable: str | None = None, family: str | None = None, status: str | None = None) -> pd.DataFrame:
    rows = []
    for m in REGISTRY.values():
        i = m.info
        if family and i.family != family:
            continue
        if status and i.status != status:
            continue
        if variable and "any" not in i.variables and variable not in i.variables:
            continue
        rows.append(dict(id=i.id, name=i.name, family=i.family, variables="/".join(i.variables), needs=",".join(i.needs),
                         best_for=",".join(i.best_for), library=i.library, section=i.section, status=i.status, cost=i.cost))
    return pd.DataFrame(rows)


def applicable(series, others=None, ctx=None, ids=None) -> dict:
    """{method id: [] if it can run, else list of unmet requirements}."""
    ctx = ctx or Ctx()
    out = {}
    for mid, m in REGISTRY.items():
        if ids is not None and mid not in ids:
            continue
        out[mid] = m.check(series, others, ctx)
    return out


def fill(series, others=None, method="linear", ctx=None, **params) -> pd.Series:
    return REGISTRY[method](series, others, ctx, **params)


# ------------------------------------------------------------------------------- shared helpers


def calendar_features(index: pd.DatetimeIndex) -> pd.DataFrame:
    doy = index.dayofyear.to_numpy(float) + index.hour.to_numpy() / 24.0
    out = {"doy_sin": np.sin(2 * np.pi * doy / 365.25), "doy_cos": np.cos(2 * np.pi * doy / 365.25)}
    if steps_per_day(index) > 1.5:
        h = index.hour.to_numpy(float) + index.minute.to_numpy() / 60.0
        out["hod_sin"] = np.sin(2 * np.pi * h / 24.0)
        out["hod_cos"] = np.cos(2 * np.pi * h / 24.0)
    return pd.DataFrame(out, index=index)


def gap_edges(series: pd.Series) -> pd.DataFrame:
    """For every step: previous and next observed value and the distance (steps) to each (NaN if none)."""
    n = len(series)
    pos = np.arange(n, dtype=float)
    obs = series.notna().to_numpy()
    prev_pos = pd.Series(np.where(obs, pos, np.nan)).ffill().to_numpy()
    next_pos = pd.Series(np.where(obs, pos, np.nan)).bfill().to_numpy()
    v = series.to_numpy(float)
    prev_val = np.where(np.isfinite(prev_pos), v[np.nan_to_num(prev_pos, nan=0).astype(int)], np.nan)
    next_val = np.where(np.isfinite(next_pos), v[np.nan_to_num(next_pos, nan=0).astype(int)], np.nan)
    return pd.DataFrame(
        {"prev_val": prev_val, "next_val": next_val, "d_prev": pos - prev_pos, "d_next": next_pos - pos},
        index=series.index,
    )
