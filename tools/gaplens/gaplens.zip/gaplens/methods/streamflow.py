"""Streamflow methods (catalog section 6) and lagged regression used for water level as well (section 7)."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import optimize

from .base import register, steps_per_day
from .multistation import _donors, _stations, donor_stats, linear_regression

try:  # optional speed-up for the rainfall-runoff model
    from numba import njit
except Exception:  # pragma: no cover

    def njit(*args, **kwargs):
        if args and callable(args[0]):
            return args[0]
        return lambda f: f


# ---------------------------------------------------------------------------------- donor transfer


@register("flow_dar", "Drainage-area ratio", "streamflow", variables=("streamflow",), needs=("series", "stations", "areas"), best_for=("G3", "G5"), library="numpy", section="6.1", transform="none",
          limits="catchment areas come from the station table (column area_km2)")
def flow_dar(series, others, ctx, exponent=1.0, fit_scale=False):
    donors = _stations(ctx, series, others)
    areas = ctx.meta.get("areas_km2", {})
    donors = [d for d in donors if d in areas and ctx.target in areas]
    if not donors:
        return series
    st = donor_stats(series, others, donors)
    order = list(st.sort_values("r", ascending=False).index)
    out = series.copy()
    for c in order:
        ratio = (areas[ctx.target] / areas[c]) ** exponent
        est = others[c] * ratio
        if fit_scale:  # correct the area ratio with the long-term flow ratio on the overlap
            pair = pd.concat([series, est], axis=1).dropna()
            if len(pair) > 30 and pair.iloc[:, 1].mean() > 0:
                est = est * pair.iloc[:, 0].mean() / pair.iloc[:, 1].mean()
        out = out.fillna(est)
    return out


def best_lags(series, others, donors, max_lag, min_pairs=30):
    """Lag (steps) of each donor that maximises the correlation with the target. Positive lag: donor leads."""
    lags = {}
    y = series
    for c in donors:
        best, best_r = 0, -2.0
        for L in range(-max_lag, max_lag + 1):
            pair = pd.concat([y, others[c].shift(L)], axis=1).dropna()
            if len(pair) < min_pairs:
                continue
            r = pair.iloc[:, 0].corr(pair.iloc[:, 1])
            if np.isfinite(r) and r > best_r:
                best, best_r = L, r
        lags[c] = best
    return lags


def _lagged_others(series, others, ctx, max_lag_days, donors, positive_only=False):
    spd = steps_per_day(series.index)
    max_lag = max(1, int(round(max_lag_days * spd)))
    lags = best_lags(series, others, donors, max_lag)
    if positive_only:
        lags = {c: max(L, 0) for c, L in lags.items()}
    return pd.DataFrame({c: others[c].shift(L) for c, L in lags.items()}), lags


@register("lagged_regression", "Regression on donors with optimal lags", "multistation", needs=("series", "neighbors"), best_for=("G2", "G3", "G5", "G6"), library="numpy", section="6.1")
def lagged_regression(series, others, ctx, max_lag_days=7, max_donors=2, residual="none"):
    donors = _donors(ctx, series, others)
    if not donors:
        return series
    shifted, lags = _lagged_others(series, others, ctx, max_lag_days, donors)
    return linear_regression(series, shifted, ctx, max_donors=max_donors, residual=residual)


@register("flow_move", "Maintenance of variance extension (MOVE.1)", "streamflow", variables=("streamflow",), needs=("series", "neighbors"), best_for=("G3", "G5", "G6"), library="numpy", section="6.1")
def flow_move(series, others, ctx, max_lag_days=3):
    donors = _donors(ctx, series, others)
    if not donors:
        return series
    shifted, lags = _lagged_others(series, others, ctx, max_lag_days, donors)
    st = donor_stats(series, shifted, donors)
    out = series.copy()
    for c in list(st.sort_values("r", ascending=False).index):
        s = st.loc[c]
        if s["sd_x"] <= 0:
            continue
        est = s["mean_y"] + (s["sd_y"] / s["sd_x"]) * (shifted[c] - s["mean_x"])
        out = out.fillna(est)
    return out


@register("flow_fdc_transfer", "Flow-duration-curve transfer", "streamflow", variables=("streamflow",), needs=("series", "neighbors"), best_for=("G3", "G5", "G7"), library="numpy", section="6.1")
def flow_fdc_transfer(series, others, ctx, max_lag_days=3):
    donors = _donors(ctx, series, others)
    if not donors:
        return series
    shifted, lags = _lagged_others(series, others, ctx, max_lag_days, donors)
    st = donor_stats(series, shifted, donors)
    out = series.copy()
    for c in list(st.sort_values("r", ascending=False).index):
        pair = pd.concat([series, shifted[c]], axis=1).dropna()
        if len(pair) < 50:
            continue
        q = np.linspace(0.0, 1.0, 201)
        qy, qx = np.quantile(pair.iloc[:, 0], q), np.quantile(pair.iloc[:, 1], q)
        qx_u, idx = np.unique(qx, return_index=True)
        est = np.interp(shifted[c].to_numpy(float), qx_u, qy[idx])
        est = pd.Series(est, index=series.index).where(shifted[c].notna())
        out = out.fillna(est)
    return out


@register("flow_lagged_routing", "Lagged routing from an upstream gauge", "streamflow", variables=("streamflow",), needs=("series", "neighbors"), best_for=("G2", "G3"), library="numpy", section="6.1")
def flow_lagged_routing(series, others, ctx, max_lag_days=7):
    donors = _donors(ctx, series, others)
    if not donors:
        return series
    shifted, lags = _lagged_others(series, others, ctx, max_lag_days, donors, positive_only=True)
    return linear_regression(series, shifted, ctx, max_donors=1)


@register("flow_recession", "Master recession curve fill", "streamflow", variables=("streamflow",), needs=("series", "years>=2"), best_for=("G2", "G3"), library="numpy", section="6.3", transform="none")
def flow_recession(series, others, ctx):
    y = series.to_numpy(float)
    n = len(y)
    obs = np.isfinite(y)
    pair = obs[1:] & obs[:-1]
    q0, q1 = y[:-1][pair], y[1:][pair]
    rec = (q1 < q0) & (q0 > 0) & (q1 > 0)
    if rec.sum() < 30:
        return series
    ratio = q1[rec] / q0[rec]
    k = float(np.clip(np.median(ratio[ratio < 1.0]), 0.5, 0.999))  # daily recession factor
    base = float(np.nanquantile(y, 0.05))
    est = y.copy()
    from ..gaps.result import find_runs

    s0, ln = find_runs(~obs)
    for s, L in zip(s0, ln):
        e = s + L
        qs = y[s - 1] if s > 0 else np.nan
        qe = y[e] if e < n else np.nan
        t = np.arange(1, L + 1)
        if np.isfinite(qs):
            rec_curve = np.maximum(base, qs * k**t)
            if np.isfinite(qe):
                end_rec = max(base, qs * k ** (L + 1))
                corr = np.log(max(qe, 1e-9)) - np.log(max(end_rec, 1e-9))
                w = t / (L + 1.0)
                curve = np.exp(np.log(rec_curve) + w * corr)
            else:
                curve = rec_curve
        elif np.isfinite(qe):
            curve = np.full(L, qe)
        else:
            continue
        est[s:e] = curve
    return pd.Series(est, index=series.index)


@register("flow_seasonal_percentile", "Seasonal flow percentile fill", "streamflow", variables=("streamflow",), needs=("series", "years>=5"), best_for=("G3", "G4"), library="pandas", section="6.3")
def flow_seasonal_percentile(series, others, ctx, q=0.5, window_days=15):
    spd = steps_per_day(series.index)
    doy = series.index.dayofyear.to_numpy()
    obs = series.dropna()
    odoy = obs.index.dayofyear.to_numpy()
    clim = {}
    half = int(window_days // 2)
    vals = obs.to_numpy()
    for d in range(1, 367):
        dist = np.abs(((odoy - d + 183) % 366) - 183)
        sel = vals[dist <= half]
        clim[d] = np.quantile(sel, q) if len(sel) else np.nan
    est = pd.Series([clim[d] for d in doy], index=series.index)
    return series.where(series.notna(), est).interpolate(limit_direction="both")


# ---------------------------------------------------------------------------------- GR4J


@njit(cache=False)
def _sh1(t, x4):
    if t <= 0.0:
        return 0.0
    if t < x4:
        return (t / x4) ** 2.5
    return 1.0


@njit(cache=False)
def _sh2(t, x4):
    if t <= 0.0:
        return 0.0
    if t < x4:
        return 0.5 * (t / x4) ** 2.5
    if t < 2.0 * x4:
        return 1.0 - 0.5 * (2.0 - t / x4) ** 2.5
    return 1.0


@njit(cache=False)
def gr4j_run(P, E, x1, x2, x3, x4):
    """Daily GR4J (Perrin et al. 2003). P, E in mm/day; returns discharge in mm/day."""
    n = len(P)
    Q = np.zeros(n)
    nh1 = int(np.ceil(x4))
    nh2 = int(np.ceil(2.0 * x4))
    uh1 = np.zeros(nh1)
    uh2 = np.zeros(nh2)
    for i in range(1, nh1 + 1):
        uh1[i - 1] = _sh1(float(i), x4) - _sh1(float(i - 1), x4)
    for i in range(1, nh2 + 1):
        uh2[i - 1] = _sh2(float(i), x4) - _sh2(float(i - 1), x4)
    st1 = np.zeros(nh1)
    st2 = np.zeros(nh2)
    S = 0.3 * x1
    R = 0.5 * x3
    for t in range(n):
        p = P[t]
        e = E[t]
        if p >= e:
            pn = p - e
            en = 0.0
        else:
            pn = 0.0
            en = e - p
        ps = 0.0
        es = 0.0
        if pn > 0.0:
            tn = np.tanh(pn / x1)
            ps = x1 * (1.0 - (S / x1) ** 2) * tn / (1.0 + (S / x1) * tn)
        else:
            te = np.tanh(en / x1)
            es = S * (2.0 - S / x1) * te / (1.0 + (1.0 - S / x1) * te)
        S = S - es + ps
        if S < 0.0:
            S = 0.0
        if S > x1:
            S = x1
        perc = S * (1.0 - (1.0 + (4.0 * S / (9.0 * x1)) ** 4) ** (-0.25))
        S = S - perc
        pr = perc + (pn - ps)
        for k in range(nh1 - 1):
            st1[k] = st1[k + 1] + uh1[k] * 0.9 * pr
        st1[nh1 - 1] = uh1[nh1 - 1] * 0.9 * pr
        for k in range(nh2 - 1):
            st2[k] = st2[k + 1] + uh2[k] * 0.1 * pr
        st2[nh2 - 1] = uh2[nh2 - 1] * 0.1 * pr
        q9 = st1[0]
        q1 = st2[0]
        f = x2 * (R / x3) ** 3.5
        R = R + q9 + f
        if R < 0.0:
            R = 0.0
        qr = R * (1.0 - (1.0 + (R / x3) ** 4) ** (-0.25))
        R = R - qr
        qd = q1 + f
        if qd < 0.0:
            qd = 0.0
        Q[t] = qr + qd
    return Q


def _pet_default(index, mean_mm=3.5, amp=0.5):
    doy = index.dayofyear.to_numpy(float)
    return mean_mm * (1.0 + amp * np.cos(2 * np.pi * (doy - 120.0) / 365.25))


def calibrate_gr4j(P, E, q_obs, warmup=365, seed=0, maxiter=18, popsize=8):
    """Fit GR4J parameters (X1..X4) and a volume scale to observed flow (NSE of Q and log Q). Returns (params, scale)."""
    ok = np.isfinite(q_obs)
    use = ok.copy()
    use[:warmup] = False
    if use.sum() < 200:
        use = ok

    def obj(theta):
        x1, x2, x3, x4 = np.exp(theta[0]), theta[1], np.exp(theta[2]), theta[3]
        sim = gr4j_run(P, E, x1, x2, x3, x4)
        s, o = sim[use], q_obs[use]
        den = np.sum(s * s)
        if den <= 0:
            return 10.0
        k = np.sum(s * o) / den
        sk = s * k
        nse = 1 - np.sum((sk - o) ** 2) / np.sum((o - o.mean()) ** 2)
        eps = 0.01 * o.mean()
        lo_, ls_ = np.log(o + eps), np.log(sk + eps)
        lnse = 1 - np.sum((ls_ - lo_) ** 2) / np.sum((lo_ - lo_.mean()) ** 2)
        return -(0.5 * nse + 0.5 * lnse)

    bounds = [(np.log(20), np.log(1500)), (-4.0, 4.0), (np.log(10), np.log(400)), (0.6, 4.0)]
    res = optimize.differential_evolution(obj, bounds, seed=seed, maxiter=maxiter, popsize=popsize, tol=1e-4, polish=False)
    x1, x2, x3, x4 = np.exp(res.x[0]), res.x[1], np.exp(res.x[2]), res.x[3]
    sim = gr4j_run(P, E, x1, x2, x3, x4)
    k = float(np.sum(sim[use] * q_obs[use]) / max(np.sum(sim[use] ** 2), 1e-12))
    return (x1, x2, x3, x4), k


def _gr4j_series(series, ctx):
    precip = ctx.meta.get("precip")
    if precip is None:
        return None
    P = precip.reindex(series.index).interpolate(limit_direction="both").fillna(0.0).to_numpy(float)
    pet = ctx.meta.get("pet")
    E = pet.reindex(series.index).interpolate(limit_direction="both").to_numpy(float) if pet is not None else _pet_default(series.index)
    return P, E


@register("flow_gr4j", "GR4J daily rainfall-runoff model", "streamflow", variables=("streamflow",), needs=("series", "forcing", "years>=2"), best_for=("G3", "G4", "G5"), library="numpy (numba optional)", section="6.2", transform="none", cost="high")
def flow_gr4j(series, others, ctx, maxiter=18, popsize=8):
    pe = _gr4j_series(series, ctx)
    if pe is None:
        return series
    P, E = pe
    params, k = calibrate_gr4j(P, E, series.to_numpy(float), seed=ctx.seed, maxiter=maxiter, popsize=popsize)
    sim = gr4j_run(P, E, *params) * k
    return series.where(series.notna(), pd.Series(sim, index=series.index))


@register("flow_gr4j_errcorr", "GR4J with error correction from the gap edges", "streamflow", variables=("streamflow",), needs=("series", "forcing", "years>=2"), best_for=("G2", "G3"), library="numpy (numba optional)", section="6.2", transform="none", cost="high")
def flow_gr4j_errcorr(series, others, ctx, maxiter=18, popsize=8):
    pe = _gr4j_series(series, ctx)
    if pe is None:
        return series
    P, E = pe
    y = series.to_numpy(float)
    params, k = calibrate_gr4j(P, E, y, seed=ctx.seed, maxiter=maxiter, popsize=popsize)
    sim = gr4j_run(P, E, *params) * k
    eps = 0.01 * np.nanmean(y)
    r = np.log(np.maximum(y, 0) + eps) - np.log(sim + eps)
    obs = np.isfinite(y)
    rr = r[obs]
    phi = float(np.clip(np.corrcoef(rr[:-1], rr[1:])[0, 1], 0.0, 0.995)) if len(rr) > 10 else 0.8
    n = len(y)
    pos = np.arange(n, dtype=float)
    prev_pos = pd.Series(np.where(obs, pos, np.nan)).ffill().to_numpy()
    next_pos = pd.Series(np.where(obs, pos, np.nan)).bfill().to_numpy()
    idx_prev = np.nan_to_num(prev_pos, nan=0).astype(int)
    idx_next = np.nan_to_num(next_pos, nan=0).astype(int)
    a = np.where(np.isfinite(prev_pos), phi ** (pos - prev_pos), 0.0)
    b = np.where(np.isfinite(next_pos), phi ** (next_pos - pos), 0.0)
    num = a * np.where(np.isfinite(prev_pos), r[idx_prev], 0.0) + b * np.where(np.isfinite(next_pos), r[idx_next], 0.0)
    den = np.maximum(a + b, 1e-12)
    # weights a,b are already the decayed fractions; scale so the correction vanishes far from both edges
    corr = num / np.maximum(1.0, a + b)
    est = np.maximum(np.exp(np.log(sim + eps) + corr) - eps, 0.0)
    return series.where(series.notna(), pd.Series(est, index=series.index))


@register("wl_slope_interpolation", "Water-surface slope interpolation between two gauges", "waterlevel", variables=("stage", "streamflow"), needs=("series", "stations>=2", "coords"), best_for=("G2", "G3"), library="numpy", section="7", transform="none")
def wl_slope_interpolation(series, others, ctx, max_lag_days=3):
    donors = _stations(ctx, series, others, min_corr=0.5)
    if len(donors) < 2:
        return series
    shifted, lags = _lagged_others(series, others, ctx, max_lag_days, donors)
    xy = ctx.coords
    d = {c: float(np.hypot(*(xy.loc[c, ["x_km", "y_km"]].to_numpy(float) - xy.loc[ctx.target, ["x_km", "y_km"]].to_numpy(float)))) for c in donors}
    pick = sorted(donors, key=lambda c: d[c])[:2]
    w = np.array([1.0 / max(d[c], 1e-6) for c in pick])
    w = w / w.sum()
    comb = shifted[pick[0]] * w[0] + shifted[pick[1]] * w[1]
    pair = pd.concat([series, comb], axis=1).dropna()
    if len(pair) < 30:
        return series
    A = np.column_stack([np.ones(len(pair)), pair.iloc[:, 1]])
    beta, *_ = np.linalg.lstsq(A, pair.iloc[:, 0], rcond=None)
    est = beta[0] + beta[1] * comb
    return series.where(series.notna(), est)
