"""Tidal water level methods (catalog section 10).

A tidal record is a mean level, a tide made of harmonic constituents, and a non-tidal residual (surge, river flow, seasonal level).
A gap is filled by predicting the tide from constituents fitted to the observed part and then filling the residual separately.

What the observed record can resolve is decided by the Rayleigh criterion: two constituents can be separated only if the record is
longer than one beat period, 360 / (difference in speed, degrees per hour) hours. `resolvability()` reports this; the fit uses
only constituents that pass it, in order of importance.

Time is taken from the index (any step). `ctx.meta["driver"]` names a river-discharge column for the nonstationary variant.
"""

from __future__ import annotations

import importlib.util
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .base import gap_edges, register, register_planned

# speed in degrees per hour
SPEEDS = {
    "Sa": 0.0410686, "Ssa": 0.0821373, "MSm": 0.4715211, "Mm": 0.5443747, "MSf": 1.0158958, "Mf": 1.0980331,
    "2Q1": 12.8542862, "Q1": 13.3986609, "O1": 13.9430356, "P1": 14.9589314, "S1": 15.0, "K1": 15.0410686, "J1": 15.5854433, "OO1": 16.1391017,
    "2N2": 27.8953548, "MU2": 27.9682084, "N2": 28.4397295, "NU2": 28.5125831, "M2": 28.9841042, "L2": 29.5284789, "T2": 29.9589333,
    "S2": 30.0, "K2": 30.0821373, "MN4": 57.4238337, "M4": 57.9682084, "MS4": 58.9841042, "S4": 60.0, "M6": 86.9523127,
}
# order of importance for ordinary tides: a constituent is kept if the record separates it from every constituent kept before it
PRIORITY = ["M2", "S2", "N2", "K1", "O1", "M4", "K2", "P1", "Q1", "MS4", "MN4", "2N2", "MU2", "NU2", "L2", "T2", "J1", "OO1", "M6", "S4", "Mf", "Mm", "MSf", "Sa", "Ssa"]
MODULATED = ("M2", "S2", "N2", "K2", "M4", "MS4", "K1", "O1")  # constituents whose amplitude may change with river flow


def node_longitude(index: pd.DatetimeIndex) -> np.ndarray:
    d = ((index - pd.Timestamp("2000-01-01 12:00")) / pd.Timedelta(days=1)).to_numpy()
    return np.radians((125.04452 - 0.05295377 * d) % 360.0)


def nodal_fu(name: str, N: np.ndarray):
    """Nodal amplitude factor f and phase correction u (radians) for the main constituents; others are unchanged."""
    c, sn = np.cos(N), np.sin(N)
    if name in ("M2", "N2", "MU2", "NU2", "2N2", "L2"):
        return 1.0004 - 0.0373 * c, np.radians(-2.14) * sn
    if name == "K1":
        return 1.006 + 0.115 * c, np.radians(-8.86) * sn
    if name in ("O1", "Q1", "J1", "2Q1"):
        return 1.009 + 0.187 * c, np.radians(10.80) * sn
    if name == "K2":
        return 1.024 + 0.286 * c, np.radians(-17.74) * sn
    if name == "M4":
        f, u = nodal_fu("M2", N)
        return f**2, 2 * u
    if name in ("MS4", "MN4"):
        return nodal_fu("M2", N)
    return np.ones_like(N), np.zeros_like(N)


def _hours(index: pd.DatetimeIndex, t0: pd.Timestamp) -> np.ndarray:
    return np.asarray((index - t0) / pd.Timedelta(hours=1), float)


def design(index: pd.DatetimeIndex, t0: pd.Timestamp, names, nodal: bool = True, qn: np.ndarray | None = None, modulated=()) -> tuple[np.ndarray, list]:
    """Columns: constant, then cos and sin of every constituent (with nodal f and u), then river terms if qn is given."""
    t = _hours(index, t0)
    N = node_longitude(index)
    cols = [np.ones(len(t))]
    labels = ["z0"]
    if qn is not None:
        cols += [qn, qn**2]
        labels += ["q", "q2"]
    for nm in names:
        f, u = nodal_fu(nm, N) if nodal else (np.ones_like(N), np.zeros_like(N))
        arg = np.radians(SPEEDS[nm]) * t + u
        cols += [f * np.cos(arg), f * np.sin(arg)]
        labels += [f"{nm}_c", f"{nm}_s"]
    if qn is not None:
        for nm in modulated:
            f, u = nodal_fu(nm, N) if nodal else (np.ones_like(N), np.zeros_like(N))
            arg = np.radians(SPEEDS[nm]) * t + u
            cols += [qn * f * np.cos(arg), qn * f * np.sin(arg)]
            labels += [f"{nm}_qc", f"{nm}_qs"]
    return np.column_stack(cols), labels


# ----------------------------------------------------------------------------- resolvability (Rayleigh)


def record_lengths(series: pd.Series) -> dict:
    """Observed hours (count of valid steps x step), span, and the longest continuous stretch in hours."""
    obs = series.notna().to_numpy()
    step_h = float(pd.Series(series.index).diff().median() / pd.Timedelta(hours=1))
    n_obs = int(obs.sum())
    if n_obs == 0:
        return dict(step_hours=step_h, observed_hours=0.0, span_hours=0.0, longest_continuous_hours=0.0)
    idx = series.index[obs]
    span = float((idx[-1] - idx[0]) / pd.Timedelta(hours=1)) + step_h
    padded = np.concatenate([[False], obs, [False]])
    ch = np.flatnonzero(padded[1:] != padded[:-1])
    longest = float((ch[1::2] - ch[0::2]).max()) * step_h
    return dict(step_hours=step_h, observed_hours=n_obs * step_h, span_hours=span, longest_continuous_hours=longest)


def select_constituents(record_hours: float, step_hours: float = 1.0, candidates=None, rayleigh: float = 1.0):
    """Constituents the record can separate, in priority order, and a table that says why the others were dropped."""
    names = [n for n in (candidates or PRIORITY) if n in SPEEDS]
    nyquist_deg = 180.0 / max(step_hours, 1e-9)  # degrees per hour
    kept, rows = [], []
    for nm in names:
        sp = SPEEDS[nm]
        if sp >= 0.9 * nyquist_deg:
            rows.append(dict(constituent=nm, speed_deg_h=sp, used=False, partner="", needs_days=np.nan, reason="above the Nyquist speed of this time step"))
            continue
        others = kept + [None]
        gap = min([abs(sp - SPEEDS[k]) for k in kept] + [sp])  # separation from every kept constituent and from zero
        partner = ""
        if kept:
            near = min(kept, key=lambda k: abs(sp - SPEEDS[k]))
            partner = near if abs(sp - SPEEDS[near]) <= sp else "mean"
        need_h = rayleigh * 360.0 / max(gap, 1e-9)
        ok = record_hours >= need_h
        rows.append(dict(constituent=nm, speed_deg_h=sp, used=bool(ok), partner=partner, needs_days=need_h / 24.0,
                         reason="" if ok else f"record shorter than the beat with {partner or 'the mean'} ({need_h / 24:.0f} days needed)"))
        if ok:
            kept.append(nm)
    return kept, pd.DataFrame(rows)


def resolvability(series: pd.Series, rayleigh: float = 1.0) -> pd.DataFrame:
    """Report of section 10.1: which constituents the observed record resolves, with the record length each one needs."""
    rl = record_lengths(series)
    _, table = select_constituents(rl["observed_hours"], rl["step_hours"], rayleigh=rayleigh)
    table.attrs.update(rl)
    return table


def tidal_gap_report(series: pd.Series) -> pd.DataFrame:
    """Every gap with its length in tidal units (catalog 1.4): M2 cycles and the share of a spring-neap cycle."""
    obs = series.isna().to_numpy()
    step_h = float(pd.Series(series.index).diff().median() / pd.Timedelta(hours=1))
    padded = np.concatenate([[False], obs, [False]])
    ch = np.flatnonzero(padded[1:] != padded[:-1])
    rows = []
    for a, b in zip(ch[0::2], ch[1::2]):
        h = (b - a) * step_h
        rows.append(dict(start=series.index[a], steps=int(b - a), hours=h, m2_cycles=h / 12.42, spring_neap_share=h / (14.77 * 24.0)))
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- fit and predict


@dataclass
class TideFit:
    names: list
    labels: list
    coef: np.ndarray
    t0: pd.Timestamp
    nodal: bool
    sigma: float
    cov_diag: np.ndarray
    modulated: tuple = ()
    river: bool = False
    qmax: float = 1.0
    table_notes: list = field(default_factory=list)

    def predict(self, index: pd.DatetimeIndex, q: pd.Series | None = None) -> np.ndarray:
        qn = None
        if self.river:
            qn = np.clip(np.asarray(q.reindex(index), float) / self.qmax, 0.0, 1.5)
        X, _ = design(index, self.t0, self.names, self.nodal, qn, self.modulated)
        return X @ self.coef

    def table(self) -> pd.DataFrame:
        """Amplitude, Greenwich-free phase (relative to the first time step) and a 95 percent interval on the amplitude."""
        rows = []
        for k, nm in enumerate(self.names):
            i = 1 + (2 if self.river else 0) + 2 * k
            c, s = self.coef[i], self.coef[i + 1]
            amp = float(np.hypot(c, s))
            se = float(self.sigma * np.sqrt(0.5 * (self.cov_diag[i] + self.cov_diag[i + 1])))
            rows.append(dict(constituent=nm, speed_deg_h=SPEEDS[nm], amplitude=amp, phase_deg=float(np.degrees(np.arctan2(s, c))), amp_ci95=1.96 * se))
        return pd.DataFrame(rows).set_index("constituent")


def fit_tide(series: pd.Series, q: pd.Series | None = None, nodal: bool = True, names=None, min_obs_hours: float = 48.0, ridge: float = 1e-8) -> TideFit:
    obs = series.notna().to_numpy()
    rl = record_lengths(series)
    if rl["observed_hours"] < min_obs_hours:
        raise ValueError(f"only {rl['observed_hours']:.0f} observed hours: too short for a harmonic fit")
    if names is None:
        names, _ = select_constituents(rl["observed_hours"], rl["step_hours"])
    t0 = series.index[0]
    qn = modulated = None
    qmax = 1.0
    if q is not None:
        qmax = float(np.nanmax(q.to_numpy(float)))
        qn = np.clip(np.asarray(q.reindex(series.index), float) / max(qmax, 1e-9), 0.0, 1.5)
        qn = np.where(np.isfinite(qn), qn, np.nanmean(qn))
        modulated = tuple(m for m in MODULATED if m in names)
    X, labels = design(series.index, t0, names, nodal, qn, modulated or ())
    Xo, yo = X[obs], series.to_numpy(float)[obs]
    A = Xo.T @ Xo + ridge * np.eye(Xo.shape[1]) * len(yo)
    coef = np.linalg.solve(A, Xo.T @ yo)
    r = yo - Xo @ coef
    dof = max(len(yo) - Xo.shape[1], 1)
    sigma = float(np.sqrt(np.sum(r**2) / dof))
    cov_diag = np.diag(np.linalg.inv(A))
    return TideFit(list(names), labels, coef, t0, nodal, sigma, cov_diag, tuple(modulated or ()), q is not None, qmax)


def _ar1_bridge(resid: pd.Series, phi: float | None = None) -> pd.Series:
    """Conditional mean of an AR(1) process between the observed residuals on both sides of every gap (one side at the ends)."""
    r = resid.copy()
    if phi is None:
        a, b = r.to_numpy()[1:], r.to_numpy()[:-1]
        ok = np.isfinite(a) & np.isfinite(b)
        phi = float(np.corrcoef(a[ok], b[ok])[0, 1]) if ok.sum() > 50 else 0.9
    phi = float(np.clip(phi, 0.0, 0.9995))
    e = gap_edges(r)
    dp, dn = e["d_prev"].to_numpy(), e["d_next"].to_numpy()
    rp, rn = e["prev_val"].to_numpy(), e["next_val"].to_numpy()
    out = np.zeros(len(r))
    both = np.isfinite(dp) & np.isfinite(dn)
    only_p = np.isfinite(dp) & ~np.isfinite(dn)
    only_n = ~np.isfinite(dp) & np.isfinite(dn)
    with np.errstate(all="ignore"):
        ap, an = phi**dp, phi**dn
        den = 1.0 - phi ** (2 * (dp + dn))
        out[both] = ((ap * (1 - phi ** (2 * dn)) * rp + an * (1 - phi ** (2 * dp)) * rn) / den)[both]
    out[only_p] = (phi ** dp * rp)[only_p]
    out[only_n] = (phi ** dn * rn)[only_n]
    return pd.Series(np.nan_to_num(out), index=r.index)


def _fill_with(fit: TideFit, series: pd.Series, q=None, residual: bool = True) -> pd.Series:
    tide = pd.Series(fit.predict(series.index, q), index=series.index)
    est = tide.copy()
    if residual:
        res = (series - tide)
        est = tide + _ar1_bridge(res)
    return series.where(series.notna(), est)


# ----------------------------------------------------------------------------- registered methods

TIDE = dict(variables=("tide",), library="numpy", transform="none")


@register("tide_harmonic", "Harmonic analysis with Rayleigh-selected constituents (tide only)", "tidal", needs=("series",), best_for=("T1", "T2"), section="10.3", limits="Fixed amplitudes; the non-tidal residual is not filled", **TIDE)
def tide_harmonic(series, others, ctx):
    fit = fit_tide(series)
    return _fill_with(fit, series, residual=False)


@register("tide_harmonic_ar", "Harmonic tide plus AR(1) bridge of the residual", "tidal", needs=("series",), best_for=("T1", "T2"), section="10.3", limits="Residual fades to zero in long gaps", **TIDE)
def tide_harmonic_ar(series, others, ctx):
    fit = fit_tide(series)
    return _fill_with(fit, series, residual=True)


@register("tide_harmonic_river", "Nonstationary harmonic analysis with river discharge as a predictor", "tidal", needs=("series", "driver"), best_for=("T3", "T5"), section="10.3", limits="More parameters; needs discharge across the gap", cost="medium", **TIDE)
def tide_harmonic_river(series, others, ctx):
    q = others[ctx.meta["driver"]]
    fit = fit_tide(series, q=q)
    return _fill_with(fit, series, q=q, residual=True)


@register("tide_harmonic_nonodal", "Harmonic tide plus AR(1) residual without nodal corrections", "tidal", needs=("series",), best_for=("T1", "T2"), section="10.3", **TIDE)
def tide_harmonic_nonodal(series, others, ctx):
    fit = fit_tide(series, nodal=False)
    return _fill_with(fit, series, residual=True)


if importlib.util.find_spec("utide") is not None:

    @register("tide_utide", "UTide harmonic analysis (Codiga 2011) with AR(1) residual bridge", "tidal", needs=("series",), best_for=("T1", "T2", "T3"), section="10.3", limits="Automatic constituent selection depends on latitude", **{**TIDE, "library": "utide"})
    def tide_utide(series, others, ctx):
        import utide

        lat = float(ctx.meta.get("latitude", 30.0))
        obs = series.notna().to_numpy()
        t = series.index.to_numpy()
        y = np.ma.masked_invalid(series.to_numpy(float))
        coef = utide.solve(t, y, lat=lat, method="ols", conf_int="none", trend=False, nodal=True, verbose=False, constit="auto")
        rec = utide.reconstruct(t, coef, verbose=False)
        tide = pd.Series(np.asarray(rec.h, float), index=series.index)
        res = series - tide
        return series.where(series.notna(), tide + _ar1_bridge(res))

else:
    register_planned("tide_utide", "UTide harmonic analysis (Codiga 2011)", "tidal", variables=("tide",), best_for=("T1", "T2", "T3"), section="10.3", status="unavailable")

register_planned("tide_inference", "Constituent inference from a partner or neighbour station", "tidal", variables=("tide",), best_for=("T3",), section="10.3")
register_planned("tide_response", "Response method (Munk and Cartwright 1966)", "tidal", variables=("tide",), best_for=("T3",), section="10.3")
register_planned("tide_neighbor_transfer", "Neighbour transfer function (amplitude and phase shift)", "tidal", variables=("tide",), best_for=("T2", "T3"), section="10.3")
