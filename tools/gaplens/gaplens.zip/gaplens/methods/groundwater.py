"""Groundwater head methods (catalog section 11): models of the response to rainfall, with the residual bridged between the gap edges.

`ctx.meta["driver"]` names the rainfall column of `others`. Levels respond slowly, so a residual that is still large at the
edge of a gap decays towards the model over its own autocorrelation time (an AR(1) bridge, as in the tidal module).
"""

from __future__ import annotations

import importlib.util

import numpy as np
import pandas as pd
from scipy.signal import lfilter

from .base import calendar_features, register, register_planned, steps_per_day
from .tidal import _ar1_bridge

GW = dict(variables=("groundwater",), library="numpy, scipy", section="11")


def _rain(others, ctx, series):
    r = others[ctx.meta["driver"]].reindex(series.index)
    return r.interpolate(limit_direction="both").fillna(0.0).to_numpy(float)


def _finish(series, model_pred, bridge=True):
    pred = pd.Series(model_pred, index=series.index)
    est = pred + _ar1_bridge(series - pred) if bridge else pred
    return series.where(series.notna(), est)


@register("gw_exp_response", "Exponential recharge response (transfer function-noise, own fit) with AR(1) residual bridge", "groundwater", needs=("series", "driver", "years>=2"), best_for=("G2", "G3"), limits="Needs rainfall across the gap and a calibration period", cost="medium", transform="none", **GW)
def gw_exp_response(series, others, ctx, taus=(10, 20, 40, 60, 90, 140, 220), thresholds=(0.0, 3.0, 6.0, 10.0, 15.0)):
    p = _rain(others, ctx, series)
    spd = steps_per_day(series.index)
    obs = series.notna().to_numpy()
    if obs.sum() < 60:
        return series
    t = np.arange(len(series)) / (365.25 * spd)
    y = series.to_numpy(float)
    best = None
    for tau in taus:
        a = np.exp(-1.0 / (tau * spd))
        for th in thresholds:
            x = lfilter([1.0 - a], [1.0, -a], np.maximum(p - th, 0.0))
            X = np.column_stack([np.ones(len(y)), t, x])
            beta, *_ = np.linalg.lstsq(X[obs], y[obs], rcond=None)
            sse = float(np.sum((y[obs] - X[obs] @ beta) ** 2))
            if best is None or sse < best[0]:
                best = (sse, X @ beta)
    return _finish(series, best[1])


@register("gw_distributed_lag", "Distributed-lag regression on rainfall sums with AR(1) residual bridge", "groundwater", needs=("series", "driver", "years>=2"), best_for=("G2", "G3"), limits="Linear response only", transform="none", **GW)
def gw_distributed_lag(series, others, ctx, windows_days=(7, 30, 90, 180, 365), alpha=1.0):
    p = pd.Series(_rain(others, ctx, series), index=series.index)
    spd = steps_per_day(series.index)
    feats = pd.DataFrame({f"p{w}": p.rolling(max(int(w * spd), 1), min_periods=1).sum() / w for w in windows_days}, index=series.index)
    feats["trend"] = np.arange(len(series)) / (365.25 * spd)
    X = feats.to_numpy(float)
    mu, sd = X.mean(axis=0), X.std(axis=0) + 1e-9
    Z = np.column_stack([np.ones(len(X)), (X - mu) / sd])
    obs = series.notna().to_numpy()
    if obs.sum() < 60:
        return series
    A = Z[obs].T @ Z[obs] + alpha * np.eye(Z.shape[1])
    beta = np.linalg.solve(A, Z[obs].T @ series.to_numpy(float)[obs])
    return _finish(series, Z @ beta)


@register("gw_seasonal_ar", "Seasonal harmonics plus trend with AR(1) residual bridge", "groundwater", needs=("series", "years>=2"), best_for=("G2", "G3"), limits="Ignores external drivers", transform="none", **GW)
def gw_seasonal_ar(series, others, ctx):
    cal = calendar_features(series.index)
    t = np.arange(len(series)) / (365.25 * steps_per_day(series.index))
    X = np.column_stack([np.ones(len(series)), t, cal["doy_sin"], cal["doy_cos"]])
    obs = series.notna().to_numpy()
    beta, *_ = np.linalg.lstsq(X[obs], series.to_numpy(float)[obs], rcond=None)
    return _finish(series, X @ beta)


if importlib.util.find_spec("pastas") is not None:

    @register("gw_pastas", "Pastas transfer function-noise model (Collenteur et al. 2019) with AR(1) residual bridge", "groundwater", needs=("series", "driver", "years>=2"), best_for=("G2", "G3"), limits="Needs rainfall across the gap and a calibration period", cost="high", transform="none", **{**GW, "library": "pastas"})
    def gw_pastas(series, others, ctx):
        import pastas as ps

        prec = pd.Series(_rain(others, ctx, series), index=series.index, name="prec")
        ps.set_log_level("ERROR") if hasattr(ps, "set_log_level") else None
        obs = series.dropna().rename("head")
        ml = ps.Model(obs)
        ml.add_stressmodel(ps.StressModel(prec, rfunc=ps.Exponential(), name="rain", settings="prec"))
        try:
            ml.solve(report=False, noise=False)  # Pastas before 1.5
        except TypeError:  # Pastas 1.5 and later: the noise model is part of the model, remove it to solve without
            if hasattr(ml, "del_noisemodel"):
                ml.del_noisemodel()
            ml.solve(report=False)
        sim = ml.simulate(tmin=series.index[0], tmax=series.index[-1])
        return _finish(series, sim.reindex(series.index).interpolate(limit_direction="both").to_numpy(float))

else:
    register_planned("gw_pastas", "Pastas transfer function-noise model (Collenteur et al. 2019)", "groundwater", variables=("groundwater",), best_for=("G2", "G3"), section="11", status="unavailable")

register_planned("gw_neighbor_wells", "Regression on neighbouring wells", "groundwater", variables=("groundwater",), best_for=("G3", "G5"), section="11")
register_planned("gw_kriging_space_time", "Kriging in space with time as a co-variable", "groundwater", variables=("groundwater",), best_for=("G3", "G8"), section="11")
