"""Rainfall methods (catalog section 4). Rainfall is zero-inflated, so no transform is applied."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

from .base import calendar_features, register
from .multistation import _donors, donor_stats


def _donor_matrix(series, others, ctx, max_donors=6, min_corr=0.1):
    donors = _donors(ctx, series, others, min_corr=min_corr)
    if not donors:
        return [], None
    st = donor_stats(series, others, donors)
    pick = list(st.sort_values("r", ascending=False).index[:max_donors])
    return pick, others[pick]


@register("rain_two_step", "Two-step wet/dry then amount", "rainfall", variables=("rainfall",), needs=("series", "neighbors"), best_for=("G1", "G2", "G3"), library="scikit-learn", section="4.1", transform="none", cost="medium")
def rain_two_step(series, others, ctx, mode="threshold", max_donors=6, thr=None):
    from sklearn.linear_model import LogisticRegression, Ridge

    thr = ctx.wet_threshold if thr is None else thr
    pick, X = _donor_matrix(series, others, ctx, max_donors)
    if not pick:
        return series
    V = X.to_numpy(float)
    avail = np.isfinite(V)
    amount = np.nanmean(np.where(avail, V, np.nan), axis=1)
    amount = np.nan_to_num(amount, nan=0.0)
    wet_frac = np.where(avail.sum(axis=1) > 0, (np.where(avail, V, 0.0) >= thr).sum(axis=1) / np.maximum(avail.sum(axis=1), 1), 0.0)
    cal = calendar_features(series.index)[["doy_sin", "doy_cos"]].to_numpy()
    wet_each = np.where(avail, (np.nan_to_num(V) >= thr).astype(float), wet_frac[:, None])
    F = np.column_stack([wet_each, np.log1p(np.where(avail, np.nan_to_num(V), amount[:, None])), wet_frac, np.log1p(amount), cal])
    y = series.to_numpy(float)
    obs = np.isfinite(y)
    if obs.sum() < 50:
        return series
    wet = y >= thr
    clf = LogisticRegression(max_iter=300, C=1.0)
    clf.fit(F[obs], wet[obs])
    p_all = clf.predict_proba(F)[:, 1]
    freq = wet[obs].mean()
    cut = float(np.quantile(p_all[obs], 1 - freq)) if 0 < freq < 1 else 0.5
    if mode == "stochastic":
        occ = ctx.rng(21).random(len(y)) < p_all
    else:
        occ = p_all >= cut
    tr = obs & wet
    if tr.sum() < 20:
        return series
    reg = Ridge(alpha=1.0)
    reg.fit(F[tr], np.log(y[tr]))
    resid = np.log(y[tr]) - reg.predict(F[tr])
    smear = float(np.mean(np.exp(resid)))
    amt = np.exp(reg.predict(F)) * smear
    est = np.where(occ, np.maximum(amt, thr), 0.0)
    return series.where(series.notna(), pd.Series(est, index=series.index))


def _nscore(x: pd.Series) -> pd.Series:
    obs = x.dropna()
    u = (obs.rank(method="average") - 0.5) / len(obs)
    return pd.Series(stats.norm.ppf(u), index=obs.index, name=x.name).reindex(x.index)


@register("rain_simolo", "Distribution-preserving neighbour method", "rainfall", variables=("rainfall",), needs=("series", "neighbors"), best_for=("G1", "G2", "G3"),
          limits="Keeps the distribution of the target (normal-score combination of the donors, mapped back with the target's quantiles) at the price of a larger error; in the benchmark its RMSE is above that of scaled or regression-type fills. A simplified method in the spirit of Simolo et al., not a replica.",
          library="numpy", section="4.1", transform="none")
def rain_simolo(series, others, ctx, max_donors=5):
    pick, X = _donor_matrix(series, others, ctx, max_donors)
    if not pick:
        return series
    zy = _nscore(series)
    zx = pd.concat([_nscore(X[c]) for c in pick], axis=1)
    pair = pd.concat([zy.rename("y"), zx], axis=1)
    R = pair.corr(min_periods=20)
    r = R.loc[pick, "y"].to_numpy(float)
    Rxx = R.loc[pick, pick].to_numpy(float)
    Z = zx.to_numpy(float)
    zhat = np.full(len(series), np.nan)
    cache = {}
    for i in np.flatnonzero(series.isna().to_numpy()):
        av = tuple(np.flatnonzero(np.isfinite(Z[i])))
        if not av:
            continue
        if av not in cache:
            idx = list(av)
            w = np.maximum(r[idx], 1e-3)
            var = float(w @ Rxx[np.ix_(idx, idx)] @ w)
            cache[av] = (idx, w, np.sqrt(max(var, 1e-9)))
        idx, w, sd = cache[av]
        zhat[i] = float(np.dot(w, Z[i, idx]) / sd)
    obs = series.dropna().to_numpy(float)
    q = stats.norm.cdf(zhat)
    est = np.where(np.isfinite(q), np.quantile(obs, np.clip(np.nan_to_num(q, nan=0.5), 0, 1)), np.nan)
    return series.where(series.notna(), pd.Series(est, index=series.index))


def _product(series, others, ctx):
    names = [c for c in ctx.meta.get("product", []) if c in others.columns]
    if not names:
        return None
    return others[names].mean(axis=1)


@register("rain_quantile_mapping", "Quantile mapping of a gridded product to the gauge", "rainfall", variables=("rainfall",), needs=("series", "product"), best_for=("G3", "G4", "G7"), library="numpy", section="4.2", transform="none")
def rain_quantile_mapping(series, others, ctx, n_q=100):
    prod = _product(series, others, ctx)
    if prod is None:
        return series
    pair = pd.concat([series.rename("g"), prod.rename("p")], axis=1).dropna()
    if len(pair) < 100:
        return series
    q = np.linspace(0.0, 1.0, n_q + 1)
    qg, qp = np.quantile(pair["g"], q), np.quantile(pair["p"], q)
    qp_u, idx = np.unique(qp, return_index=True)
    est = np.interp(prod.to_numpy(float), qp_u, qg[idx])
    hi = prod.to_numpy(float) > qp_u[-1]
    if hi.any() and qp_u[-1] > 0:
        est[hi] = qg[-1] * prod.to_numpy(float)[hi] / qp_u[-1]
    return series.where(series.notna(), pd.Series(est, index=series.index))


@register("rain_local_scaling", "Local intensity scaling of a product", "rainfall", variables=("rainfall",), needs=("series", "product"), best_for=("G3", "G7"), library="numpy", section="4.2", transform="none")
def rain_local_scaling(series, others, ctx, thr=None):
    thr = ctx.wet_threshold if thr is None else thr
    prod = _product(series, others, ctx)
    if prod is None:
        return series
    pair = pd.concat([series.rename("g"), prod.rename("p")], axis=1).dropna()
    if len(pair) < 100:
        return series
    freq = (pair["g"] >= thr).mean()
    t_p = float(np.quantile(pair["p"], 1 - freq)) if 0 < freq < 1 else 0.0
    sel = pair["p"] > t_p
    scale = float(pair["g"].sum() / max(pair.loc[sel, "p"].sum(), 1e-9))
    est = np.where(prod.to_numpy(float) > t_p, prod.to_numpy(float) * scale, 0.0)
    return series.where(series.notna(), pd.Series(est, index=series.index))


@register("rain_regression_merge", "Regression merge of gridded product and gauge", "rainfall", variables=("rainfall",), needs=("series", "product"), best_for=("G3", "G7"), library="numpy", section="4.2", transform="none")
def rain_regression_merge(series, others, ctx, thr=None):
    thr = ctx.wet_threshold if thr is None else thr
    prod = _product(series, others, ctx)
    if prod is None:
        return series
    pair = pd.concat([series.rename("g"), prod.rename("p")], axis=1).dropna()
    if len(pair) < 100:
        return series
    A = np.column_stack([np.ones(len(pair)), np.sqrt(pair["p"])])
    beta, *_ = np.linalg.lstsq(A, np.sqrt(pair["g"]), rcond=None)
    est = np.square(np.maximum(beta[0] + beta[1] * np.sqrt(prod.to_numpy(float)), 0.0))
    est = np.where(est < thr, 0.0, est)
    return series.where(series.notna(), pd.Series(est, index=series.index))


@register("rain_weather_generator", "Markov-chain occurrence with gamma amounts", "rainfall", variables=("rainfall",), needs=("series", "years>=5"), best_for=("G3", "G4"), library="numpy", section="4.1", transform="none")
def rain_weather_generator(series, others, ctx, thr=None):
    thr = ctx.wet_threshold if thr is None else thr
    rng = ctx.rng(31)
    y = series.to_numpy(float)
    months = series.index.month.to_numpy()
    obs = np.isfinite(y)
    wet = np.where(obs, y >= thr, False)
    params = {}
    for m in range(1, 13):
        sel = months == m
        prev_ok = np.r_[False, obs[:-1]] & obs & sel
        prev_wet = np.r_[False, wet[:-1]]
        n_w = (prev_ok & prev_wet).sum()
        n_d = (prev_ok & ~prev_wet).sum()
        p11 = (wet & prev_ok & prev_wet).sum() / n_w if n_w > 0 else 0.5
        p01 = (wet & prev_ok & ~prev_wet).sum() / n_d if n_d > 0 else 0.2
        amt = y[obs & wet & sel]
        if len(amt) >= 5 and amt.var() > 0:
            shape = amt.mean() ** 2 / amt.var()
            scale = amt.var() / amt.mean()
        else:
            shape, scale = 0.8, max(float(np.nanmean(y[obs & wet])) if (obs & wet).any() else 5.0, 1.0)
        params[m] = (p01, p11, shape, scale)
    est = y.copy()
    state = bool(wet[0]) if obs[0] else False
    u = rng.random(len(y))
    for i in range(len(y)):
        if obs[i]:
            state = wet[i]
            continue
        p01, p11, shape, scale = params[months[i]]
        state = u[i] < (p11 if state else p01)
        est[i] = max(thr, rng.gamma(shape, scale)) if state else 0.0
    return series.where(series.notna(), pd.Series(est, index=series.index))


def repair_accumulated(series: pd.Series, others: pd.DataFrame | None, events, ctx=None) -> pd.Series:
    """Spread accumulated totals over the days of the gap that precedes them (G13).

    events: list of dicts with gap_start, reading (Timestamps) as found by the profiler.
    The reading and the gap days get total * w / sum(w), where w is the mean of the donors on those days
    (equal weights if no donor value exists). Returns a new series; the totals are conserved.
    """
    out = series.copy()
    for ev in events:
        span = out.loc[ev["gap_start"] : ev["reading"]].index
        total = float(out.loc[ev["reading"]])
        if not np.isfinite(total):
            continue
        w = np.ones(len(span))
        if others is not None and others.shape[1]:
            pat = others.loc[span].mean(axis=1).to_numpy(float)
            if np.isfinite(pat).any() and np.nansum(pat) > 0:
                w = np.nan_to_num(pat, nan=0.0) + 1e-6
        out.loc[span] = total * w / w.sum()
    return out
