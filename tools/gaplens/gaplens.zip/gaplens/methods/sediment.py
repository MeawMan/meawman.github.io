"""Sediment and solute concentration methods (catalog section 9).

All methods work on log concentration and log discharge: the library transforms the target and the other series with
log(x + c) before calling them (variable "sediment"), and maps the result back. The methods therefore fit straight lines
in log-log space, and the retransformation bias is handled here by Duan's smearing factor, added in log space.

`ctx.meta["driver"]` names the discharge column of `others`; `ctx.meta["surrogate"]` names a turbidity (or other surrogate) column.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import calendar_features, register, steps_per_day

COMMON = dict(variables=("sediment",), library="numpy, scikit-learn", section="9.2")


def _xy(series, others, ctx, col="driver"):
    x = others[ctx.meta[col]]
    return x, pd.concat([series.rename("y"), x.rename("x")], axis=1).dropna()


def _ols(x, y):
    X = np.column_stack([np.ones_like(x), x])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    r = y - X @ beta
    return beta, r


def _smear(r):
    """Duan (1983) smearing factor in log space: ln mean(exp(residuals)), capped for safety."""
    return float(np.log(np.mean(np.exp(np.clip(r, -5, 5)))))


def _predict_lines(series, x, fits, label):
    """Use one (intercept, slope, smear) per label value; label is an array aligned with the index."""
    out = np.full(len(series), np.nan)
    xv = x.to_numpy(float)
    for lab, (b0, b1, sm) in fits.items():
        m = label == lab
        out[m] = b0 + b1 * xv[m] + sm
    return pd.Series(out, index=series.index)


@register("sed_rating", "Power-law sediment rating (log-log OLS, no bias correction)", "sediment", needs=("series", "driver"), best_for=("S1",), limits="Under-estimates loads: the retransformation bias is not corrected (Ferguson 1986)", **COMMON)
def sed_rating(series, others, ctx):
    x, d = _xy(series, others, ctx)
    if len(d) < 8:
        return series
    beta, _ = _ols(d["x"].to_numpy(), d["y"].to_numpy())
    est = pd.Series(beta[0] + beta[1] * x.to_numpy(float), index=series.index)
    return series.where(series.notna(), est)


@register("sed_rating_smear", "Power-law sediment rating with smearing bias correction", "sediment", needs=("series", "driver"), best_for=("S1", "S4"), limits="Assumes similar residual spread across flow (Duan 1983)", **COMMON)
def sed_rating_smear(series, others, ctx):
    x, d = _xy(series, others, ctx)
    if len(d) < 8:
        return series
    beta, r = _ols(d["x"].to_numpy(), d["y"].to_numpy())
    est = pd.Series(beta[0] + beta[1] * x.to_numpy(float) + _smear(r), index=series.index)
    return series.where(series.notna(), est)


def _grouped(series, others, ctx, label_all, min_n=12):
    x, d = _xy(series, others, ctx)
    if len(d) < 8:
        return series
    lab_obs = pd.Series(label_all, index=series.index).loc[d.index].to_numpy()
    beta_g, r_g = _ols(d["x"].to_numpy(), d["y"].to_numpy())
    glob = (beta_g[0], beta_g[1], _smear(r_g))
    fits = {}
    for lab in np.unique(label_all):
        m = lab_obs == lab
        if m.sum() >= min_n and np.ptp(d["x"].to_numpy()[m]) > 1e-6:
            b, r = _ols(d["x"].to_numpy()[m], d["y"].to_numpy()[m])
            fits[lab] = (b[0], b[1], _smear(r))
        else:
            fits[lab] = glob
    est = _predict_lines(series, x, fits, label_all)
    return series.where(series.notna(), est)


@register("sed_rating_seasonal", "Seasonal sediment rating curves (four seasons) with smearing", "sediment", needs=("series", "driver", "years>=2"), best_for=("S1",), limits="Fewer samples per curve", **COMMON)
def sed_rating_seasonal(series, others, ctx):
    season = (series.index.month % 12 // 3).to_numpy()  # DJF=0, MAM=1, JJA=2, SON=3
    return _grouped(series, others, ctx, season)


@register("sed_rating_limb", "Rising and falling limb sediment rating curves with smearing", "sediment", needs=("series", "driver"), best_for=("S1",), limits="Needs a short time step; the limb is read from the discharge series", **COMMON)
def sed_rating_limb(series, others, ctx):
    q = others[ctx.meta["driver"]].interpolate(limit_direction="both")
    slope = q.shift(-1) - q.shift(1)
    limb = (slope.fillna(0.0).to_numpy() > 0).astype(int)  # 1 = rising
    return _grouped(series, others, ctx, limb)


@register("sed_turbidity", "Surrogate regression of concentration on turbidity", "sediment", needs=("series", "surrogate"), best_for=("S2",), limits="The relation changes with particle size (Gray and Gartner 2009)", **COMMON)
def sed_turbidity(series, others, ctx):
    x, d = _xy(series, others, ctx, col="surrogate")
    if len(d) < 8:
        return series
    beta, r = _ols(d["x"].to_numpy(), d["y"].to_numpy())
    est = pd.Series(beta[0] + beta[1] * x.to_numpy(float) + _smear(r), index=series.index)
    return series.where(series.notna(), est)


@register("sed_turbidity_discharge", "Concentration on turbidity and discharge (log-log multiple regression)", "sediment", needs=("series", "driver", "surrogate"), best_for=("S2",), **COMMON)
def sed_turbidity_discharge(series, others, ctx):
    xq, xt = others[ctx.meta["driver"]], others[ctx.meta["surrogate"]]
    d = pd.concat([series.rename("y"), xq.rename("q"), xt.rename("t")], axis=1).dropna()
    if len(d) < 12:
        return series
    X = np.column_stack([np.ones(len(d)), d["q"], d["t"]])
    beta, *_ = np.linalg.lstsq(X, d["y"].to_numpy(), rcond=None)
    r = d["y"].to_numpy() - X @ beta
    full = pd.concat([xq.rename("q"), xt.rename("t")], axis=1)
    est = pd.Series(beta[0] + beta[1] * full["q"] + beta[2] * full["t"] + _smear(r), index=series.index)
    return series.where(series.notna(), est)


@register("sed_wrtds", "Weighted regression on time, discharge and season (WRTDS-type)", "sediment", needs=("series", "driver", "years>=3"), best_for=("S1", "S4"), limits="Needs many samples and years (Hirsch et al. 2010)", cost="medium", **COMMON)
def sed_wrtds(series, others, ctx, h_time_years=4.0, h_logq=2.0, h_season=0.5, min_eff=25.0):
    x, d = _xy(series, others, ctx)
    if len(d) < 40:
        return series
    t_obs = (d.index - series.index[0]) / pd.Timedelta(days=365.25)
    t_obs = np.asarray(t_obs, float)
    yr = lambda idx: np.asarray((idx - series.index[0]) / pd.Timedelta(days=365.25), float)  # noqa: E731
    doy = lambda idx: np.asarray(idx.dayofyear, float) / 365.25  # noqa: E731
    s_obs = doy(d.index)
    q_obs, y_obs = d["x"].to_numpy(), d["y"].to_numpy()
    X_obs = np.column_stack([np.ones(len(d)), t_obs, q_obs, np.sin(2 * np.pi * s_obs), np.cos(2 * np.pi * s_obs)])
    miss = series.isna() & x.notna()
    idx = series.index[miss.to_numpy()]
    t_new, s_new, q_new = yr(idx), doy(idx), x[miss].to_numpy()
    X_new = np.column_stack([np.ones(len(idx)), t_new, q_new, np.sin(2 * np.pi * s_new), np.cos(2 * np.pi * s_new)])
    est = np.empty(len(idx))

    def tricube(dist, h):
        u = np.clip(dist / h, 0, 1)
        return (1 - u**3) ** 3

    for i in range(len(idx)):
        scale = 1.0
        for _ in range(6):
            ds = np.abs(s_obs - s_new[i])
            ds = np.minimum(ds, 1.0 - ds)
            w = tricube(np.abs(t_obs - t_new[i]), h_time_years * scale) * tricube(np.abs(q_obs - q_new[i]), h_logq * scale) * tricube(ds, h_season * min(scale, 2.0))
            if w.sum() ** 2 / max((w**2).sum(), 1e-12) >= min_eff:
                break
            scale *= 1.6
        sw = np.sqrt(w)
        beta, *_ = np.linalg.lstsq(X_obs * sw[:, None], y_obs * sw, rcond=None)
        r = y_obs - X_obs @ beta
        sm = np.log(max(float(np.sum(w * np.exp(np.clip(r, -5, 5))) / max(w.sum(), 1e-12)), 1e-6))
        est[i] = X_new[i] @ beta + sm
    out = pd.Series(np.nan, index=series.index)
    out[miss.to_numpy()] = est
    return series.where(series.notna(), out)


@register("sed_gbm", "Gradient boosting on discharge, discharge change, antecedent flow and season", "sediment", needs=("series", "driver"), best_for=("S1", "S2"), limits="Cannot extrapolate above the sampled flows", library="scikit-learn", section="9.2", variables=("sediment",), cost="medium")
def sed_gbm(series, others, ctx, seed=0):
    from sklearn.ensemble import HistGradientBoostingRegressor

    q = others[ctx.meta["driver"]].interpolate(limit_direction="both")
    spd = steps_per_day(series.index)
    feats = pd.DataFrame({"lnq": q, "dq": q.diff().fillna(0.0)})
    for days in (3, 14, 60):
        feats[f"lnq_ma{days}"] = q.rolling(max(int(days * spd), 1), min_periods=1).mean()
    feats = pd.concat([feats, calendar_features(series.index)], axis=1)
    if ctx.meta.get("surrogate") in others.columns:
        feats["surr"] = others[ctx.meta["surrogate"]]
    obs = series.notna() & feats.notna().all(axis=1)
    if obs.sum() < 30:
        return series
    model = HistGradientBoostingRegressor(max_depth=4, learning_rate=0.06, max_iter=250, random_state=seed)
    model.fit(feats[obs], series[obs])
    est = pd.Series(model.predict(feats.fillna(0.0)), index=series.index)
    return series.where(series.notna(), est)
