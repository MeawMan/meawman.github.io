"""Temperature methods (catalog section 5)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import register, steps_per_day
from .multistation import _donors, distances, donor_stats


@register("temp_neighbor_elevation", "Neighbour interpolation with elevation adjustment", "temperature", variables=("temperature",), needs=("series", "neighbors"), best_for=("G1", "G2", "G3"), library="numpy", section="5", transform="none")
def temp_neighbor_elevation(series, others, ctx, lapse_c_per_km=6.5, max_donors=5, power=2.0):
    donors = _donors(ctx, series, others, min_corr=0.5)
    if not donors:
        return series
    st = donor_stats(series, others, donors)
    d = distances(ctx.target, donors, ctx, st).sort_values().iloc[:max_donors]
    X = others[list(d.index)].copy()
    have_elev = ctx.coords is not None and "elevation_m" in ctx.coords.columns and ctx.target in ctx.coords.index and all(c in ctx.coords.index for c in d.index)
    if have_elev:
        dz = (ctx.coords.loc[d.index, "elevation_m"].to_numpy(float) - float(ctx.coords.loc[ctx.target, "elevation_m"])) / 1000.0
        X = X + lapse_c_per_km * dz[None, :]
    # remove what is left of the mean offset on the overlap
    off = []
    for c in X.columns:
        pair = pd.concat([series, X[c]], axis=1).dropna()
        off.append(float((pair.iloc[:, 0] - pair.iloc[:, 1]).mean()))
    X = X + np.array(off)[None, :]
    w = 1.0 / np.maximum(d.to_numpy(), 1e-6) ** power
    V = X.to_numpy(float)
    W = np.where(np.isfinite(V), w[None, :], 0.0)
    num = np.nansum(np.where(np.isfinite(V), V, 0.0) * W, axis=1)
    den = W.sum(axis=1)
    est = pd.Series(np.where(den > 0, num / np.where(den > 0, den, 1.0), np.nan), index=series.index)
    return series.where(series.notna(), est)


@register("temp_diurnal_anomaly", "Mean diurnal shape plus interpolated anomaly", "temperature", variables=("temperature",), needs=("series", "years>=1"), best_for=("G1", "G2"), library="pandas", section="5", transform="none")
def temp_diurnal_anomaly(series, others, ctx, min_cover=0.8):
    spd = steps_per_day(series.index)
    if spd <= 1.5:
        return series.interpolate(method="time", limit_direction="both")
    day = series.index.normalize()
    cover = series.notna().groupby(day).mean()
    full_days = cover[cover >= min_cover].index
    daily_mean = series.groupby(day).mean()
    anom = series - daily_mean.reindex(day).to_numpy()
    key = pd.Series(list(zip(series.index.month, series.index.hour)), index=series.index)
    sel = pd.Series(day.isin(full_days), index=series.index) & series.notna()
    shape = anom[sel].groupby(key[sel]).mean()
    est_shape = key.map(shape).astype(float).fillna(0.0)
    dm = daily_mean.where(daily_mean.index.isin(full_days))
    dm = dm.reindex(pd.date_range(day[0], day[-1], freq="D")).interpolate(limit_direction="both")
    base_level = pd.Series(dm.reindex(day).to_numpy(float), index=series.index)
    return series.where(series.notna(), base_level + est_shape)
