"""Temporal methods (catalog 3.1): the series alone."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import interpolate

from .base import register, steps_per_day


def _tvals(index):
    return np.asarray((index - index[0]) / pd.Timedelta(1, "D"), dtype=float)


@register("locf", "Last or next value carried", "temporal", best_for=("G1",), library="pandas", section="3.1")
def locf(series, others, ctx, limit=None):
    return series.ffill(limit=limit).bfill(limit=limit)


@register("linear", "Linear interpolation", "temporal", best_for=("G1", "G2"), library="pandas, scipy", section="3.1")
def linear(series, others, ctx, max_gap=None):
    out = series.interpolate(method="time", limit_direction="both", limit=max_gap)
    return out


def _scipy_interp(series, kind, max_gap_days=None):
    """Interpolate the gaps. With `max_gap_days`, gaps longer than that are left empty (for the next method of a fill
    cascade): cubic and Akima curves are not bounded by their end points and swing far off across long gaps."""
    obs = series.dropna()
    if len(obs) < 4:
        return series.interpolate(limit_direction="both")
    t = _tvals(series.index)
    t_obs = t[series.notna().to_numpy()]
    y_obs = obs.to_numpy()
    if kind == "pchip":
        f = interpolate.PchipInterpolator(t_obs, y_obs, extrapolate=False)
    elif kind == "akima":
        f = interpolate.Akima1DInterpolator(t_obs, y_obs)
    elif kind == "cubic":
        f = interpolate.CubicSpline(t_obs, y_obs, bc_type="natural", extrapolate=False)
    else:
        raise ValueError(kind)
    est = np.asarray(f(t), float)
    out = pd.Series(est, index=series.index)
    # outside the observed range: carry the nearest value
    out = out.ffill().bfill()
    if max_gap_days is not None:
        from ..gaps.result import find_runs

        limit = max(1, int(round(max_gap_days * steps_per_day(series.index))))
        miss = series.isna().to_numpy()
        starts, lengths = find_runs(miss)
        for s0, ln in zip(starts, lengths):
            if ln > limit:
                out.iloc[s0 : s0 + ln] = np.nan
    return out


@register("pchip", "PCHIP interpolation", "temporal", best_for=("G1", "G2"), library="scipy", section="3.1")
def pchip(series, others, ctx):
    return _scipy_interp(series, "pchip")


@register("akima", "Akima interpolation (gaps up to 7 days)", "temporal", best_for=("G1", "G2"), library="scipy", section="3.1",
          limits="longer gaps are left for the next method: the curve is not bounded by the gap ends")
def akima(series, others, ctx, max_gap_days=7):
    return _scipy_interp(series, "akima", max_gap_days)


@register("spline", "Cubic spline interpolation (gaps up to 7 days)", "temporal", best_for=("G1", "G2"), library="scipy", section="3.1",
          limits="longer gaps are left for the next method: a cubic spline swings far off across long gaps")
def spline(series, others, ctx, max_gap_days=7):
    return _scipy_interp(series, "cubic", max_gap_days)


def _moving(series, window_days, stat):
    spd = steps_per_day(series.index)
    w = max(3, int(round(window_days * spd)))
    out = series.copy()
    for _ in range(8):
        r = out.rolling(w, center=True, min_periods=1)
        est = r.mean() if stat == "mean" else r.median()
        out = out.where(out.notna(), est)
        if out.notna().all():
            break
        w *= 2
    return out.ffill().bfill()


@register("moving_mean", "Moving-window mean fill", "temporal", best_for=("G1",), library="pandas", section="3.1")
def moving_mean(series, others, ctx, window_days=7):
    return _moving(series, window_days, "mean")


@register("moving_median", "Moving-window median fill", "temporal", best_for=("G1",), library="pandas", section="3.1")
def moving_median(series, others, ctx, window_days=7):
    return _moving(series, window_days, "median")


def _climatology_key(index, spd):
    doy = np.minimum(index.dayofyear.to_numpy(), 365)
    if spd > 1.5:
        return doy * 100 + index.hour.to_numpy()
    return doy


def _climatology(series, stat="mean", smooth_days=7):
    """Day-of-year (and hour of day for sub-daily data) mean or median, smoothed circularly over the year."""
    spd = steps_per_day(series.index)
    key = pd.Series(_climatology_key(series.index, spd), index=series.index)
    g = series.groupby(key)
    clim = (g.mean() if stat == "mean" else g.median()).sort_index()
    k = int(smooth_days) if smooth_days else 1
    if k > 1 and spd <= 1.5:
        vals = clim.to_numpy()
        ext = np.r_[vals[-k:], vals, vals[:k]]
        sm = pd.Series(ext).rolling(k, center=True, min_periods=1).mean().to_numpy()[k:-k]
        clim = pd.Series(sm, index=clim.index)
    return pd.Series(key.map(clim).to_numpy(float), index=series.index)


@register("climatology_mean", "Seasonal climatology (day-of-year mean)", "temporal", needs=("series", "years>=3"), best_for=("G3", "G4", "G5"), library="pandas", section="3.1")
def climatology_mean(series, others, ctx, smooth_days=7):
    est = _climatology(series, "mean", smooth_days)
    return series.where(series.notna(), est).interpolate(limit_direction="both")


@register("climatology_median", "Seasonal climatology (day-of-year median)", "temporal", needs=("series", "years>=3"), best_for=("G3", "G4", "G5"), library="pandas", section="3.1")
def climatology_median(series, others, ctx, smooth_days=7):
    est = _climatology(series, "median", smooth_days)
    return series.where(series.notna(), est).interpolate(limit_direction="both")


def fourier_design(index, k_year=3, k_day=2, trend=True):
    spd = steps_per_day(index)
    t_years = (index - index[0]) / pd.Timedelta(days=365.25)
    doy = index.dayofyear.to_numpy(float) + index.hour.to_numpy() / 24.0
    cols = [np.ones(len(index))]
    if trend:
        cols.append(np.asarray(t_years, float))
    for k in range(1, k_year + 1):
        cols += [np.sin(2 * np.pi * k * doy / 365.25), np.cos(2 * np.pi * k * doy / 365.25)]
    if spd > 1.5:
        h = index.hour.to_numpy(float) + index.minute.to_numpy() / 60.0
        for k in range(1, k_day + 1):
            cols += [np.sin(2 * np.pi * k * h / 24.0), np.cos(2 * np.pi * k * h / 24.0)]
    return np.column_stack(cols)


@register("harmonic_regression", "Harmonic (Fourier) regression", "temporal", needs=("series", "years>=2"), best_for=("G3", "G4"), library="numpy", section="3.1", uncertainty=True)
def harmonic_regression(series, others, ctx, k_year=3, k_day=2, trend=True):
    X = fourier_design(series.index, k_year, k_day, trend)
    ok = series.notna().to_numpy()
    beta, *_ = np.linalg.lstsq(X[ok], series.to_numpy()[ok], rcond=None)
    est = X @ beta
    resid_sd = float(np.std(series.to_numpy()[ok] - est[ok]))
    s = pd.Series(est, index=series.index)
    return s, s - 1.96 * resid_sd, s + 1.96 * resid_sd


@register("stl_interp", "Seasonal-trend decomposition, fill the remainder", "temporal", needs=("series", "years>=2"), best_for=("G2", "G3"), library="statsmodels", section="3.1", cost="medium")
def stl_interp(series, others, ctx, period=None, iterations=3, tau=None, robust=False):
    from statsmodels.tsa.seasonal import STL

    spd = steps_per_day(series.index)
    if period is None:
        period = 365 if spd <= 1.5 and len(series) > 2 * 365 else (int(round(spd)) if spd > 1.5 else max(7, len(series) // 4))
    work = series.interpolate(limit_direction="both")
    miss = series.isna().to_numpy()
    for _ in range(iterations):
        res = STL(work, period=int(period), robust=robust).fit()
        comp = res.trend + res.seasonal
        rem = (series - comp)
        rem_f = rem.interpolate(limit_direction="both")
        if tau:
            dist = pd.Series(np.where(miss, np.nan, 0.0), index=series.index)
            pos = np.arange(len(series), dtype=float)
            obs_pos = np.where(miss, np.nan, pos)
            d_prev = pos - pd.Series(obs_pos).ffill().to_numpy()
            d_next = pd.Series(obs_pos).bfill().to_numpy() - pos
            d = np.nanmin(np.vstack([np.nan_to_num(d_prev, nan=1e9), np.nan_to_num(d_next, nan=1e9)]), axis=0)
            rem_f = rem_f * np.exp(-d / float(tau))
        new = comp + rem_f
        work = series.where(~miss, new)
    return work
