"""Fill methods. Importing this package registers every implemented method in `REGISTRY`."""

from . import groundwater, ml, multistation, rainfall, rating, sediment, streamflow, temperature, tidal, temporal, timeseries  # noqa: F401
from .base import REGISTRY, Ctx, Method, MethodInfo, applicable, fill, get, list_methods, register, register_planned

__all__ = ["REGISTRY", "Ctx", "Method", "MethodInfo", "applicable", "fill", "get", "list_methods", "register", "register_planned"]
