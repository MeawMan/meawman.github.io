"""Time-series models (catalog 3.2): ARIMA with Kalman smoother, state space, SSA, Gaussian process, dynamic regression."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import register, steps_per_day, usable_donors
from .temporal import fourier_design


def _smoothed_forecasts(res, y_obs_mask, y):
    """Expected value of the observation given all data, from a statsmodels state-space result.

    Falls back to the filtered one-step forecasts if the smoothed ones are not available or look wrong.
    """
    est, var = None, None
    try:
        sr = res.smoother_results
        est = np.asarray(sr.smoothed_forecasts)[0].astype(float)
        var = np.asarray(sr.smoothed_forecasts_error_cov)[0, 0].astype(float)
    except Exception:
        est = None
    if est is not None and y_obs_mask.any():
        scale = max(np.nanstd(y), 1e-9)
        if np.nanmax(np.abs(est[y_obs_mask] - y[y_obs_mask])) > 0.5 * scale and not _has_meas_error(res):
            est = None
    if est is None:
        est = np.asarray(res.filter_results.forecasts)[0].astype(float)
        var = np.asarray(res.filter_results.forecasts_error_cov)[0, 0].astype(float)
    return est, var


def _has_meas_error(res):
    try:
        return bool(res.model.measurement_error)
    except Exception:
        return True  # UnobservedComponents with irregular component: smoothed != observed is expected


def _seasonal_exog(index, k_year):
    X = fourier_design(index, k_year=k_year, k_day=2 if steps_per_day(index) > 1.5 else 0, trend=False)
    return X[:, 1:]  # drop the constant: the model has its own intercept


@register("arima_kalman", "ARIMA with Kalman smoother", "timeseries", needs=("series", "years>=1"), best_for=("G1", "G2", "G3"), library="statsmodels", section="3.2", uncertainty=True, cost="medium")
def arima_kalman(series, others, ctx, order=(2, 0, 1), k_year=2, maxiter=60):
    from statsmodels.tsa.statespace.sarimax import SARIMAX

    exog = _seasonal_exog(series.index, k_year) if k_year else None
    mod = SARIMAX(series.to_numpy(float), exog=exog, order=order, trend="c")
    res = mod.fit(disp=False, maxiter=maxiter)
    obs = series.notna().to_numpy()
    est, var = _smoothed_forecasts(res, obs, series.to_numpy(float))
    sd = np.sqrt(np.maximum(var, 0.0))
    s = pd.Series(est, index=series.index)
    return s, s - 1.96 * sd, s + 1.96 * sd


@register("state_space_uc", "Structural state-space model (level, seasonal, AR)", "timeseries", needs=("series", "years>=2"), best_for=("G1", "G2", "G3"), library="statsmodels", section="3.2", uncertainty=True, cost="high")
def state_space_uc(series, others, ctx, harmonics=2, ar=1, maxiter=40):
    from statsmodels.tsa.statespace.structural import UnobservedComponents

    spd = steps_per_day(series.index)
    period = 365.25 * spd
    mod = UnobservedComponents(
        series.to_numpy(float),
        level="llevel",
        freq_seasonal=[{"period": period, "harmonics": int(harmonics)}],
        stochastic_freq_seasonal=[False],
        autoregressive=int(ar) if ar else None,
    )
    res = mod.fit(disp=False, maxiter=maxiter)
    obs = series.notna().to_numpy()
    est, var = _smoothed_forecasts(res, obs, series.to_numpy(float))
    sd = np.sqrt(np.maximum(var, 0.0))
    s = pd.Series(est, index=series.index)
    return s, s - 1.96 * sd, s + 1.96 * sd


def _hankel(x, L):
    n = len(x)
    K = n - L + 1
    idx = np.arange(L)[:, None] + np.arange(K)[None, :]
    return x[idx]


def _diag_average(M, n):
    L, K = M.shape
    rec = np.zeros(n)
    cnt = np.zeros(n)
    for i in range(L):
        rec[i : i + K] += M[i]
        cnt[i : i + K] += 1.0
    return rec / cnt


@register("ssa", "Singular spectrum analysis gap filling", "timeseries", needs=("series", "years>=2"), best_for=("G2", "G3"), library="numpy", section="3.2", cost="medium")
def ssa(series, others, ctx, window=None, var_frac=0.9, max_comp=40, max_iter=30, tol=2e-3):
    y = series.to_numpy(float)
    n = len(y)
    obs = np.isfinite(y)
    spd = steps_per_day(series.index)
    L = int(window) if window else int(min(n // 3, 200 if spd <= 1.5 else 24 * 8))
    L = max(L, 10)
    mu, sd = np.mean(y[obs]), max(np.std(y[obs]), 1e-12)
    z = np.where(obs, (y - mu) / sd, 0.0)
    prev = z.copy()
    for it in range(max_iter):
        M = _hankel(z, L)
        # eigen-decomposition of the L x L lag covariance: same leading components as the SVD of the wide matrix, much cheaper
        w, U = np.linalg.eigh(M @ M.T)
        order = np.argsort(w)[::-1]
        w, U = np.clip(w[order], 0.0, None), U[:, order]
        var = w / max(np.sum(w), 1e-300)
        r = int(min(max_comp, np.searchsorted(np.cumsum(var), var_frac) + 1))
        Ur = U[:, :r]
        approx = Ur @ (Ur.T @ M)
        rec = _diag_average(approx, n)
        z = np.where(obs, (y - mu) / sd, rec)
        change = np.sqrt(np.mean((z[~obs] - prev[~obs]) ** 2)) if (~obs).any() else 0.0
        prev = z.copy()
        if change < tol:
            break
    return pd.Series(z * sd + mu, index=series.index)


@register("gp_local", "Gaussian-process regression (local windows)", "timeseries", needs=("series",), best_for=("G1", "G2", "G3"), library="scikit-learn", section="3.2", uncertainty=True, cost="medium")
def gp_local(series, others, ctx, context_factor=3.0, min_context=60, max_train=200):
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel

    from ..gaps.result import find_runs

    y = series.to_numpy(float)
    n = len(y)
    miss = ~np.isfinite(y)
    est = y.copy()
    lo = y.copy()
    hi = y.copy()
    starts, lens = find_runs(miss)
    for s, ln in zip(starts, lens):
        ctx_len = int(max(min_context, context_factor * ln))
        a, b = max(0, s - ctx_len), min(n, s + ln + ctx_len)
        idx = np.arange(a, b)
        tr = idx[np.isfinite(y[idx])]
        if len(tr) < 8:
            continue
        if len(tr) > max_train:
            tr = tr[np.linspace(0, len(tr) - 1, max_train).astype(int)]
        mu, sd = y[tr].mean(), max(y[tr].std(), 1e-9)
        kern = C(1.0, (1e-2, 1e2)) * RBF(length_scale=max(5.0, ln / 2.0), length_scale_bounds=(1.0, 2000.0)) + WhiteKernel(0.05, (1e-5, 1.0))
        gp = GaussianProcessRegressor(kernel=kern, normalize_y=False, n_restarts_optimizer=0, random_state=ctx.seed)
        gp.fit(tr[:, None].astype(float), (y[tr] - mu) / sd)
        te = np.arange(s, s + ln)
        m, sdp = gp.predict(te[:, None].astype(float), return_std=True)
        est[te] = m * sd + mu
        lo[te] = est[te] - 1.96 * sdp * sd
        hi[te] = est[te] + 1.96 * sdp * sd
    s_est = pd.Series(est, index=series.index).interpolate(limit_direction="both")
    return s_est, pd.Series(lo, index=series.index).interpolate(limit_direction="both"), pd.Series(hi, index=series.index).interpolate(limit_direction="both")


@register("dynreg_arma", "Dynamic regression on a donor with ARMA errors", "timeseries", needs=("series", "donor"), best_for=("G2", "G3"), library="statsmodels", section="3.2", uncertainty=True, cost="medium")
def dynreg_arma(series, others, ctx, order=(1, 0, 1), max_donors=2, maxiter=60):
    from statsmodels.tsa.statespace.sarimax import SARIMAX

    donors = usable_donors(series, others, exclude=ctx.meta.get("product", []))
    if not donors:
        return series
    corr = {c: series.corr(others[c]) for c in donors}
    pick = sorted(donors, key=lambda c: -corr[c])[:max_donors]
    X = others[pick].interpolate(limit_direction="both")
    X = (X - X.mean()) / X.std().replace(0, 1)
    mod = SARIMAX(series.to_numpy(float), exog=X.to_numpy(float), order=order, trend="c")
    res = mod.fit(disp=False, maxiter=maxiter)
    obs = series.notna().to_numpy()
    est, var = _smoothed_forecasts(res, obs, series.to_numpy(float))
    sd = np.sqrt(np.maximum(var, 0.0))
    s = pd.Series(est, index=series.index)
    return s, s - 1.96 * sd, s + 1.96 * sd
