"""Gap profiler and mechanism diagnosis (catalog sections 1 and 2.1).

    prof = profile(df, variable="rainfall")
    prof.findings     detected gap types G1-G15 with evidence
    prof.runs         every gap run with position and length class
    prof.mechanism    tests of MCAR / MAR / MNAR (suspect) with a plain verdict
    prof.donors       usable donor series for each column
    prof.cleaned      the data with sentinel codes replaced by NaN
    print(prof.summary())

The thresholds are design defaults (ProfileConfig) that the benchmark tunes.
The mechanism can only be probed, never proved: MNAR is reported as a suspicion.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import stats

from .gaps.mechanisms import NAMES
from .gaps.result import find_runs

SENTINELS = (-999.0, -9999.0, -99999.0, -99.0, -999.9, -99.9, -9.99, -9.999, 9999.0, 99999.0, 999.0, 9999.9, 99.99, 9.999e3, -1e30, 1e30, -32768.0, 32767.0)
NONNEG = ("rainfall", "streamflow", "sediment", "discharge")


@dataclass
class ProfileConfig:
    short_days: float = 10.0  # runs up to this length are "short" (G2); longer ones are "long" (G3)
    long_days: float = 30.0  # any run this long marks G3
    min_cells_share: float = 0.15  # share of interior missing cells a length class needs to be reported
    single_share: float = 0.6  # G1 needs this share of missing cells in single-step runs
    long_share: float = 0.25  # G3 needs this share of cells in runs longer than short_days
    min_runs: int = 3
    sparse_obs_frac: float = 0.30  # G15: observed fraction below this and isolated observations
    sparse_median_run: int = 2
    seasonal_p: float = 0.25  # G4: share of years a calendar window is missing
    seasonal_min_days: int = 15
    seasonal_min_years: int = 3
    edge_frac: float = 0.02  # G5/G6: leading or trailing gap of at least this share of the record
    thin_overlap_days: float = 180.0  # G9
    long_gap_days: float = 10.0  # gap length that needs a donor (G9, G7, G8)
    z_crit: float = 3.0  # edge and neighbour tests (MNAR suspect)
    clip_share: float = 0.005
    clip_ratio: float = 5.0
    flat_min_days: float = 5.0
    sentinel_min_count: int = 2
    additive: tuple = ("rainfall",)
    donor_min_overlap_days: float = 30.0
    donor_min_corr: float = 0.2


@dataclass
class Profile:
    variable: str
    freq: str
    steps_per_day: float
    n: int
    start: pd.Timestamp
    end: pd.Timestamp
    columns: pd.DataFrame
    runs: pd.DataFrame
    findings: pd.DataFrame
    mechanism: pd.DataFrame
    donors: pd.DataFrame
    cleaned: pd.DataFrame
    meta: dict = field(default_factory=dict)
    config: ProfileConfig = field(default_factory=ProfileConfig)

    @property
    def codes(self) -> list:
        return sorted(set(self.findings["code"]), key=lambda c: int(c[1:])) if len(self.findings) else []

    def detected(self, code: str, column: str | None = None) -> bool:
        f = self.findings[self.findings["code"] == code]
        if column is not None:
            f = f[(f["scope"] == column) | (f["scope"] == "network")]
        return len(f) > 0

    def verdict(self) -> str:
        m = self.mechanism[self.mechanism["test"] == "verdict"]
        return m["note"].iloc[0] if len(m) else "unknown"

    def summary(self) -> str:
        lines = [
            f"{self.variable}: {self.n} steps ({self.freq}), {self.start.date()} to {self.end.date()}, {self.columns.shape[0]} series",
            "",
            "Series (missing %, runs, longest run in days):",
        ]
        for _, r in self.columns.iterrows():
            lines.append(f"  {r['column']:<18s} {100 * r['missing_frac']:5.1f} %  {int(r['n_runs']):4d} runs  longest {r['longest_days']:.1f} d")
        lines += ["", "Gap types found:"]
        if len(self.findings) == 0:
            lines.append("  none")
        for code in self.codes:
            f = self.findings[self.findings["code"] == code]
            scopes = ", ".join(sorted(set(f["scope"])))
            lines.append(f"  {code} {NAMES[code]} [{scopes}]: {f['evidence'].iloc[0]}")
        lines += ["", f"Mechanism: {self.verdict()}"]
        return "\n".join(lines)


# ----------------------------------------------------------------------------- helpers


def _steps_per_day(index):
    step = pd.Series(index).diff().median()
    return float(pd.Timedelta(days=1) / step) if pd.notna(step) and step > pd.Timedelta(0) else 1.0


def _freq_name(spd):
    if abs(spd - 1) < 0.01:
        return "daily"
    if abs(spd - 24) < 0.1:
        return "hourly"
    if spd > 1:
        return f"{spd:.3g} steps/day"
    return f"{1 / spd:.3g} days/step"


def _regularise(df: pd.DataFrame):
    df = df.copy()
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index)
    df = df[~df.index.duplicated(keep="first")].sort_index()
    step = pd.Series(df.index).diff().median()
    if pd.isna(step) or step <= pd.Timedelta(0):
        step = pd.Timedelta(days=1)
    irregular = float((pd.Series(df.index).diff().dropna() != step).mean()) if len(df) > 2 else 0.0
    full = pd.date_range(df.index[0], df.index[-1], freq=step)
    if len(full) != len(df) or irregular > 0:
        df = df.reindex(full)
    return df, irregular


def _seasonal_rank(s: pd.Series) -> pd.Series:
    """Percent rank of each value within its calendar month (removes the seasonal cycle from rank tests)."""
    out = pd.Series(np.nan, index=s.index)
    for m, g in s.groupby(s.index.month):
        out.loc[g.index] = g.rank(pct=True)
    return out


def _blocks(flags):
    return find_runs(np.asarray(flags, bool))


def _f(code, scope, strength, evidence, **detail):
    return {"code": code, "scope": scope, "strength": float(np.clip(strength, 0, 1)), "evidence": evidence, "detail": detail}


# ----------------------------------------------------------------------------- sentinel codes, clipping, flat lines


def detect_sentinels(df: pd.DataFrame, variable: str, cfg: ProfileConfig):
    """Return (cleaned df, findings, per-column code lists)."""
    cleaned = df.copy()
    findings = []
    found = {}
    for c in df.columns:
        x = df[c].astype(float)
        vals = x.dropna()
        if len(vals) < 20:
            continue
        counts = vals.value_counts()
        q1, q3 = vals.quantile(0.25), vals.quantile(0.75)
        iqr = max(q3 - q1, 1e-9)
        codes = []
        for v, k in counts.items():
            if k < cfg.sentinel_min_count:
                continue
            rest = vals[vals != v]
            if len(rest) < 10:
                continue
            lo, hi = rest.min(), rest.max()
            rng_ = max(hi - lo, 1e-9)
            outside = (v < lo - 0.25 * rng_) or (v > hi + 0.25 * rng_)
            candidate = any(abs(v - s) < 1e-9 for s in SENTINELS)
            negative_impossible = variable in NONNEG and v < 0
            far = (v < q1 - 8 * iqr) or (v > q3 + 8 * iqr)
            round_number = abs(v * 10 - round(v * 10)) < 1e-9
            near = int(((vals - v).abs() <= 0.1 * max(abs(v), 1e-9)).sum()) - int(k)
            isolated = k >= 3 * (near + 1)  # a sentinel stands alone; a tied value in a skewed tail has neighbours
            if (candidate and (outside or negative_impossible)) or (far and round_number and isolated and k >= max(3, 0.001 * len(vals))):
                codes.append((float(v), int(k)))
        if codes:
            found[c] = codes
            for v, _ in codes:
                cleaned.loc[(cleaned[c] - v).abs() < 1e-9, c] = np.nan
    if found:
        total = sum(k for cs in found.values() for _, k in cs)
        ex = "; ".join(f"{c}: " + ", ".join(f"{v:g} x{k}" for v, k in cs) for c, cs in found.items())
        for c in found:
            findings.append(_f("G12", c, 0.9, f"sentinel values replaced by NaN ({ex})", codes=found[c]))
    return cleaned, findings, found


def detect_clip_flat(cleaned: pd.DataFrame, variable: str, spd: float, cfg: ProfileConfig):
    findings = []
    for c in cleaned.columns:
        x = cleaned[c].dropna()
        if len(x) < 100:
            continue
        counts = x.value_counts().sort_index()
        # clipping at the maximum (and at the minimum where zero is not a natural floor)
        for side in ("max", "min"):
            if side == "min" and variable in ("rainfall",):
                continue
            ends = counts.iloc[::-1] if side == "max" else counts
            top_v, top_k = ends.index[0], ends.iloc[0]
            nxt = ends.iloc[1:6].mean() if len(ends) > 1 else 0.0
            share = top_k / len(x)
            if side == "min" and variable in NONNEG and top_v <= 0:
                continue
            if share >= cfg.clip_share and top_k >= 5 and top_k >= cfg.clip_ratio * max(nxt, 1.0):
                findings.append(_f("G11", c, min(1.0, share * 20), f"{share * 100:.1f} % of values equal the {side} {top_v:g} (sensor limit?)", kind="clip", side=side, value=float(top_v), share=float(share)))
        # stuck sensor: runs of identical values
        v = x.reindex(cleaned.index).to_numpy(float)
        same = np.r_[False, (v[1:] == v[:-1]) & np.isfinite(v[1:]) & np.isfinite(v[:-1])]
        if variable == "rainfall":
            same &= np.nan_to_num(v) != 0.0
        top_val = counts.index[-1]
        same &= ~(np.nan_to_num(v, nan=-1e99) == top_val)  # runs at the clipped ceiling are explained by clipping
        s0, ln = _blocks(same)
        min_len = max(3, int(cfg.flat_min_days * spd))
        long_ = ln >= min_len
        if long_.any():
            findings.append(_f("G11", c, 0.8, f"{int(long_.sum())} runs of identical values of at least {min_len} steps (stuck sensor?)", kind="flat", runs=int(long_.sum())))
    return findings


# ----------------------------------------------------------------------------- runs table


def runs_table(frame: pd.DataFrame, spd: float, cfg: ProfileConfig) -> pd.DataFrame:
    rows = []
    n = len(frame)
    for c in frame.columns:
        s0, ln = find_runs(frame[c].isna().to_numpy())
        for s, L in zip(s0, ln):
            days = L / spd
            pos = "lead" if s == 0 else ("trail" if s + L == n else "interior")
            cls = "single" if L == 1 else ("short" if days <= cfg.short_days else "long")
            rows.append(dict(column=c, i0=int(s), i1=int(s + L - 1), start=frame.index[s], end=frame.index[s + L - 1], length=int(L), days=days, position=pos, cls=cls))
    return pd.DataFrame(rows, columns=["column", "i0", "i1", "start", "end", "length", "days", "position", "cls"])


def decorrelation_steps(x: pd.Series, max_lag=400) -> int:
    z = x.interpolate(limit_direction="both").to_numpy(float)
    z = z - z.mean()
    den = np.sum(z * z)
    if den <= 0:
        return 1
    for k in range(1, min(max_lag, len(z) // 2)):
        if np.sum(z[k:] * z[:-k]) / den < 1.0 / np.e:
            return k
    return max_lag


# ----------------------------------------------------------------------------- type detectors


def detect_sparse(frame, spd, cfg):
    """G15: few observations, isolated in time."""
    out = []
    sparse_cols = []
    for c in frame.columns:
        obs = frame[c].notna().to_numpy()
        frac = obs.mean()
        if frac >= cfg.sparse_obs_frac or obs.sum() < 5:
            continue
        s0, ln = find_runs(obs)
        med_run = float(np.median(ln)) if len(ln) else 0.0
        if med_run <= cfg.sparse_median_run:
            idx = np.flatnonzero(obs)
            sp = np.diff(idx) / spd
            sparse_cols.append(c)
            out.append(_f("G15", c, 0.9, f"{int(obs.sum())} observations ({100 * frac:.1f} % of steps), median spacing {np.median(sp):.1f} d, spacing range {sp.min():.0f}-{sp.max():.0f} d", n_obs=int(obs.sum()), median_spacing_days=float(np.median(sp)), cv=float(np.std(sp) / max(np.mean(sp), 1e-9))))
    return out, sparse_cols


def detect_length_classes(frame, runs, spd, sparse_cols, cfg):
    out = []
    for c in frame.columns:
        r = runs[(runs["column"] == c) & (runs["position"] == "interior")]
        if c in sparse_cols:
            # inside a sparse series, long gaps are the spacings much larger than usual
            obs_idx = np.flatnonzero(frame[c].notna().to_numpy())
            if len(obs_idx) > 10:
                sp = np.diff(obs_idx) / spd
                med = np.median(sp)
                big = sp > max(5 * med, cfg.long_gap_days)
                if big.any():
                    out.append(_f("G3", c, 0.7, f"{int(big.sum())} gaps between samples of {sp[big].min():.0f}-{sp[big].max():.0f} d while the usual spacing is {med:.0f} d", n=int(big.sum())))
            continue
        if len(r) < cfg.min_runs:
            if len(r) and (r["days"] >= cfg.long_days).any():
                out.append(_f("G3", c, 0.8, f"{len(r)} long runs, longest {r['days'].max():.0f} d", n=len(r)))
            continue
        cells = r["length"].sum()
        single = r.loc[r["cls"] == "single", "length"].sum() / cells
        short = r.loc[r["cls"] == "short", "length"].sum() / cells
        long_ = r.loc[r["cls"] == "long", "length"].sum() / cells
        n_short = int((r["cls"] == "short").sum())
        if single >= cfg.single_share:
            out.append(_f("G1", c, single, f"{100 * single:.0f} % of missing values are isolated single steps ({int((r['cls'] == 'single').sum())} runs)", share=float(single)))
        elif short >= cfg.min_cells_share and n_short >= cfg.min_runs:
            out.append(_f("G2", c, short + single, f"{n_short} short runs (median {r.loc[r['cls'] == 'short', 'length'].median():.0f} steps, up to {cfg.short_days:g} d)", share=float(short)))
        elif single >= 0.2:
            out.append(_f("G1", c, single, f"{100 * single:.0f} % of missing values are isolated single steps", share=float(single)))
        if long_ >= cfg.long_share or (r["days"] >= cfg.long_days).any():
            lr = r[r["cls"] == "long"]
            out.append(_f("G3", c, max(long_, 0.5), f"{len(lr)} long runs ({100 * long_:.0f} % of missing values), longest {r['days'].max():.0f} d", n=len(lr), share=float(long_)))
    return out


def detect_seasonal(frame, runs, spd, sparse_cols, cfg, n_perm=199, seed=0):
    """G4: the same calendar window is missing in several years.

    Leading and trailing gaps are ignored. The statistic is the largest number of years in which every day of a
    window of at least `seasonal_min_days` is missing. Its p-value comes from shifting each year's missing pattern
    by a random offset (keeps the run lengths, destroys the common calendar position).
    """
    out = []
    years = np.unique(frame.index.year)
    if len(years) < max(cfg.seasonal_min_years + 1, 4):
        return out
    rng = np.random.default_rng(seed)
    doy = np.minimum(frame.index.dayofyear.to_numpy(), 365)
    yr = frame.index.year.to_numpy()
    W = int(cfg.seasonal_min_days)

    def stat(tab):
        cnt = tab.sum(axis=1)
        ext = np.r_[cnt, cnt[: W - 1]]
        win_min = pd.Series(ext).rolling(W).min().to_numpy()[W - 1 :]
        return cnt, win_min

    for c in frame.columns:
        if c in sparse_cols:
            continue
        miss = frame[c].isna().to_numpy().copy()
        for _, e in runs[(runs["column"] == c) & (runs["position"] != "interior")].iterrows():
            miss[e["i0"] : e["i1"] + 1] = False
        if miss.sum() < W:
            continue
        day = pd.Series(miss.astype(float)).groupby([yr, doy]).mean().unstack(0).reindex(range(1, 366))
        tab = (day > 0.5).astype(float).fillna(0.0).to_numpy()
        cnt, win_min = stat(tab)
        t_obs = float(win_min.max())
        if t_obs < cfg.seasonal_min_years:
            continue
        ge = 0
        for _ in range(n_perm):
            sh = np.column_stack([np.roll(tab[:, j], int(rng.integers(0, 365))) for j in range(tab.shape[1])])
            if stat(sh)[1].max() >= t_obs:
                ge += 1
        pval = (1 + ge) / (1 + n_perm)
        if pval <= 0.01:
            start = int(np.argmax(win_min))
            thr = max(cfg.seasonal_min_years, int(np.ceil(0.5 * t_obs)))
            good = cnt >= thr
            ext = np.r_[good, good]
            best = None
            for s0, L in zip(*find_runs(ext)):
                if s0 < 365 and L >= W and s0 <= start + W and s0 + L >= start:
                    best = (s0, min(L, 365))
            s0, L = best if best else (start, W)
            a = pd.Timestamp("2001-01-01") + pd.Timedelta(days=int(s0 % 365))
            b = pd.Timestamp("2001-01-01") + pd.Timedelta(days=int((s0 + L - 1) % 365))
            out.append(_f("G4", c, min(1.0, 1 - pval + 0.1), f"{a.strftime('%d %b')} - {b.strftime('%d %b')} ({L} d) missing in {int(t_obs)} of {len(years)} years (permutation p = {pval:.3f})", start_doy=int(s0 % 365 + 1), length_days=int(L), years=int(t_obs), p=float(pval)))
    return out


def detect_edges(frame, runs, cfg):
    """G5 (series starts late or ends early) and G6 (some stations stop while others continue)."""
    out = []
    n = len(frame)
    k = frame.shape[1]
    lead = runs[runs["position"] == "lead"]
    trail = runs[runs["position"] == "trail"]
    lead_cols = [r["column"] for _, r in lead.iterrows() if r["length"] >= cfg.edge_frac * n]
    trail_cols = [r["column"] for _, r in trail.iterrows() if r["length"] >= cfg.edge_frac * n]
    if lead_cols:
        out.append(_f("G5", "network" if len(lead_cols) == k and k > 1 else lead_cols[0], 0.8, "leading gap: " + ", ".join(f"{c} starts {frame[c].first_valid_index().date() if frame[c].notna().any() else 'never'}" for c in lead_cols[:6]), columns=lead_cols))
    if trail_cols:
        stops = {c: (frame[c].last_valid_index() if frame[c].notna().any() else None) for c in trail_cols}
        if k > 1 and len(trail_cols) < k:
            out.append(_f("G6", "network", 0.8, f"{len(trail_cols)} of {k} series stop early while others continue: " + ", ".join(f"{c} ends {d.date() if d is not None else 'never'}" for c, d in list(stops.items())[:6]), columns=trail_cols))
        else:
            out.append(_f("G5", "network" if k > 1 else trail_cols[0], 0.8, "trailing gap: " + ", ".join(f"{c} ends {d.date() if d is not None else 'never'}" for c, d in list(stops.items())[:6]), columns=trail_cols))
    return out


def detect_network(frame, runs, spd, g4_cols, cfg):
    """G7: gaps with the same start and end in a large share of the series; G8: one series carries all gaps."""
    out = []
    k = frame.shape[1]
    if k < 2:
        return out
    inter = runs[(runs["position"] == "interior") & (runs["length"] >= 5)]
    need = max(2, int(np.ceil(0.5 * k)))
    events = []
    used = set()
    for i, r in inter.iterrows():
        if i in used:
            continue
        tol = max(1, int(0.05 * r["length"]))
        match = inter[(abs(inter["i0"] - r["i0"]) <= tol) & (abs(inter["i1"] - r["i1"]) <= tol)]
        cols = set(match["column"])
        if len(cols) >= need:
            events.append((r["start"], r["end"], r["length"], sorted(cols)))
            used.update(match.index)
    if events:
        # recurring at the same time of year = seasonal pattern (G4), not an outage
        doy = [pd.Timestamp(e[0]).dayofyear for e in events]
        recurring = 0
        for d in doy:
            recurring += sum(1 for d2 in doy if abs(d2 - d) <= 10) >= cfg.seasonal_min_years
        if recurring < 0.8 * len(events):
            out.append(_f("G7", "network", 0.9, f"{len(events)} gaps with the same dates in at least {need} of {k} series (e.g. {pd.Timestamp(events[0][0]).date()} to {pd.Timestamp(events[0][1]).date()}, {len(events[0][3])} series)", events=len(events)))
    miss = frame.isna().sum()
    tot = int(miss.sum())
    if k >= 3 and tot > 0:
        top = miss.idxmax()
        others = miss.drop(top)
        if miss[top] / tot >= 0.9 and (others / len(frame)).max() <= 0.01 and miss[top] / len(frame) >= 0.01:
            out.append(_f("G8", top, 0.8, f"{top} carries {100 * miss[top] / tot:.0f} % of all missing values; all other series are complete (<= 1 %)", station=top))
    return out


def donor_table(frame, spd, cfg, gap_runs=None):
    """For every column, the other columns with overlap, correlation and availability inside its gaps."""
    rows = []
    min_n = max(10, int(cfg.donor_min_overlap_days * spd))
    obs = frame.notna()
    for a in frame.columns:
        ya = frame[a]
        gaps = ya.isna().to_numpy()
        for b in frame.columns:
            if a == b:
                continue
            both = obs[a] & obs[b]
            n_both = int(both.sum())
            r = np.nan
            if n_both >= min_n and ya[both].std() > 0 and frame[b][both].std() > 0:
                r = float(ya[both].corr(frame[b][both]))
            avail = float(obs[b].to_numpy()[gaps].mean()) if gaps.any() else np.nan
            rows.append(dict(column=a, donor=b, overlap_steps=n_both, overlap_days=n_both / spd, r=r, available_in_gaps=avail))
    return pd.DataFrame(rows, columns=["column", "donor", "overlap_steps", "overlap_days", "r", "available_in_gaps"])


def detect_thin_overlap(frame, runs, donors, spd, cfg, sparse_cols=()):
    out = []
    if frame.shape[1] < 2:
        return out
    long_runs = runs[runs["days"] >= cfg.long_gap_days]
    for c in frame.columns:
        if c in sparse_cols:
            continue
        r = long_runs[long_runs["column"] == c]
        if r.empty:
            continue
        d = donors[donors["column"] == c]
        flagged = []
        for _, run in r.iterrows():
            sl = slice(run["i0"], run["i1"] + 1)
            cand = []
            for _, row in d.iterrows():
                avail = frame[row["donor"]].iloc[sl].notna().mean()
                if avail >= 0.9:
                    cand.append(row)
            if cand:
                best = max(cand, key=lambda x: x["overlap_days"])
                if best["overlap_days"] < cfg.thin_overlap_days:
                    flagged.append((run, best))
        if flagged:
            run, best = flagged[0]
            out.append(_f("G9", c, 0.9, f"{c}: gap of {run['days']:.0f} d could use {best['donor']}, but they overlap only {best['overlap_days']:.0f} d", donor=best["donor"], overlap_days=float(best["overlap_days"])))
    return out


def detect_accumulated(frame, runs, spd, cfg, variable):
    """G13: the reading right after a gap holds the total of the gap (rainfall and other additive variables).

    Two tests. (1) Alone: after a gap the next reading is wet more often and larger than usual.
    (2) With neighbours: the reading depends on what the neighbours measured on the gap days (OLS, pooled over series).
    """
    out = []
    if variable not in cfg.additive:
        return out
    thr = 0.1
    flagged = set()
    for c in frame.columns:
        x = frame[c].to_numpy(float)
        n = len(x)
        r = runs[(runs["column"] == c) & (runs["position"] == "interior")]
        if len(r) < 15:
            continue
        post = np.array([x[i + 1] for i in r["i1"].to_numpy() if i + 1 < n], float)
        post = post[np.isfinite(post)]
        if len(post) < 15:
            continue
        base = x[np.isfinite(x)]
        p0 = np.mean(base >= thr)
        p1 = np.mean(post >= thr)
        k1 = int(np.sum(post >= thr))
        pv = stats.binomtest(k1, len(post), p0, alternative="greater").pvalue
        wet_base, wet_post = base[base >= thr], post[post >= thr]
        pv_amt = stats.mannwhitneyu(wet_post, wet_base, alternative="greater").pvalue if len(wet_post) >= 10 and len(wet_base) >= 10 else 1.0
        if pv < 0.001 and pv_amt < 0.01:
            flagged.add(c)
            out.append(_f("G13", c, 0.9, f"after {len(post)} gaps the next reading is wet {100 * p1:.0f} % of the time (usual {100 * p0:.0f} %) and {np.median(wet_post) / np.median(wet_base):.1f}x larger: accumulated totals likely", n=int(len(post)), p_freq=float(pv), p_amount=float(pv_amt)))
    k = frame.shape[1]
    if k >= 2:
        rows = []
        for c in frame.columns:
            nb = frame.drop(columns=c).mean(axis=1).to_numpy(float)
            x = frame[c].to_numpy(float)
            n = len(x)
            for _, run in runs[(runs["column"] == c) & (runs["position"] == "interior")].iterrows():
                e = run["i1"] + 1
                if e >= n or not np.isfinite(x[e]):
                    continue
                gap_nb = nb[run["i0"] : run["i1"] + 1]
                if not np.isfinite(nb[e]) or np.isnan(gap_nb).any():
                    continue
                rows.append((c, np.sqrt(x[e]), np.sqrt(max(nb[e], 0.0)), float(np.sum(np.sqrt(np.maximum(gap_nb, 0.0))))))
        if len(rows) >= 40:
            d = pd.DataFrame(rows, columns=["col", "y", "n1", "ne"])
            X = np.column_stack([np.ones(len(d)), d["n1"], d["ne"]])
            beta, res_, rank, _ = np.linalg.lstsq(X, d["y"].to_numpy(), rcond=None)
            resid = d["y"].to_numpy() - X @ beta
            s2 = float(resid @ resid) / (len(d) - 3)
            cov = s2 * np.linalg.inv(X.T @ X)
            t = beta[2] / np.sqrt(cov[2, 2])
            pv = float(stats.t.sf(t, len(d) - 3))
            if pv < 0.001 and beta[2] > 0.05:
                for c in frame.columns:
                    if c not in flagged:
                        out.append(_f("G13", c, 0.8, f"the reading after a gap grows with the neighbours' rain on the gap days (pooled, {len(d)} gaps, t = {t:.1f}): accumulated totals likely", n=int(len(d)), t=float(t), p=pv))
                        break
                else:
                    pass
    return out


def detect_extreme_linked(frame, runs, spd, cfg, skip_cols=(), before_only_cols=()):
    """G10/G14: gaps sit next to extreme values (edge test) and neighbours are extreme during the gaps."""
    out, tests = [], []
    rank = {c: _seasonal_rank(frame[c]) for c in frame.columns}
    zs_edge = {}
    for c in frame.columns:
        if c in skip_cols:
            continue
        r = runs[(runs["column"] == c) & (runs["position"] == "interior")]
        if len(r) < 5:
            continue
        vals = []
        for _, run in r.iterrows():
            a, b = run["i0"] - 1, run["i1"] + 1
            q = [rank[c].iloc[a], rank[c].iloc[b]] if (b < len(frame) and c not in before_only_cols) else [rank[c].iloc[a]]
            q = [v for v in q if np.isfinite(v)]
            if q:
                vals.append(np.mean(q))
        vals = np.array(vals)
        if len(vals) < 5:
            continue
        z = (vals.mean() - 0.5) / (np.sqrt(1.0 / 12.0) / np.sqrt(len(vals)))
        spread = np.mean(np.abs(vals - 0.5)) * 2
        zs_edge[c] = z
        tests.append(dict(test="edge_extremeness", scope=c, statistic=float(vals.mean()), z=float(z), n=int(len(vals)), note=f"mean seasonal rank next to gaps {vals.mean():.2f} (0.5 = random)"))
        if abs(z) >= cfg.z_crit:
            side = "high" if z > 0 else "low"
            out.append(_f("G10", c, min(1.0, abs(z) / 8), f"values next to the gaps are unusually {side} (mean rank {vals.mean():.2f}, z = {z:.1f}, {len(vals)} gaps): MNAR suspect", side=side, z=float(z)))
    # neighbour test: are the other series extreme when this one is missing?
    if frame.shape[1] >= 2:
        for c in frame.columns:
            if c in skip_cols:
                continue
            miss = frame[c].isna().to_numpy()
            if miss.sum() < 10:
                continue
            others = [rank[o].to_numpy() for o in frame.columns if o != c]
            M = np.vstack(others).T
            m = np.nanmean(M[miss], axis=1)
            m = m[np.isfinite(m)]
            if len(m) < 10:
                continue
            # effective sample size: gaps are long, count runs instead of cells
            s0, ln = find_runs(miss)
            n_eff = max(len(s0), 2)
            z = (m.mean() - 0.5) / (np.sqrt(1.0 / 12.0) / np.sqrt(n_eff) * np.sqrt(1.0 + np.var(ln) / max(np.mean(ln), 1) ** 2 * 0.0 + 1.0))
            tests.append(dict(test="neighbour_extremeness", scope=c, statistic=float(m.mean()), z=float(z), n=int(n_eff), note=f"mean seasonal rank of the other series while {c} is missing: {m.mean():.2f}"))
            if abs(z) >= cfg.z_crit and not any(f["code"] == "G10" and f["scope"] == c for f in out):
                side = "high" if z > 0 else "low"
                out.append(_f("G10", c, min(1.0, abs(z) / 8), f"other series are unusually {side} while {c} is missing (mean rank {m.mean():.2f}, z = {z:.1f}): gaps linked to {side} values", side=side, z=float(z)))
    return out, tests


# ----------------------------------------------------------------------------- mechanism tests


def season_test(frame, runs, cfg):
    tests = []
    r = runs[runs["position"] == "interior"]
    for c in frame.columns:
        rc = r[r["column"] == c]
        if len(rc) < 12:
            continue
        months = pd.DatetimeIndex(rc["start"]).month
        obs = np.bincount(months, minlength=13)[1:].astype(float)
        days = np.array([31, 28.25, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
        exp = obs.sum() * days / days.sum()
        chi2, p = stats.chisquare(obs, exp)
        tests.append(dict(test="gap_starts_by_month", scope=c, statistic=float(chi2), p_value=float(p), n=int(len(rc)), note=f"{len(rc)} gap starts; peak month {int(np.argmax(obs)) + 1}"))
    return tests


def little_mcar(frame, variable, min_pattern=10):
    """Little's (1988) MCAR test with the EM estimate of a multivariate normal. Informational: serial correlation inflates it."""
    from .methods.multistation import em_mvn

    X = frame.to_numpy(float)
    if variable == "rainfall":
        X = np.sqrt(np.maximum(X, 0.0))
    ok_cols = [j for j in range(X.shape[1]) if np.isfinite(X[:, j]).sum() > 30]
    X = X[:, ok_cols]
    if X.shape[1] < 2 or np.isfinite(X).all():
        return None
    mu, Sigma, _, _ = em_mvn(X, max_iter=80)
    obs = np.isfinite(X)
    d2, df_ = 0.0, 0
    pats = {}
    for i in range(len(X)):
        pats.setdefault(obs[i].tobytes(), []).append(i)
    used = 0
    for key, rows in pats.items():
        o = np.frombuffer(key, dtype=bool)
        if len(rows) < min_pattern or o.sum() == 0:
            continue
        xbar = X[rows][:, o].mean(axis=0)
        diff = xbar - mu[o]
        d2 += len(rows) * float(diff @ np.linalg.solve(Sigma[np.ix_(o, o)], diff))
        df_ += int(o.sum())
        used += 1
    df_ -= X.shape[1]
    if df_ <= 0:
        return None
    p = float(stats.chi2.sf(d2, df_))
    return dict(test="little_mcar", scope="network", statistic=float(d2), p_value=p, n=int(used), note=f"d2 = {d2:.1f}, df = {df_}, {used} patterns (informational: serial correlation inflates this test)")


def mar_auc(frame, cfg, max_cols=6):
    """Cross-validated AUC of the missing indicator on season alone and on season plus the other series."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score

    tests = []
    n = len(frame)
    doy = frame.index.dayofyear.to_numpy(float)
    cal = np.column_stack([np.sin(2 * np.pi * doy / 365.25), np.cos(2 * np.pi * doy / 365.25), np.sin(4 * np.pi * doy / 365.25), np.cos(4 * np.pi * doy / 365.25)])
    folds = np.array_split(np.arange(n), 5)  # blocked folds
    for c in frame.columns:
        y = frame[c].isna().to_numpy()
        if y.sum() < 20 or y.sum() > 0.8 * n:
            continue
        others = [o for o in frame.columns if o != c][:max_cols]
        feats = {"season": cal}
        if others:
            Z = frame[others].copy()
            Z = (Z - Z.mean()) / Z.std().replace(0, 1.0)
            Zv = Z.fillna(0.0).to_numpy()
            feats["season+series"] = np.column_stack([cal, Zv])
        aucs = {}
        for name, F in feats.items():
            preds = np.full(n, np.nan)
            for f in folds:
                tr = np.setdiff1d(np.arange(n), f)
                if y[tr].sum() < 5 or (~y[tr]).sum() < 5:
                    continue
                m = LogisticRegression(max_iter=200)
                m.fit(F[tr], y[tr])
                preds[f] = m.predict_proba(F[f])[:, 1]
            ok = np.isfinite(preds)
            if ok.sum() > 50 and 0 < y[ok].sum() < ok.sum():
                aucs[name] = float(roc_auc_score(y[ok], preds[ok]))
        if aucs:
            note = ", ".join(f"{k} {v:.2f}" for k, v in aucs.items())
            tests.append(dict(test="mar_auc", scope=c, statistic=aucs.get("season+series", aucs.get("season")), auc_season=aucs.get("season"), auc_series=aucs.get("season+series"), note=f"AUC of the missing indicator: {note}"))
    return tests


def mechanism_verdict(findings, tests, cfg):
    mn = [f for f in findings if f["code"] == "G10"]
    if mn:
        cols = sorted({f["scope"] for f in mn})
        return "MNAR suspect: gaps sit next to extreme values in " + ", ".join(cols) + " (a suspicion, not a proof; masked tests will be optimistic)"
    t = pd.DataFrame(tests) if tests else pd.DataFrame(columns=["test"])
    season = False
    if len(t):
        s = t[t["test"] == "gap_starts_by_month"]
        season = bool((s["p_value"] < 0.01).any()) if len(s) else False
        a = t[t["test"] == "mar_auc"]
        if len(a):
            season = season or bool((a["auc_season"] >= 0.65).any())
            series_dep = bool(((a["auc_series"] - a["auc_season"]) >= 0.08).any())
        else:
            series_dep = False
    else:
        series_dep = False
    if any(f["code"] in ("G4",) for f in findings):
        season = True
    if season or series_dep:
        why = []
        if season:
            why.append("season")
        if series_dep:
            why.append("values of other series")
        return "MAR-compatible: missingness depends on " + " and ".join(why) + " (observed information), no sign of dependence on the missing values"
    return "MCAR-compatible: no dependence on season, other series or extreme values was found"


# ----------------------------------------------------------------------------- main


def profile(df, variable: str = "generic", config: ProfileConfig | None = None, mechanism: bool = True) -> Profile:
    cfg = config or ProfileConfig()
    if isinstance(df, pd.Series):
        df = df.to_frame(df.name or "series")
    frame0, irregular = _regularise(df)
    spd = _steps_per_day(frame0.index)
    cleaned, f_sent, sent = detect_sentinels(frame0, variable, cfg)
    findings = list(f_sent)
    findings += detect_clip_flat(cleaned, variable, spd, cfg)
    runs = runs_table(cleaned, spd, cfg)
    g15, sparse_cols = detect_sparse(cleaned, spd, cfg)
    findings += g15
    findings += detect_length_classes(cleaned, runs, spd, sparse_cols, cfg)
    g4 = detect_seasonal(cleaned, runs, spd, sparse_cols, cfg)
    findings += g4
    findings += detect_edges(cleaned, runs, cfg)
    findings += detect_network(cleaned, runs, spd, [f["scope"] for f in g4], cfg)
    donors = donor_table(cleaned, spd, cfg)
    findings += detect_thin_overlap(cleaned, runs, donors, spd, cfg, sparse_cols)
    g13 = detect_accumulated(cleaned, runs, spd, cfg, variable)
    findings += g13
    ext, tests = detect_extreme_linked(cleaned, runs, spd, cfg, skip_cols={f["scope"] for f in g4}, before_only_cols={f["scope"] for f in g13})
    findings += ext
    tests = list(tests)
    if mechanism:
        tests += season_test(cleaned, runs, cfg)
        try:
            tests += mar_auc(cleaned, cfg)
        except Exception as e:  # sklearn missing or degenerate data
            tests.append(dict(test="mar_auc", scope="network", note=f"not run: {e}"))
        try:
            lm = little_mcar(cleaned, variable)
            if lm:
                tests.append(lm)
        except Exception as e:
            tests.append(dict(test="little_mcar", scope="network", note=f"not run: {e}"))
    verdict = mechanism_verdict(findings, tests, cfg)
    tests.append(dict(test="verdict", scope="network", note=verdict))
    # per-column summary
    rows = []
    for c in cleaned.columns:
        r = runs[runs["column"] == c]
        miss = cleaned[c].isna()
        rows.append(
            dict(column=c, n=len(cleaned), n_missing=int(miss.sum()), missing_frac=float(miss.mean()), n_runs=len(r), longest_days=float(r["days"].max()) if len(r) else 0.0,
                 median_run=float(r["length"].median()) if len(r) else 0.0, first_obs=cleaned[c].first_valid_index(), last_obs=cleaned[c].last_valid_index(),
                 decorrelation_steps=decorrelation_steps(cleaned[c]) if cleaned[c].notna().sum() > 50 else np.nan)
        )
    cols = pd.DataFrame(rows)
    runs = runs.merge(cols[["column", "decorrelation_steps"]], on="column", how="left")
    runs["length_in_decorr"] = runs["length"] / runs["decorrelation_steps"]
    fdf = pd.DataFrame(findings, columns=["code", "scope", "strength", "evidence", "detail"])
    if len(fdf):
        fdf = fdf.sort_values(["code", "scope"], key=lambda s: s.map(lambda v: int(v[1:]) if isinstance(v, str) and v.startswith("G") and v[1:].isdigit() else v)).reset_index(drop=True)
    return Profile(
        variable=variable, freq=_freq_name(spd), steps_per_day=spd, n=len(cleaned), start=cleaned.index[0], end=cleaned.index[-1], columns=cols, runs=runs,
        findings=fdf, mechanism=pd.DataFrame(tests), donors=donors, cleaned=cleaned, meta={"sentinels": sent, "irregular_share": irregular}, config=cfg,
    )
