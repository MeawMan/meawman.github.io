"""Build (series, others, ctx) for a synthetic basin variable, the way a user's project files would be assembled.

    series, others, ctx = make_task(basin, "rainfall", "R03", observed=case_observed_frame)

`observed` is the table with gaps (a GapResult.observed); without it the truth is used (for masked tests).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .methods import Ctx
from .synth import rain_product, temperature_product


def _gauge_coords(basin) -> pd.DataFrame:
    """Nominal gauge positions: weighted centroid of the rain stations each gauge sees (the downstream gauge sits between)."""
    st = basin["rainfall"].extras["stations"]
    rows = {}
    for g in basin["streamflow"].meta["gauges"]:
        w = np.asarray(g["weights"], float)
        rows[g["gauge"]] = (float((w * st["x_km"].to_numpy()).sum() / w.sum()), float((w * st["y_km"].to_numpy()).sum() / w.sum()))
    ds = basin["streamflow"].meta.get("downstream")
    if ds:
        up = rows[ds["upstream"]]
        rows[ds["gauge"]] = (up[0] - 6.0, up[1] - 8.0)
    return pd.DataFrame(rows, index=["x_km", "y_km"]).T.rename_axis("station")


def flow_areas(basin) -> dict:
    areas = {g["gauge"]: float(g["area_km2"]) for g in basin["streamflow"].meta["gauges"]}
    ds = basin["streamflow"].meta.get("downstream")
    if ds:
        areas[ds["gauge"]] = areas[ds["upstream"]] + float(ds["lateral_area_km2"])
    return areas


def gauge_precip(basin, gauge: str) -> pd.Series:
    """Weighted mean rainfall (mm/day) over the stations a gauge's catchment sees (truth rainfall)."""
    rain = basin["rainfall"].truth
    ws = {g["gauge"]: g["weights"] for g in basin["streamflow"].meta["gauges"]}
    ds = basin["streamflow"].meta.get("downstream")
    w = ws.get(gauge) or (ws[ds["upstream"]] if ds else None)
    return pd.Series(rain.to_numpy() @ np.asarray(w, float), index=rain.index, name=f"P_{gauge}")


def make_task(basin: dict, variable: str, target: str, observed: pd.DataFrame | None = None, product: bool = True, seed: int = 0, surrogate: bool = False, river: bool = True):
    """Return (series, others, ctx) for `target` in basin[variable]."""
    ser = basin[variable]
    frame = observed if observed is not None else ser.truth
    series = frame[target]
    others = frame.drop(columns=[target])
    ctx = Ctx(variable=variable if variable in ("rainfall", "temperature", "streamflow", "sediment", "groundwater", "tide", "salinity") else "generic", target=target, seed=seed)
    if variable == "sediment":
        cols = ["discharge_m3s"] + (["turbidity_ntu"] if surrogate else [])
        full = ser.truth
        others = pd.concat([(frame[c] if c in frame.columns else full[c]) for c in cols], axis=1)  # load_t_day is never given: it would leak the answer
        ctx.meta["driver"] = "discharge_m3s"
        if surrogate:
            ctx.meta["surrogate"] = "turbidity_ntu"
        return series, others, ctx
    if variable == "tide":
        cols = {}
        if river:
            main = basin["streamflow"].truth.columns[-1]
            q = basin["streamflow"].truth[main]
            qh = q.reindex(q.index.union(series.index)).interpolate("time").reindex(series.index).ffill().bfill()
            cols["river_q"] = qh
            ctx.meta["driver"] = "river_q"
        others = pd.DataFrame(cols, index=series.index) if cols else None
        ctx.meta["latitude"] = 22.0
        return series, others, ctx
    if variable == "groundwater":
        rain = basin["rainfall"].truth.mean(axis=1).reindex(series.index)
        others = pd.DataFrame({"rain_areal": rain})
        ctx.meta["driver"] = "rain_areal"
        ctx.meta["precip"] = rain
        return series, others, ctx
    if variable == "rating":
        # stage <-> discharge: only the paired variable is given to the method; the generator's internals (steady flow, true h0) stay hidden
        if target == "discharge_m3s":
            driver, ctx.variable = "stage_m", "streamflow"
        elif target == "stage_m":
            driver, ctx.variable = "discharge_m3s", "stage"
        else:
            raise ValueError("rating tasks are built for discharge_m3s or stage_m")
        others = frame[[driver]]
        ctx.meta["driver"] = driver
        ctx.meta["gaugings"] = ser.extras["gaugings"][["date", "stage_m", "discharge_m3s", "u_rel"]].copy()
        return series, others, ctx
    if variable == "rainfall":
        ctx.coords = ser.extras["stations"][["x_km", "y_km"]]
        if product:
            p = rain_product(ser.truth, target, seed=seed + 11)
            others = pd.concat([others, p], axis=1)
            ctx.meta["product"] = [p.name]
    elif variable == "temperature":
        st = ser.extras["stations"]
        ctx.coords = st[["elevation_m"]]
        if product:
            p = temperature_product(ser.truth, target, seed=seed + 12)
            others = pd.concat([others, p], axis=1)
            ctx.meta["product"] = [p.name]
    elif variable == "streamflow":
        ctx.coords = _gauge_coords(basin)
        ctx.meta["areas_km2"] = flow_areas(basin)
        ctx.meta["precip"] = gauge_precip(basin, target)
    return series, others, ctx
