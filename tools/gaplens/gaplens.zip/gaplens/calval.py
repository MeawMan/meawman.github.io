"""Calibration and validation of one series against another (catalog section 14).

The user brings two series: an observation and a simulation (a model, a product, a second gauge, a rating curve). The module
    1. aligns them and looks for a time lag, a unit factor or a datum offset            align()
    2. cuts the record into calibration and validation periods                          make_splits()
    3. fits a correction (bias, linear, lag, quantile mapping) or the parameters of a   fit_correction(), calibrate()
       built-in model (power-law rating, linear reservoir, GR4J, your own function)
    4. validates with all relevant metrics, block-bootstrap intervals and a rating      validate()
    5. runs the whole cycle on every split and warns about over-fitting and equifinality run_calval()

    rep = validate(obs, sim)                  # metrics, intervals, ratings
    out = run_calval(model, forcing, obs, scheme="differential")
    print(rep.summary()); print(out.summary())

The qualitative ratings use thresholds that you can edit (THRESHOLDS). NSE, PBIAS and RSR follow Moriasi et al. (2007, 2015);
the KGE bands are indicative only: KGE has no standard classes, and a KGE of -0.41 equals the skill of the mean of the observations
(Knoben et al. 2019).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd
from scipy import optimize, stats

from . import metrics as M
from .methods.base import steps_per_day

EPS = 1e-12

# ------------------------------------------------------------------------------------------------ thresholds
# Each entry: list of (upper limit, label) tested in order for "lower is better" measures (abs value for pbias),
# or (lower limit, label) for "higher is better" measures. Edit the dictionaries or pass your own `thresholds`.
THRESHOLDS = {
    "moriasi2015": {
        "source": "Moriasi et al. (2015), Trans. ASABE 58(6):1763-1785, daily/monthly streamflow",
        "nse": ("higher", [(0.80, "very good"), (0.70, "good"), (0.50, "satisfactory")], "unsatisfactory"),
        "pbias": ("abs_lower", [(5.0, "very good"), (10.0, "good"), (15.0, "satisfactory")], "unsatisfactory"),
        "rsr": ("lower", [(0.45, "very good"), (0.55, "good"), (0.70, "satisfactory")], "unsatisfactory"),
        "kge": ("higher", [(0.75, "good"), (0.50, "fair"), (-0.41, "poor")], "worse than the mean of the observations"),
    },
    "moriasi2007": {
        "source": "Moriasi et al. (2007), Trans. ASABE 50(3):885-900, monthly streamflow",
        "nse": ("higher", [(0.75, "very good"), (0.65, "good"), (0.50, "satisfactory")], "unsatisfactory"),
        "pbias": ("abs_lower", [(10.0, "very good"), (15.0, "good"), (25.0, "satisfactory")], "unsatisfactory"),
        "rsr": ("lower", [(0.50, "very good"), (0.60, "good"), (0.70, "satisfactory")], "unsatisfactory"),
        "kge": ("higher", [(0.75, "good"), (0.50, "fair"), (-0.41, "poor")], "worse than the mean of the observations"),
    },
}


def rate(name: str, value: float, thresholds: dict) -> str:
    spec = thresholds.get(name)
    if spec is None or not np.isfinite(value):
        return ""
    kind, bands, worst = spec
    for lim, label in bands:
        if kind == "higher" and value > lim:
            return label
        if kind == "lower" and value <= lim:
            return label
        if kind == "abs_lower" and abs(value) < lim:
            return label
    return worst


# ------------------------------------------------------------------------------------------------ alignment

KNOWN_FACTORS = {
    "x1000 (m3 to L, m to mm, mm/h to um/h)": 1000.0, "x0.001": 0.001, "x86.4 (m3/s to mm/day on 1000 km2, or m3/s to 1000 m3/day)": 86.4, "x1/86.4": 1 / 86.4,
    "x0.3048 (ft to m)": 0.3048, "x3.28084 (m to ft)": 3.28084, "x0.0283168 (ft3/s to m3/s)": 0.0283168, "x35.3147 (m3/s to ft3/s)": 35.3147,
    "x25.4 (inch to mm)": 25.4, "x0.0393701 (mm to inch)": 0.0393701, "x24": 24.0, "x1/24": 1 / 24.0, "x3600": 3600.0, "x1/3600": 1 / 3600.0, "x100 (m to cm)": 100.0, "x0.01 (cm to m)": 0.01,
}


@dataclass
class Aligned:
    obs: pd.Series
    sim: pd.Series
    step: pd.Timedelta
    lag_steps: int = 0
    lag_curve: pd.DataFrame | None = None
    notes: list = field(default_factory=list)
    unit_hint: str = ""
    offset: float = 0.0
    n_pairs: int = 0

    def summary(self) -> str:
        head = f"{self.n_pairs} paired values at a step of {self.step}."
        return "\n".join([head] + [f"  - {n}" for n in self.notes]) if self.notes else head + "\n  No lag, unit or datum problem found."


def _regularise(s: pd.Series) -> pd.Series:
    s = s.copy()
    s.index = pd.DatetimeIndex(s.index)
    s = s[~s.index.duplicated(keep="first")].sort_index()
    return s.astype(float)


def _median_step(index) -> pd.Timedelta:
    d = pd.Series(index[1:] - index[:-1])
    return d.median() if len(d) else pd.Timedelta(days=1)


def cross_correlation(o: pd.Series, s: pd.Series, max_lag: int) -> pd.DataFrame:
    """Pearson r between o(t) and s(t + k) for k = -max_lag..max_lag (positive k: the simulation is later than the observation)."""
    rows = []
    for k in range(-max_lag, max_lag + 1):
        sk = s.shift(-k)
        ok = o.notna() & sk.notna()
        if ok.sum() >= 10 and o[ok].std() > EPS and sk[ok].std() > EPS:
            rows.append((k, float(np.corrcoef(o[ok], sk[ok])[0, 1]), int(ok.sum())))
        else:
            rows.append((k, np.nan, int(ok.sum())))
    return pd.DataFrame(rows, columns=["lag_steps", "r", "n"])


def align(obs: pd.Series, sim: pd.Series, how: str = "mean", max_lag: int | None = None, apply_lag: bool = False, detect: bool = True) -> Aligned:
    """Put two series on one regular time axis and look for a time shift, a unit factor and a datum offset.

    `how` is the aggregation when one series has a finer step than the other ("mean" or "sum"). The lag search compares r at
    lags up to `max_lag` steps; the best lag is reported, and applied to `sim` only when apply_lag=True.
    """
    o, s = _regularise(obs), _regularise(sim)
    so, ss = _median_step(o.index), _median_step(s.index)
    step = max(so, ss)
    notes = []
    if so != ss:
        rule = pd.tseries.frequencies.to_offset(step)
        f = (lambda x: x.resample(rule).sum(min_count=1)) if how == "sum" else (lambda x: x.resample(rule).mean())
        if so < ss:
            o = f(o)
        else:
            s = f(s)
        notes.append(f"The series have different steps ({so} and {ss}); the finer one was aggregated by the {how} to {step}.")
    full = pd.date_range(min(o.index.min(), s.index.min()), max(o.index.max(), s.index.max()), freq=step)
    o, s = o.reindex(full), s.reindex(full)
    both = o.notna() & s.notna()
    out = Aligned(o, s, step, n_pairs=int(both.sum()))
    if both.sum() < 20:
        out.notes.append("Fewer than 20 paired values: no lag, unit or datum check was possible.")
        return out
    out.notes.extend(notes)
    if not detect:
        return out
    spd = steps_per_day(full)
    ml = max_lag if max_lag is not None else int(min(max(3, round(spd * 2)), 72, both.sum() // 10))
    cc = cross_correlation(o, s, ml)
    out.lag_curve = cc
    r0 = float(cc.loc[cc["lag_steps"] == 0, "r"].iloc[0]) if (cc["lag_steps"] == 0).any() else np.nan
    best = cc.loc[cc["r"].idxmax()] if cc["r"].notna().any() else None
    if best is not None and int(best["lag_steps"]) != 0 and np.isfinite(r0) and best["r"] - r0 > 0.02:
        k = int(best["lag_steps"])
        out.lag_steps = k
        hours = k * step.total_seconds() / 3600
        msg = f"The simulation is {abs(k)} step(s) {'later' if k > 0 else 'earlier'} than the observation (r {r0:.3f} at lag 0, {best['r']:.3f} at lag {k})."
        if step <= pd.Timedelta(hours=1) and abs(hours) >= 1 and abs(hours - round(hours)) < 1e-6:
            msg += f" A shift of {round(hours)} h can be a time-zone or daylight-saving mistake."
        if step == pd.Timedelta(days=1) and abs(k) == 1:
            msg += " A one-day shift can come from the day boundary (reading at 09:00 against midnight totals)."
        out.notes.append(msg)
        if apply_lag:
            out.sim = out.sim.shift(-k)
            out.notes.append(f"The lag was removed from the simulation (shifted by {-k} steps).")
    # unit factor and datum offset, from the regression on the pairs (after the lag, if it was applied)
    oo, ss_ = out.obs, out.sim
    if out.lag_steps and not apply_lag:
        ss_ = ss_.shift(-out.lag_steps)  # judge the unit and datum on the lag-corrected pairs, without changing the returned simulation
    ok = oo.notna() & ss_.notna()
    x, y = ss_[ok].to_numpy(), oo[ok].to_numpy()
    if np.std(x) > EPS and np.std(y) > EPS:
        slope, icpt, r, *_ = stats.linregress(x, y)
        if r > 0.8:
            ratio = float(np.nanmedian(y[x > 0] / x[x > 0])) if (x > 0).sum() > 10 else slope
            for label, fac in KNOWN_FACTORS.items():
                if abs(slope / fac - 1) < 0.25 and abs(ratio / fac - 1) < 0.06 and abs(fac - 1) > 1e-9:  # slope is attenuated by noise in the simulation, the median ratio is not
                    out.unit_hint = label
                    out.notes.append(f"The observation is about {fac:g} times the simulation (slope {slope:.4g}, r {r:.2f}): check the units ({label}).")
                    break
            else:
                if abs(slope - 1) < 0.08 and abs(icpt) > 0.25 * np.std(y) and r > 0.9:
                    out.offset = float(np.mean(y - x))
                    out.notes.append(f"The two series agree in shape but differ by a constant of {out.offset:.4g}: check the datum or zero level.")
    return out


# ------------------------------------------------------------------------------------------------ splits


@dataclass
class Split:
    name: str
    calib: np.ndarray  # boolean mask
    valid: np.ndarray

    def describe(self, index) -> str:
        c, v = index[self.calib], index[self.valid]
        return f"{self.name}: calibrate {c.min().date()}..{c.max().date()} ({self.calib.sum()}), validate {v.min().date()}..{v.max().date()} ({self.valid.sum()})"


SCHEMES = ("split_sample", "split_sample_swap", "differential", "blocked_kfold", "rolling_origin", "leave_one_year_out")


def make_splits(index: pd.DatetimeIndex, scheme: str = "split_sample", obs: pd.Series | None = None, n_folds: int = 5, calib_frac: float = 0.5, warmup: int = 0, n_origins: int = 4) -> list:
    """Calibration and validation masks. `warmup` steps at the start of the record are excluded from both.

    split_sample        calibrate on the first part, validate on the rest (Klemes 1986 split-sample test)
    split_sample_swap   the split-sample test in both directions
    differential        calibrate on the driest half of the years, validate on the wettest, and the reverse (needs `obs`)
    blocked_kfold       k contiguous blocks, each used once for validation
    rolling_origin      expanding calibration window; the next block validates (time-series cross-validation)
    leave_one_year_out  each calendar year validates once
    """
    n = len(index)
    base = np.ones(n, bool)
    base[: max(warmup, 0)] = False
    pos = np.arange(n)
    out: list[Split] = []
    if scheme in ("split_sample", "split_sample_swap"):
        cut = int(n * calib_frac)
        out.append(Split("first half -> second half" if calib_frac == 0.5 else f"first {calib_frac:.0%} -> rest", base & (pos < cut), base & (pos >= cut)))
        if scheme == "split_sample_swap":
            out.append(Split("second half -> first half", base & (pos >= cut), base & (pos < cut)))
    elif scheme == "differential":
        if obs is None:
            raise ValueError("the differential scheme needs the observed series")
        ann = obs.groupby(obs.index.year).mean().dropna()
        if len(ann) < 4:
            raise ValueError("the differential scheme needs at least four years")
        years = ann.sort_values().index.to_numpy()
        dry, wet = set(years[: len(years) // 2]), set(years[len(years) - len(years) // 2:])
        yr = index.year.to_numpy()
        is_dry, is_wet = np.isin(yr, list(dry)), np.isin(yr, list(wet))
        out.append(Split("dry years -> wet years", base & is_dry, base & is_wet))
        out.append(Split("wet years -> dry years", base & is_wet, base & is_dry))
    elif scheme == "blocked_kfold":
        edges = np.linspace(0, n, n_folds + 1).astype(int)
        for i in range(n_folds):
            v = (pos >= edges[i]) & (pos < edges[i + 1])
            out.append(Split(f"fold {i + 1}/{n_folds}", base & ~v, base & v))
    elif scheme == "rolling_origin":
        first = int(n * 0.4)
        edges = np.linspace(first, n, n_origins + 1).astype(int)
        for i in range(n_origins):
            out.append(Split(f"origin {i + 1}/{n_origins}", base & (pos < edges[i]), base & (pos >= edges[i]) & (pos < edges[i + 1])))
    elif scheme == "leave_one_year_out":
        yr = index.year.to_numpy()
        for y in np.unique(yr):
            v = yr == y
            if v.sum() > 10:
                out.append(Split(f"year {y}", base & ~v, base & v))
    else:
        raise ValueError(f"unknown scheme {scheme!r}; choose from {SCHEMES}")
    return out


# ------------------------------------------------------------------------------------------------ corrections


class Correction:
    """A correction learned on calibration pairs (obs, sim) and applied to any simulated series."""

    name = "none"

    def fit(self, o: np.ndarray, s: np.ndarray):
        return self

    def apply(self, s: np.ndarray) -> np.ndarray:
        return s

    def describe(self) -> str:
        return self.name


class BiasScale(Correction):
    name = "bias_scale"

    def fit(self, o, s):
        self.k = float(np.sum(o) / np.sum(s)) if abs(np.sum(s)) > EPS else 1.0
        return self

    def apply(self, s):
        return s * self.k

    def describe(self):
        return f"multiply by {self.k:.4g}"


class BiasShift(Correction):
    name = "bias_shift"

    def fit(self, o, s):
        self.d = float(np.mean(o - s))
        return self

    def apply(self, s):
        return s + self.d

    def describe(self):
        return f"add {self.d:.4g}"


class LinearCorrection(Correction):
    name = "linear"

    def fit(self, o, s):
        if np.std(s) < EPS:
            self.a, self.b = float(np.mean(o)), 0.0
        else:
            self.b, self.a = np.polyfit(s, o, 1)
        return self

    def apply(self, s):
        return self.a + self.b * s

    def describe(self):
        return f"obs = {self.a:.4g} + {self.b:.4g} sim"


class PowerCorrection(Correction):
    name = "power"

    def fit(self, o, s):
        ok = (o > 0) & (s > 0)
        if ok.sum() < 10:
            self.a, self.b = 1.0, 1.0
            return self
        b, la = np.polyfit(np.log(s[ok]), np.log(o[ok]), 1)
        r = np.log(o[ok]) - (la + b * np.log(s[ok]))
        self.a, self.b = float(np.exp(la + 0.5 * np.var(r))), float(b)
        return self

    def apply(self, s):
        return self.a * np.maximum(s, 0.0) ** self.b

    def describe(self):
        return f"obs = {self.a:.4g} sim^{self.b:.4g}"


class QuantileMapping(Correction):
    """Empirical quantile mapping with a constant ratio (or difference) beyond the calibration range."""

    name = "quantile_map"

    def __init__(self, n_q: int = 100, multiplicative: bool = True):
        self.n_q, self.mult = n_q, multiplicative

    def fit(self, o, s):
        q = np.linspace(0.005, 0.995, self.n_q)
        self.qs, self.qo = np.quantile(s, q), np.quantile(o, q)
        self.qs, idx = np.unique(self.qs, return_index=True)
        self.qo = self.qo[idx]
        if self.mult:
            self.hi = float(self.qo[-1] / self.qs[-1]) if abs(self.qs[-1]) > EPS else 1.0
            self.lo = float(self.qo[0] / self.qs[0]) if abs(self.qs[0]) > EPS else 1.0
        else:
            self.hi, self.lo = float(self.qo[-1] - self.qs[-1]), float(self.qo[0] - self.qs[0])
        return self

    def apply(self, s):
        out = np.interp(s, self.qs, self.qo)
        above, below = s > self.qs[-1], s < self.qs[0]
        out[above] = s[above] * self.hi if self.mult else s[above] + self.hi
        out[below] = s[below] * self.lo if self.mult else s[below] + self.lo
        return out

    def describe(self):
        return f"empirical quantile mapping on {self.n_q} quantiles"


CORRECTIONS = {"none": Correction, "bias_scale": BiasScale, "bias_shift": BiasShift, "linear": LinearCorrection, "power": PowerCorrection, "quantile_map": QuantileMapping}


def fit_correction(name: str, obs: pd.Series, sim: pd.Series, mask: np.ndarray | None = None) -> Correction:
    ok = obs.notna() & sim.notna()
    if mask is not None:
        ok &= mask
    o, s = obs[ok].to_numpy(float), sim[ok].to_numpy(float)
    if len(o) < 10:
        return Correction()
    return CORRECTIONS[name]().fit(o, s)


def apply_correction(corr: Correction, sim: pd.Series) -> pd.Series:
    v = sim.to_numpy(float)
    out = np.full_like(v, np.nan)
    ok = np.isfinite(v)
    out[ok] = corr.apply(v[ok])
    return pd.Series(out, index=sim.index)


# ------------------------------------------------------------------------------------------------ validation report

CORE_METRICS = {
    "rmse": M.rmse, "mae": M.mae, "bias": M.bias, "pbias": M.pbias, "nse": M.nse,
    "kge": lambda o, s: M.kge_parts(o, s)[0], "kge2012": lambda o, s: M.kge_parts(o, s, modified=True)[0],
    "pearson": M._corr, "log_nse": M.log_nse, "npkge": M.npkge,
}


def _block_length(x: np.ndarray, n: int) -> int:
    a = M.acf(pd.Series(x).interpolate(limit_direction="both").to_numpy(), 60)
    dec = int(np.argmax(a < 1 / np.e)) + 1 if (a < 1 / np.e).any() else 60
    return int(min(max(dec, 5), max(n // 10, 5)))


def block_bootstrap(o: np.ndarray, s: np.ndarray, fns: dict, n_boot: int = 200, ci: float = 0.9, seed: int = 0) -> dict:
    """Moving-block bootstrap of the paired values; returns {metric: (low, high)}."""
    n = len(o)
    if n < 30:
        return {k: (np.nan, np.nan) for k in fns}
    L = _block_length(o - s, n)
    rng = np.random.default_rng(seed)
    n_blocks = int(np.ceil(n / L))
    draws = {k: [] for k in fns}
    for _ in range(n_boot):
        starts = rng.integers(0, n - L + 1, n_blocks)
        idx = (starts[:, None] + np.arange(L)[None, :]).ravel()[:n]
        bo, bs = o[idx], s[idx]
        for k, f in fns.items():
            try:
                draws[k].append(f(bo, bs))
            except Exception:  # noqa: BLE001
                draws[k].append(np.nan)
    a = (1 - ci) / 2
    return {k: (float(np.nanquantile(v, a)), float(np.nanquantile(v, 1 - a))) if np.isfinite(v).sum() > 10 else (np.nan, np.nan) for k, v in draws.items()}


@dataclass
class Validation:
    table: pd.DataFrame  # metric, value, low, high, rating
    all_metrics: dict
    n: int
    source: str
    notes: list = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"Validation on {self.n} paired values. Ratings: {self.source}."]
        keep = ["nse", "kge", "pbias", "rsr", "rmse", "mae", "pearson", "log_nse"]
        t = self.table.set_index("metric")
        for m in keep:
            if m in t.index:
                r = t.loc[m]
                ci = f" [{r['low']:.3f}, {r['high']:.3f}]" if np.isfinite(r["low"]) else ""
                lines.append(f"  {m:8s} {r['value']:9.3f}{ci}  {r['rating']}")
        for n in self.notes:
            lines.append(f"  ! {n}")
        return "\n".join(lines)

    def rating_of(self, metric: str) -> str:
        t = self.table.set_index("metric")
        return t.loc[metric, "rating"] if metric in t.index else ""


def validate(obs: pd.Series, sim: pd.Series, mask: np.ndarray | None = None, groups=None, variable: str = "generic", thresholds: str | dict = "moriasi2015", n_boot: int = 200, ci: float = 0.9, seed: int = 0, ctx: dict | None = None) -> Validation:
    """All metrics for one pair of series. `groups` selects metric groups of the library (default: the variable's own set)."""
    th = THRESHOLDS[thresholds] if isinstance(thresholds, str) else thresholds
    ok = obs.notna() & sim.notna()
    if mask is not None:
        ok &= mask
    o, s = obs[ok].to_numpy(float), sim[ok].to_numpy(float)
    notes = []
    if len(o) < 10:
        return Validation(pd.DataFrame(columns=["metric", "value", "low", "high", "rating"]), {}, len(o), th.get("source", "custom"), ["Fewer than 10 paired values."])
    hidden = pd.Series(ok.to_numpy(), index=obs.index)
    full = M.score(obs, sim.where(ok), hidden, groups=groups, variable=variable, ctx=ctx or {})
    values = {k.split(".", 1)[1] if "." in k else k: v for k, v in full.items() if k != "n_hidden"}
    values["rsr"] = float(M.rmse(o, s) / np.std(o)) if np.std(o) > EPS else np.nan
    for k, f in CORE_METRICS.items():
        values.setdefault(k, f(o, s))
    cis = block_bootstrap(o, s, {**CORE_METRICS, "rsr": lambda a, b: M.rmse(a, b) / max(np.std(a), EPS)}, n_boot=n_boot, ci=ci, seed=seed)
    rows = []
    for k, v in values.items():
        lo, hi = cis.get(k, (np.nan, np.nan))
        rows.append((k, v, lo, hi, rate(k, v, th)))
    order = ["nse", "kge", "kge2012", "pbias", "rsr", "rmse", "mae", "bias", "pearson", "log_nse", "npkge"]
    rows.sort(key=lambda r: (order.index(r[0]) if r[0] in order else 99, r[0]))
    table = pd.DataFrame(rows, columns=["metric", "value", "low", "high", "rating"])
    if np.isfinite(values.get("kge_beta", np.nan)) and abs(values["kge_beta"] - 1) > 0.2:
        notes.append(f"The simulation volume is {100 * (values['kge_beta'] - 1):+.0f} % off the observations; a bias correction may help.")
    if np.isfinite(values.get("pearson", np.nan)) and values["pearson"] > 0.9 and np.isfinite(values.get("nse", np.nan)) and values["nse"] < 0.5:
        notes.append("High correlation but low NSE: the shape is right and the scale or timing is off; test a linear correction or a lag.")
    if np.nanmin([values.get("nse", 1), values.get("kge", 1)]) < 0:
        notes.append("NSE or KGE below the mean-of-observations benchmark: the simulation is worse than a constant.")
    return Validation(table, values, len(o), th.get("source", "custom"), notes)


# ------------------------------------------------------------------------------------------------ models and calibration


@dataclass
class Model:
    """A simulator with named parameters. run(theta, forcing) returns an array the length of the record."""

    name: str
    params: list
    bounds: object  # list of (lo, hi) or callable(forcing) -> list
    run: Callable
    log: tuple = ()
    notes: str = ""

    def get_bounds(self, forcing):
        b = self.bounds(forcing) if callable(self.bounds) else self.bounds
        return [(float(lo), float(hi)) for lo, hi in b]

    def simulate(self, theta, forcing) -> np.ndarray:
        return np.asarray(self.run(np.asarray(theta, float), forcing), float)


def rating_power_law() -> Model:
    """Q = a (h - h0)^b. forcing = {"x": stage}."""

    def bounds(f):
        h = np.asarray(f["x"], float)
        h = h[np.isfinite(h)]
        span = max(np.ptp(h), 1e-3)
        return [(1e-3, 1e4), (0.5, 4.0), (h.min() - 2 * span, h.min() - 1e-4)]

    def run(th, f):
        a, b, h0 = th
        return a * np.maximum(np.asarray(f["x"], float) - h0, 0.0) ** b

    return Model("power-law rating", ["a", "b", "h0"], bounds, run, log=(True, False, False), notes="catalog 8.1")


def linear_reservoir() -> Model:
    """One linear store fed by a fraction c of the rainfall; Q = scale * S / K. forcing = {"P": rain}."""

    def run(th, f):
        K, c, scale = th
        P = np.nan_to_num(np.asarray(f["P"], float))
        out = np.empty(len(P))
        S = 0.0
        for t in range(len(P)):
            S += c * P[t]
            q = S / K
            S -= q
            out[t] = q
        return scale * out

    return Model("linear reservoir", ["K", "c", "scale"], [(1.0, 300.0), (0.01, 1.5), (1e-3, 1e4)], run, log=(True, False, True), notes="the simplest rainfall-runoff model; useful as a baseline")


def gr4j_model() -> Model:
    """GR4J (Perrin et al. 2003) with a volume scale, so the output can be in m3/s. forcing = {"P": rain, "E": pet}."""
    from .methods.streamflow import gr4j_run

    def run(th, f):
        x1, x2, x3, x4, scale = th
        return scale * gr4j_run(np.ascontiguousarray(f["P"], dtype=np.float64), np.ascontiguousarray(f["E"], dtype=np.float64), x1, x2, x3, x4)

    return Model("GR4J", ["x1", "x2", "x3", "x4", "scale"], [(20.0, 1500.0), (-4.0, 4.0), (10.0, 400.0), (0.6, 4.0), (1e-2, 1e3)], run, log=(True, False, True, False, True))


def custom_model(fn: Callable, names: list, bounds: list, log: tuple = (), name: str = "custom") -> Model:
    """Wrap your own function fn(theta, forcing) -> array."""
    return Model(name, list(names), list(bounds), fn, log=tuple(log))


MODELS = {"rating": rating_power_law, "linear_reservoir": linear_reservoir, "gr4j": gr4j_model}

OBJECTIVES = {
    "nse": ("max", M.nse),
    "kge": ("max", lambda o, s: M.kge_parts(o, s)[0]),
    "kge2012": ("max", lambda o, s: M.kge_parts(o, s, modified=True)[0]),
    "log_nse": ("max", M.log_nse),
    "npkge": ("max", M.npkge),
    "rmse": ("min", M.rmse),
    "mae": ("min", M.mae),
    "nse_logmix": ("max", lambda o, s: 0.5 * M.nse(o, s) + 0.5 * (M.log_nse(o, s) if np.isfinite(M.log_nse(o, s)) else M.nse(o, s))),
}


def _to_internal(theta, log):
    th = np.array(theta, float)
    for i, lg in enumerate(log):
        if lg:
            th[i] = np.log10(th[i])
    return th


def _from_internal(z, log):
    th = np.array(z, float)
    for i, lg in enumerate(log):
        if lg:
            th[i] = 10.0 ** th[i]
    return th


def _sce_ua(f, lo, hi, budget, rng, x0=None):
    """Shuffled complex evolution (Duan et al. 1992), compact form. Minimises f within [lo, hi] using about `budget` evaluations."""
    n = len(lo)
    ngs = max(2, min(5, budget // (4 * (2 * n + 1))))
    npg, nps = 2 * n + 1, n + 1
    npop = ngs * npg
    pop = lo + rng.random((npop, n)) * (hi - lo)
    if x0 is not None:
        pop[0] = np.clip(x0, lo, hi)
    cost = np.array([f(p) for p in pop])
    used = npop
    while used < budget:
        order = np.argsort(cost)
        pop, cost = pop[order], cost[order]
        for g in range(ngs):
            idx = np.arange(g, npop, ngs)
            cx, cf = pop[idx], cost[idx]
            for _ in range(npg):
                w = 2.0 * (npg + 1 - np.arange(1, npg + 1)) / (npg * (npg + 1))
                sel = np.sort(rng.choice(npg, size=nps, replace=False, p=w))
                sx, sf = cx[sel], cf[sel]
                worst = sx[-1]
                cen = sx[:-1].mean(axis=0)
                new = cen + (cen - worst)
                if np.any(new < lo) or np.any(new > hi):
                    new = lo + rng.random(n) * (hi - lo)
                fn = f(new)
                used += 1
                if fn > sf[-1]:
                    new = cen + 0.5 * (worst - cen)
                    fn = f(new)
                    used += 1
                    if fn > sf[-1]:
                        new = lo + rng.random(n) * (hi - lo)
                        fn = f(new)
                        used += 1
                sx[-1], sf[-1] = new, fn
                cx[sel], cf[sel] = sx, sf
                o2 = np.argsort(cf)
                cx, cf = cx[o2], cf[o2]
            pop[idx], cost[idx] = cx, cf
        if used >= budget:
            break
    best = int(np.argmin(cost))
    return pop[best], float(cost[best])


@dataclass
class CalibResult:
    model: Model
    params: dict
    theta: np.ndarray
    objective: str
    value: float
    n_eval: int
    method: str
    behavioural: pd.DataFrame
    spread: dict

    def summary(self) -> str:
        p = ", ".join(f"{k}={v:.4g}" for k, v in self.params.items())
        return f"{self.model.name}: {self.objective}={self.value:.3f} after {self.n_eval} runs ({self.method}); {p}"


def calibrate(model: Model, forcing: dict, obs, mask: np.ndarray | None = None, objective: str = "kge", method: str = "de", budget: int = 1500, seed: int = 0, behavioural_frac: float = 0.05) -> CalibResult:
    """Fit the model parameters to `obs` on the steps where mask is True. Methods: de, sce (shuffled complex), lhs (random search + simplex)."""
    o_all = np.asarray(obs, float)
    use = np.isfinite(o_all) if mask is None else (np.isfinite(o_all) & np.asarray(mask, bool))
    if use.sum() < 20:
        raise ValueError("fewer than 20 usable observations in the calibration period")
    direction, fn = OBJECTIVES[objective]
    bounds = model.get_bounds(forcing)
    log = tuple(model.log) + (False,) * (len(bounds) - len(model.log))
    lo = np.array([np.log10(b[0]) if lg else b[0] for b, lg in zip(bounds, log)])
    hi = np.array([np.log10(b[1]) if lg else b[1] for b, lg in zip(bounds, log)])
    rng = np.random.default_rng(seed)
    trace = []

    def loss(z):
        th = _from_internal(z, log)
        try:
            sim = model.simulate(th, forcing)
            v = fn(o_all[use], sim[use])
        except Exception:  # noqa: BLE001
            v = np.nan
        if not np.isfinite(v):
            v = -1e3 if direction == "max" else 1e12
        L = -v if direction == "max" else v
        trace.append((th, v, L))
        return L

    if method == "de":
        pop = max(8, min(15, int(budget / (10 * len(bounds)))))
        optimize.differential_evolution(loss, list(zip(lo, hi)), seed=seed, maxiter=max(2, budget // (pop * len(bounds))), popsize=pop, tol=1e-6, polish=False)
    elif method == "sce":
        _sce_ua(loss, lo, hi, budget, rng)
    elif method == "lhs":
        n0 = int(budget * 0.7)
        sampler = stats.qmc.LatinHypercube(d=len(bounds), seed=seed)
        pts = lo + sampler.random(n0) * (hi - lo)
        ls = np.array([loss(p) for p in pts])
        z0 = pts[int(np.argmin(ls))]
        optimize.minimize(loss, z0, method="Nelder-Mead", bounds=list(zip(lo, hi)), options={"maxfev": budget - n0, "xatol": 1e-4, "fatol": 1e-6})
    else:
        raise ValueError("method must be de, sce or lhs")
    losses = np.array([t[2] for t in trace])
    best = int(np.argmin(losses))
    theta, val = trace[best][0], trace[best][1]
    k = max(5, int(behavioural_frac * len(trace)))
    top = np.argsort(losses)[:k]
    beh = pd.DataFrame([trace[i][0] for i in top], columns=model.params)
    beh[objective] = [trace[i][1] for i in top]
    spread = {}
    for j, p in enumerate(model.params):
        col = beh[p].to_numpy()
        rng_ = hi[j] - lo[j]
        zc = np.log10(col) if log[j] else col
        spread[p] = float((np.quantile(zc, 0.9) - np.quantile(zc, 0.1)) / rng_) if rng_ > 0 else 0.0
    return CalibResult(model, dict(zip(model.params, theta)), theta, objective, float(val), len(trace), method, beh, spread)


# ------------------------------------------------------------------------------------------------ the whole cycle


@dataclass
class CalValResult:
    scheme: str
    table: pd.DataFrame  # per split: calibration and validation metrics
    params: pd.DataFrame
    final: CalibResult | None
    warnings: list
    sim: pd.Series | None = None

    def summary(self) -> str:
        t = self.table
        lines = [f"Scheme: {self.scheme}; {t['split'].nunique()} split(s)."]
        for _, r in t.iterrows():
            lines.append(f"  {r['split']}: {r['metric']} calibration {r['calibration']:.3f}, validation {r['validation']:.3f}")
        for w in self.warnings:
            lines.append(f"  ! {w}")
        if self.final is not None:
            lines.append("Final fit on all data: " + self.final.summary())
        return "\n".join(lines)


def run_calval(model: Model, forcing: dict, obs: pd.Series, scheme: str = "split_sample", objective: str = "kge", method: str = "de", budget: int = 1200, warmup: int = 0, seed: int = 0,
               report_metrics=("nse", "kge", "pbias"), fit_final: bool = True, **split_kw) -> CalValResult:
    """Calibrate the model on each calibration period, validate on the matching validation period, report both and warn."""
    splits = make_splits(obs.index, scheme, obs=obs, warmup=warmup, **split_kw)
    rows, prow, warns = [], [], []
    o = obs.to_numpy(float)
    for sp in splits:
        res = calibrate(model, forcing, o, mask=sp.calib, objective=objective, method=method, budget=budget, seed=seed)
        sim = model.simulate(res.theta, forcing)
        for m in report_metrics:
            vc = _metric(m, o, sim, sp.calib)
            vv = _metric(m, o, sim, sp.valid)
            rows.append((sp.name, m, vc, vv))
        prow.append({"split": sp.name, **res.params, "equifinality": max(res.spread.values())})
        vk = _metric("kge", o, sim, sp.valid)
        ck = _metric("kge", o, sim, sp.calib)
        if np.isfinite(ck) and np.isfinite(vk) and ck - vk > 0.2:
            warns.append(f"{sp.name}: KGE falls from {ck:.2f} (calibration) to {vk:.2f} (validation): the parameters do not transfer to this period.")
        pb = _metric("pbias", o, sim, sp.valid)
        if np.isfinite(pb) and abs(pb) > 25:
            warns.append(f"{sp.name}: validation PBIAS is {pb:.0f} %.")
        if max(res.spread.values()) > 0.5:
            wide = [k for k, v in res.spread.items() if v > 0.5]
            warns.append(f"{sp.name}: many parameter sets fit almost equally well (wide ranges for {', '.join(wide)}); the single best set is not reliable.")
    table = pd.DataFrame(rows, columns=["split", "metric", "calibration", "validation"])
    final = calibrate(model, forcing, o, mask=_warm_mask(len(o), warmup), objective=objective, method=method, budget=budget, seed=seed) if fit_final else None
    sim_final = pd.Series(model.simulate(final.theta, forcing), index=obs.index) if final is not None else None
    return CalValResult(scheme, table, pd.DataFrame(prow), final, warns, sim_final)


def _warm_mask(n, warmup):
    m = np.ones(n, bool)
    m[: max(warmup, 0)] = False
    return m


def _metric(name: str, o: np.ndarray, s: np.ndarray, mask: np.ndarray) -> float:
    ok = mask & np.isfinite(o) & np.isfinite(s)
    if ok.sum() < 10:
        return np.nan
    oo, ss = o[ok], s[ok]
    if name == "kge":
        return M.kge_parts(oo, ss)[0]
    return {"nse": M.nse, "pbias": M.pbias, "rmse": M.rmse, "mae": M.mae, "log_nse": M.log_nse, "pearson": M._corr}[name](oo, ss)


# ------------------------------------------------------------------------------------------------ comparing corrections


CORRECTION_ORDER = ["none", "bias_scale", "bias_shift", "linear", "power", "quantile_map"]  # from the simplest to the most flexible


def compare_corrections(obs: pd.Series, sim: pd.Series, scheme: str = "blocked_kfold", metrics=("nse", "kge", "rmse"), names=("none", "bias_scale", "bias_shift", "linear", "power", "quantile_map"), tolerance: float = 0.0, **split_kw) -> pd.DataFrame:
    """Cross-validated skill of each correction of `sim` against `obs` (higher NSE and KGE, lower RMSE are better).

    The row flagged `recommended` is the simplest correction within one standard error of the best KGE (Breiman et al. 1984), so that a scale factor
    is not replaced by a quantile map for a gain that cross-validation cannot distinguish from noise. The folds of a long record are almost
    identical, which makes the standard error very small; `tolerance` is a margin in KGE units below which a difference is treated as
    negligible, and the band is the larger of the standard error and the tolerance."""
    splits = make_splits(obs.index, scheme, obs=obs, **split_kw)
    rows = []
    for name in names:
        per = {m: [] for m in metrics}
        for sp in splits:
            corr = fit_correction(name, obs, sim, mask=sp.calib)
            fixed = apply_correction(corr, sim)
            for m in metrics:
                per[m].append(_metric(m, obs.to_numpy(float), fixed.to_numpy(float), sp.valid))
        rows.append({"correction": name, **{m: float(np.nanmean(v)) for m, v in per.items()}, **{f"{m}_sd": float(np.nanstd(v)) for m, v in per.items()}})
    out = pd.DataFrame(rows)
    key = "kge" if "kge" in metrics else metrics[0]
    out = out.sort_values(key, ascending=False).reset_index(drop=True)
    # one-standard-error rule: of the corrections whose cross-validated score is within one standard error of the best, recommend the simplest
    out["recommended"] = out["correction"] == recommend_correction(out, key, len(splits), tolerance)
    return out


def recommend_correction(table: pd.DataFrame, key: str = "kge", n_folds: int = 1, tolerance: float = 0.0) -> str:
    """The simplest correction whose cross-validated score is within max(one standard error, tolerance) of the best row of `table`
    (which must be sorted from the best to the worst and carry the column `{key}_sd`)."""
    se = float(table.loc[0, f"{key}_sd"]) / np.sqrt(max(n_folds, 1))
    near = table[table[key] >= table.loc[0, key] - max(se, float(tolerance))]
    return sorted(near["correction"], key=lambda c: CORRECTION_ORDER.index(c) if c in CORRECTION_ORDER else 99)[0]


def best_lag(obs: pd.Series, sim: pd.Series, max_lag: int = 10) -> int:
    """Lag (in steps; positive = simulation later) with the highest correlation."""
    cc = cross_correlation(obs, sim, max_lag)
    return int(cc.loc[cc["r"].idxmax(), "lag_steps"]) if cc["r"].notna().any() else 0
