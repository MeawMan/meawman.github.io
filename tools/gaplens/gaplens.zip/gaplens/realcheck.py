"""Check the methods on real records, where no true value is hidden by a generator.

A real record has no truth for its gaps, but it has observed values. This module hides some of them, lets the tool work on what is left
(diagnose, suggest, hold-out test), and then scores every candidate method against the values that were hidden. The hidden values are
never seen by the diagnosis, the suggestion or the hold-out test, so the hold-out pick can be compared fairly with the best method in
hindsight:

    regret = RMSE of the method / RMSE of the best candidate - 1      (0 = the best candidate was chosen)

    from gaplens import realcheck
    row, cands = realcheck.run_record(df, target="Q", variable="streamflow", design="ladder", seed=1)

The numbers describe the records you supply and nothing else. A few records give a few numbers; do not read a ranking of methods
for other stations from them.
"""

from __future__ import annotations

import time
import warnings

import numpy as np
import pandas as pd

from . import service
from .compare import make_holdout, real_gap_lengths
from .methods import REGISTRY
from .probe import probe
from .suggest import suggest

DESIGNS = ("ladder", "match", "mnar_upper")
PRESETS = {"rainfall": "drought", "streamflow": "flood_frequency", "temperature": "climate_trend", "tide": "tidal", "sediment": "sediment_load"}
MIN_COVERAGE = 0.9  # a method counts as a candidate for "best in hindsight" only if it fills at least this share of the hidden values


def usable_methods(series: pd.Series, others, ctx, methods=None, timeout: float = 120.0, isolate: bool = True) -> list:
    """Methods that can run on this record. With `methods` named, only the applicability check is made; otherwise every registered
    method is run once on a small test, each in its own process, and the ones that fail or time out are dropped."""
    if methods:
        return [m for m in methods if m in REGISTRY and not REGISTRY[m].check(series, others, ctx)]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        pr = probe(series, others, ctx, timeout=timeout, isolate=isolate)
    return [m for m, st in zip(pr.method, pr.status) if st == "ok"]


def _errors(truth: pd.Series, est: pd.Series, mask: pd.Series) -> dict:
    ok = (mask & est.notna() & truth.notna()).to_numpy()
    n_hidden = int(mask.sum())
    if ok.sum() < 3:
        return dict(rmse=np.nan, mae=np.nan, bias=np.nan, coverage=ok.sum() / max(n_hidden, 1))
    e = est.to_numpy(float)[ok] - truth.to_numpy(float)[ok]
    return dict(rmse=float(np.sqrt(np.mean(e**2))), mae=float(np.mean(np.abs(e))), bias=float(np.mean(e)), coverage=float(ok.sum() / max(n_hidden, 1)))


def run_record(df: pd.DataFrame, target: str, variable: str = "auto", name: str | None = None, design: str = "ladder", seed: int = 1, frac: float = 0.10,
               reps: int = 3, methods=None, ok_methods=None, max_singles: int = 12, preset: str | None = None, ladder=None, min_obs: int = 200,
               timeout: float = 120.0, isolate: bool = True, **roles):
    """One record, one hiding design, one seed. `roles` are the keyword arguments of `service.build_task` (driver, surrogate, precip, pet, product, latitude ...).

    Returns (summary row as a dict, list of candidate rows). `ok_methods` skips the test run that finds the usable methods, so a loop over seeds
    and designs does it once per record."""
    t0 = time.time()
    series0 = df[target].astype(float)
    n_obs = int(series0.notna().sum())
    if n_obs < min_obs:
        raise ValueError(f"{target}: {n_obs} observed values; at least {min_obs} are needed to hide some and still have a record to work on")
    if design not in DESIGNS:
        raise ValueError(f"design must be one of {DESIGNS}")
    steps = ladder or service._default_ladder(series0)
    rng = np.random.default_rng(seed)
    hidden_arr, _ = make_holdout(series0, rng, steps, frac, design=design, real_lengths=real_gap_lengths(series0))
    hidden = pd.Series(hidden_arr, index=series0.index)
    if not hidden.any():
        raise ValueError(f"{target}: no block of the design fits between the observed values")

    df_e = df.copy()
    df_e[target] = series0.where(~hidden)  # everything below sees only this table
    series, others, ctx = service.build_task(df_e, target, variable, seed=seed, **roles)
    prof = service.run_profile(df_e, ctx, others)
    sg = service.run_suggest(prof, series, others, ctx)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        sg_lit = suggest(prof, series, others, ctx, target=ctx.target, prior=None)  # literature defaults only
    ok = list(ok_methods) if ok_methods is not None else usable_methods(series, others, ctx, methods, timeout, isolate)
    if not ok:
        raise ValueError(f"{target}: no method can run on this record")

    res = service.run_compare(series, others, ctx, methods=ok, n_rep=reps, seed=seed + 1000)
    preset = preset or PRESETS.get(ctx.variable, "balanced")
    rk = res.ranking(preset)
    pick = res.best(preset, n=1)
    pick = pick[0] if pick else None
    s1 = (sg.top(1) or [None])[0]
    l1 = (sg_lit.top(1) or [None])[0]
    names = list(dict.fromkeys(list(rk.index[:max_singles]) + sg.top(5) + sg_lit.top(5) + ["linear"]))
    names = [m for m in names if m in ok]

    cands = []
    for m in names:
        try:
            f = service.run_fill(series, others, ctx, [m], intervals=False)
            cands.append(dict(method=m, rank_in_holdout=float(rk.loc[m, "weighted_rank"]) if m in rk.index else np.nan, **_errors(series0, f["value"], hidden)))
        except Exception as e:  # noqa: BLE001 - one failing method must not stop the record
            cands.append(dict(method=m, rank_in_holdout=np.nan, rmse=np.nan, mae=np.nan, bias=np.nan, coverage=0.0, error=str(e)[:100]))
    c = pd.DataFrame(cands)
    valid = c[(c["coverage"] >= MIN_COVERAGE) & c["rmse"].notna()] if len(c) else c
    best = valid.loc[valid["rmse"].idxmin()] if len(valid) else None
    by = c.set_index("method") if len(c) else pd.DataFrame()

    def rmse_of(m):
        return float(by.loc[m, "rmse"]) if m in by.index and by.loc[m, "coverage"] >= MIN_COVERAGE else np.nan

    def regret(m):
        r = rmse_of(m)
        return float(r / best["rmse"] - 1) if best is not None and np.isfinite(r) and best["rmse"] > 0 else np.nan

    top3 = set(valid.nsmallest(3, "rmse")["method"]) if len(valid) else set()
    row = dict(record=name or target, target=target, variable=ctx.variable, design=design, seed=seed, preset=preset, n=len(series0), n_observed=n_obs,
               missing_pct_before=100 * float(series0.isna().mean()), hidden_n=int(hidden.sum()), missing_after=int(series.isna().sum()),
               gap_types="+".join(prof.codes), n_methods_ok=len(ok), n_candidates=len(names),
               pick=pick, suggest_top1=s1, literature_top1=l1, best_in_hindsight=None if best is None else best["method"],
               rmse_best=np.nan if best is None else float(best["rmse"]), rmse_pick=rmse_of(pick), rmse_suggest=rmse_of(s1), rmse_literature=rmse_of(l1), rmse_linear=rmse_of("linear"),
               regret_pick=regret(pick), regret_suggest=regret(s1), regret_literature=regret(l1), regret_linear=regret("linear"),
               pick_in_oracle_top3=bool(pick in top3), seconds=time.time() - t0)
    return row, [dict(record=name or target, design=design, seed=seed, **r) for r in cands]


REGRET_COLUMNS = ("regret_pick", "regret_suggest", "regret_literature", "regret_linear")


def summarise(summary: pd.DataFrame) -> pd.DataFrame:
    """Median regret over the seeds, per record and design, and the share of runs in which the pick was among the best three in hindsight."""
    if not len(summary):
        return pd.DataFrame()
    g = summary.groupby(["record", "design"])
    out = g[list(REGRET_COLUMNS)].median()
    out["runs"] = g.size()
    out["pick_in_oracle_top3"] = g["pick_in_oracle_top3"].mean()
    out["missing_pct_before"] = g["missing_pct_before"].first()
    return out.reset_index()
