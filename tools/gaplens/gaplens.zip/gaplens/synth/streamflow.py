"""Synthetic daily streamflow from rainfall with a simple conceptual model.

Each gauge is a lumped catchment: a soil store (saturation-excess runoff
generation) feeding a fast and a slow linear reservoir. Gauges share the rainfall
network (each uses its own random weighted mean of the stations) but have their
own area and slightly different parameters, so donor gauges are correlated but
not identical. Optionally the last gauge is a downstream mainstem gauge made of
the first gauge's flow routed with a lag plus its own lateral inflow.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .common import SyntheticSeries, rng_from, seasonal_cos


def bucket_model(precip, pet, smax=250.0, k_fast=0.30, k_slow=0.02, frac_fast=0.7, exponent=2.0):
    """Conceptual runoff model. Inputs and output in mm/day; returns flow in mm/day."""
    n = len(precip)
    soil = 0.5 * smax
    fast = 5.0
    slow = 20.0
    out = np.empty(n)
    for t in range(n):
        wetness = soil / smax
        gen = precip[t] * wetness**exponent
        soil = soil + precip[t] - gen - pet[t] * wetness
        if soil > smax:
            gen += soil - smax
            soil = smax
        if soil < 0.0:
            soil = 0.0
        fast += frac_fast * gen
        slow += (1.0 - frac_fast) * gen
        q_fast = k_fast * fast
        q_slow = k_slow * slow
        fast -= q_fast
        slow -= q_slow
        out[t] = q_fast + q_slow
    return out


def streamflow(
    rain: pd.DataFrame,
    n_gauges: int = 3,
    seed: int = 0,
    areas_km2=None,
    pet_mean_mm: float = 3.5,
    include_downstream: bool = True,
    lag_days: int = 1,
) -> SyntheticSeries:
    """Generate daily discharge (m3/s) for `n_gauges` gauges driven by `rain` (mm/day).

    With include_downstream=True the last column is Q_ds = Q_01 shifted by
    lag_days plus the lateral inflow of the extra catchment area (so the
    first and last gauges are an upstream and downstream pair on one river).
    """
    rng = rng_from(seed)
    index = rain.index
    n = len(index)
    if areas_km2 is None:
        areas_km2 = np.sort(np.exp(rng.uniform(np.log(300.0), np.log(4000.0), n_gauges)))
    areas = np.asarray(areas_km2, dtype=float)
    pet = pet_mean_mm * (1.0 + 0.4 * seasonal_cos(index, 110.0))
    spinup = 365
    rain_vals = rain.to_numpy(dtype=float)
    n_st = rain_vals.shape[1]

    flows = {}
    params = []
    for g in range(n_gauges):
        w = rng.dirichlet(np.full(n_st, 2.0))
        p_g = rain_vals @ w
        p_run = np.concatenate([p_g[:spinup], p_g])
        pet_run = np.concatenate([pet[:spinup], pet])
        jit = rng.uniform(0.8, 1.2, 3)
        q_mm = bucket_model(p_run, pet_run, smax=250.0 * jit[0], k_fast=0.30 * jit[1], k_slow=0.02 * jit[2])[spinup:]
        flows[f"Q{g + 1:02d}"] = q_mm * areas[g] / 86.4
        params.append(dict(gauge=f"Q{g + 1:02d}", area_km2=float(areas[g]), weights=w.round(3).tolist(), jitter=jit.round(3).tolist()))
    truth = pd.DataFrame(flows, index=index)

    meta = dict(generator="streamflow", seed=seed, n_gauges=n_gauges, pet_mean_mm=pet_mean_mm, gauges=params, units="m3/s")
    if include_downstream:
        a_lat = float(areas[0] * 0.8 + 200.0)
        w = rng.dirichlet(np.full(n_st, 2.0))
        p_g = rain_vals @ w
        q_lat = bucket_model(np.concatenate([p_g[:spinup], p_g]), np.concatenate([pet[:spinup], pet]))[spinup:] * a_lat / 86.4
        up = truth["Q01"].to_numpy()
        shifted = np.concatenate([np.full(lag_days, up[0]), up[: n - lag_days]]) if lag_days > 0 else up
        name = f"Q{n_gauges + 1:02d}"
        truth[name] = shifted + q_lat
        meta["downstream"] = dict(gauge=name, upstream="Q01", lag_days=lag_days, lateral_area_km2=a_lat)
    truth.index.name = "time"
    return SyntheticSeries("streamflow", "discharge", "m3/s", truth, meta, {})
