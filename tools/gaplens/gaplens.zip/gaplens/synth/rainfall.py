"""Synthetic daily rainfall at several stations.

Model: a latent Gaussian field with exponential spatial correlation and AR(1)
persistence in time. A day is wet where the latent value exceeds a seasonal
threshold, and the wet-day amount is a gamma quantile of the exceedance, so
amounts and occurrence are coupled and spatially coherent. Seasonality follows
a monsoon cycle (more and heavier rain around `peak_doy`).

Wet day = amount of at least 0.1 mm (amounts below that are set to zero).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.signal import lfilter
from scipy.stats import gamma, norm

from .common import (
    SyntheticSeries,
    make_index,
    random_coords,
    rng_from,
    seasonal_cos,
    spatial_cholesky,
    station_names,
)


def rainfall(
    n_stations: int = 6,
    years: int = 10,
    start: str = "2000-01-01",
    seed: int = 0,
    extent_km: float = 80.0,
    corr_range_km: float = 40.0,
    p_wet_mean: float = 0.35,
    p_wet_amp: float = 0.30,
    peak_doy: float = 200.0,
    amount_mean_mm: float = 11.0,
    amount_amp: float = 0.5,
    gamma_shape: float = 0.75,
    persistence: float = 0.35,
    orographic: float = 0.3,
) -> SyntheticSeries:
    """Generate multi-station daily rainfall (mm/day).

    p_wet(doy)   = clip(p_wet_mean + p_wet_amp cos(2 pi (doy - peak)/365.25), 0.02, 0.95)
    mean_wet(doy)= amount_mean_mm (1 + amount_amp cos(...)) x station factor
    The station factor rises along the x axis by `orographic` (relative) from west to east.
    """
    rng = rng_from(seed)
    index = make_index(start, years, "D")
    n = len(index)
    coords = random_coords(rng, n_stations, extent_km)
    chol = spatial_cholesky(coords, corr_range_km)

    # latent field: spatially correlated innovations, AR(1) in time, unit marginal variance
    burn = 60
    innov = rng.standard_normal((n + burn, n_stations)) @ chol.T
    z = lfilter([np.sqrt(1.0 - persistence**2)], [1.0, -persistence], innov, axis=0)[burn:]
    u = norm.cdf(z)

    season = seasonal_cos(index, peak_doy)[:, None]
    p_wet = np.clip(p_wet_mean + p_wet_amp * season, 0.02, 0.95)
    station_factor = 1.0 + orographic * (coords[:, 0] / extent_km - 0.5)
    scale_mean = amount_mean_mm * (1.0 + amount_amp * season) * station_factor[None, :]

    wet = u > (1.0 - p_wet)
    v = np.clip((u - (1.0 - p_wet)) / p_wet, 1e-6, 1.0 - 1e-6)
    amount = gamma.ppf(v, a=gamma_shape, scale=scale_mean / gamma_shape)
    amount = np.where(wet, amount, 0.0)
    amount = np.round(amount, 1)
    amount[amount < 0.1] = 0.0

    names = station_names("R", n_stations)
    truth = pd.DataFrame(amount, index=index, columns=names)
    truth.index.name = "time"
    coords_df = pd.DataFrame({"station": names, "x_km": coords[:, 0], "y_km": coords[:, 1], "amount_factor": station_factor})
    meta = dict(
        generator="rainfall",
        seed=seed,
        n_stations=n_stations,
        years=years,
        start=start,
        extent_km=extent_km,
        corr_range_km=corr_range_km,
        p_wet_mean=p_wet_mean,
        p_wet_amp=p_wet_amp,
        peak_doy=peak_doy,
        amount_mean_mm=amount_mean_mm,
        amount_amp=amount_amp,
        gamma_shape=gamma_shape,
        persistence=persistence,
        orographic=orographic,
        wet_day_threshold_mm=0.1,
        units="mm/day",
    )
    return SyntheticSeries("rainfall", "precipitation", "mm/day", truth, meta, {"stations": coords_df.set_index("station")})
