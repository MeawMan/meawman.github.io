"""A synthetic gridded or reanalysis product for one station: smoother than the gauge, biased, with false drizzle and missed storms."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .common import rng_from


def rain_product(truth: pd.DataFrame, target: str, seed: int = 0, smooth: float = 0.5, bias: float = 1.15, sigma: float = 0.5,
                 drizzle_prob: float = 0.2, miss_prob: float = 0.08) -> pd.Series:
    """Daily product at the location of `target`.

    smooth        share of the areal mean mixed into the local value (grid cells are larger than a gauge)
    bias          wet bias of the product
    sigma         log-sd of the multiplicative error
    drizzle_prob  chance that a dry gauge day gets a small false amount
    miss_prob     chance that a rain day above 5 mm is mostly missed
    """
    rng = rng_from(seed)
    local = truth[target].to_numpy(float)
    areal = truth.mean(axis=1).to_numpy(float)
    base = (1.0 - smooth) * local + smooth * areal
    prod = base * bias * np.exp(rng.normal(-0.5 * sigma**2, sigma, len(base)))
    dry = prod < 0.5
    add = dry & (rng.random(len(base)) < drizzle_prob)
    prod[add] = rng.gamma(1.2, 0.8, int(add.sum()))
    miss = (local > 5.0) & (rng.random(len(base)) < miss_prob)
    prod[miss] *= 0.2
    return pd.Series(np.maximum(prod, 0.0), index=truth.index, name=f"PROD_{target}")


def temperature_product(truth: pd.DataFrame, target: str, seed: int = 0, bias_c: float = -0.8, sd_c: float = 1.0) -> pd.Series:
    """Daily reanalysis-like temperature at the location of `target`: biased and noisy."""
    rng = rng_from(seed)
    areal = truth.mean(axis=1).to_numpy(float)
    local = truth[target].to_numpy(float)
    prod = 0.8 * local + 0.2 * areal + bias_c + rng.normal(0, sd_c, len(local))
    return pd.Series(prod, index=truth.index, name=f"PROD_{target}")
