"""One consistent synthetic basin: rainfall -> flow -> stage, sediment, groundwater, tide, salinity.

The variables share one weather history, so cross-variable methods (rainfall as a
predictor of flow, discharge as a predictor of sediment or salinity, river
discharge shaping the tide) can be tested on data whose links are known.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .common import SyntheticSeries
from .groundwater import groundwater
from .rainfall import rainfall
from .rating import rating_series
from .salinity import salinity
from .sediment import sediment
from .streamflow import streamflow
from .temperature import temperature
from .tide import tide


def build_basin(
    seed: int = 1,
    years: int = 10,
    start: str = "2000-01-01",
    n_rain: int = 6,
    n_temp: int = 5,
    n_gauges: int = 3,
    tide_years: float = 2.0,
    hysteresis_beta: float = 0.15,
) -> dict[str, SyntheticSeries]:
    """Generate every variable for one basin. Returns a dict name -> SyntheticSeries."""
    rain = rainfall(n_stations=n_rain, years=years, start=start, seed=seed)
    temp = temperature(n_stations=n_temp, years=years, start=start, seed=seed + 1)
    flow = streamflow(rain.truth, n_gauges=n_gauges, seed=seed + 2)
    main_gauge = flow.truth.columns[-1]
    rate = rating_series(flow.truth[main_gauge], seed=seed + 3, vegetation_amp_m=0.05, hysteresis_beta=hysteresis_beta)
    sed = sediment(rate.truth["discharge_m3s"], seed=seed + 4)
    areal = rain.truth.mean(axis=1)
    gw = groundwater(areal, seed=seed + 5)
    # tide over the last `tide_years` years of the river record so the river effect lines up
    q_tail = flow.truth[main_gauge]
    tide_start = (q_tail.index[-1] - pd.DateOffset(years=int(tide_years))).normalize() + pd.Timedelta(days=1)
    q_for_tide = q_tail.loc[tide_start:]
    td = tide(years=tide_years, start=str(tide_start.date()), seed=seed + 6, river_discharge=q_for_tide)
    tidal_range = td.truth["level_m"].resample("D").agg(lambda x: x.max() - x.min())
    sal = salinity(q_for_tide, tidal_range, seed=seed + 7)
    return {
        "rainfall": rain,
        "temperature": temp,
        "streamflow": flow,
        "rating": rate,
        "sediment": sed,
        "groundwater": gw,
        "tide": td,
        "salinity": sal,
    }


def write_basin(folder, **kwargs) -> Path:
    """Build a basin and write each variable to its own sub-folder."""
    folder = Path(folder)
    parts = build_basin(**kwargs)
    for name, ser in parts.items():
        ser.to_folder(folder / name)
    return folder
