"""Synthetic estuarine salinity (psu) driven by river discharge and tidal range.

S = S_sea / (1 + (Q/Q50)^1.5) x (1 + tide_gain z) x lognormal noise
where z is the standardised daily tidal range. Dry season (low Q) gives high
salinity intrusion; monsoon flow freshens the estuary.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .common import SyntheticSeries, ar1, rng_from


def salinity(
    discharge: pd.Series,
    tidal_range: pd.Series | None = None,
    seed: int = 0,
    s_sea_psu: float = 30.0,
    tide_gain: float = 0.12,
    noise_sd_ln: float = 0.10,
    noise_phi: float = 0.8,
) -> SyntheticSeries:
    rng = rng_from(seed)
    index = discharge.index
    q = discharge.to_numpy(dtype=float)
    q50 = float(np.median(q))
    base = s_sea_psu / (1.0 + (q / q50) ** 1.5)
    if tidal_range is not None:
        tr = tidal_range.reindex(index).interpolate().bfill().ffill().to_numpy(dtype=float)
        z = (tr - tr.mean()) / max(tr.std(), 1e-9)
        base = base * (1.0 + tide_gain * np.clip(z, -2.0, 2.0))
    s = np.clip(base * np.exp(ar1(rng, len(q), noise_phi, noise_sd_ln)), 0.05, 35.0)
    truth = pd.DataFrame({"salinity_psu": s}, index=index)
    truth.index.name = "time"
    meta = dict(generator="salinity", seed=seed, s_sea_psu=s_sea_psu, tide_gain=tide_gain, noise_sd_ln=noise_sd_ln, units="psu")
    return SyntheticSeries("salinity", "salinity", "psu", truth, meta, {})
