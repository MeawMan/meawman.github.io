"""Synthetic hydroclimate data with known truth."""

from .basin import build_basin, write_basin
from .common import SyntheticSeries
from .groundwater import groundwater
from .product import rain_product, temperature_product
from .rainfall import rainfall
from .rating import rating_forward, rating_inverse, rating_series
from .salinity import salinity
from .sediment import sediment
from .streamflow import bucket_model, streamflow
from .temperature import temperature
from .tide import DEFAULT_CONSTITUENTS, harmonic_design, tide

__all__ = [
    "SyntheticSeries",
    "build_basin",
    "write_basin",
    "rainfall",
    "temperature",
    "streamflow",
    "bucket_model",
    "rating_series",
    "rating_forward",
    "rating_inverse",
    "sediment",
    "groundwater",
    "tide",
    "harmonic_design",
    "DEFAULT_CONSTITUENTS",
    "salinity",
    "rain_product",
    "temperature_product",
]
