"""Synthetic air temperature (daily or hourly) at several stations.

Daily mean = annual cycle + lapse-rate offset by elevation + slow trend +
spatially shared AR(1) anomaly + a small local anomaly + station bias, plus
shared heat-wave episodes. Daily maximum and minimum are mean +/- half the
diurnal range (kept at 1 degree C or more, so Tmax >= Tmin always holds).
Hourly data add a diurnal cosine peaking at 15:00 local time.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (
    SyntheticSeries,
    ar1,
    make_index,
    rng_from,
    seasonal_cos,
    station_names,
)


def temperature(
    n_stations: int = 5,
    years: int = 10,
    start: str = "2000-01-01",
    seed: int = 0,
    freq: str = "D",
    t_mean_c: float = 26.0,
    annual_amp_c: float = 4.5,
    peak_doy: float = 140.0,
    dtr_mean_c: float = 8.0,
    dtr_amp_c: float = 2.0,
    dtr_peak_doy: float = 60.0,
    lapse_c_per_km: float = 6.5,
    elevations_m=None,
    trend_c_per_year: float = 0.03,
    anomaly_sd_c: float = 1.8,
    anomaly_phi: float = 0.7,
    shared_fraction: float = 0.8,
    heatwaves_per_year: float = 1.5,
) -> SyntheticSeries:
    """Generate multi-station temperature (degrees C).

    truth holds the mean temperature (daily mean for freq "D", the instantaneous
    hourly value for freq "h"); extras["tmax"] and extras["tmin"] hold the daily
    maximum and minimum. The shared fraction is the share of anomaly variance
    common to all stations.
    """
    if freq not in ("D", "h"):
        raise ValueError("freq must be 'D' or 'h'")
    rng = rng_from(seed)
    day_index = make_index(start, years, "D")
    nd = len(day_index)
    if elevations_m is None:
        elevations_m = rng.uniform(0.0, 1500.0, n_stations)
    elevations_m = np.asarray(elevations_m, dtype=float)
    bias = rng.normal(0.0, 0.3, n_stations)

    shared = ar1(rng, nd, anomaly_phi, anomaly_sd_c * np.sqrt(shared_fraction))[:, None]
    local = ar1(rng, (nd, n_stations), anomaly_phi, anomaly_sd_c * np.sqrt(1.0 - shared_fraction))
    heat = np.zeros(nd)
    n_events = rng.poisson(heatwaves_per_year * years)
    events = []
    for _ in range(n_events):
        s = int(rng.integers(0, nd - 10))
        length = int(rng.integers(4, 10))
        amp = rng.uniform(3.0, 6.0)
        heat[s : s + length] += amp
        events.append((day_index[s], length, amp))
    years_elapsed = np.arange(nd) / 365.25
    season = seasonal_cos(day_index, peak_doy)[:, None]
    mean_d = (
        t_mean_c
        + annual_amp_c * season
        - lapse_c_per_km * elevations_m[None, :] / 1000.0
        + trend_c_per_year * years_elapsed[:, None]
        + shared
        + local
        + heat[:, None]
        + bias[None, :]
    )
    dtr = np.maximum(1.0, dtr_mean_c + dtr_amp_c * seasonal_cos(day_index, dtr_peak_doy)[:, None] + 0.6 * rng.standard_normal((nd, n_stations)))
    tmax = mean_d + dtr / 2.0
    tmin = mean_d - dtr / 2.0

    names = station_names("T", n_stations)
    tmax_df = pd.DataFrame(tmax, index=day_index, columns=names)
    tmin_df = pd.DataFrame(tmin, index=day_index, columns=names)
    mean_df = pd.DataFrame(mean_d, index=day_index, columns=names)
    for df in (tmax_df, tmin_df, mean_df):
        df.index.name = "time"

    if freq == "h":
        hour_index = make_index(start, years, "h")
        day_pos = np.searchsorted(day_index.values, hour_index.normalize().values)
        hod = hour_index.hour.to_numpy(dtype=float)
        diurnal = 0.5 * dtr[day_pos] * np.cos(2.0 * np.pi * (hod[:, None] - 15.0) / 24.0)
        truth = pd.DataFrame(mean_d[day_pos] + diurnal, index=hour_index, columns=names)
        truth.index.name = "time"
    else:
        truth = mean_df

    stations = pd.DataFrame({"station": names, "elevation_m": elevations_m, "bias_c": bias}).set_index("station")
    meta = dict(
        generator="temperature",
        seed=seed,
        n_stations=n_stations,
        years=years,
        start=start,
        freq=freq,
        t_mean_c=t_mean_c,
        annual_amp_c=annual_amp_c,
        peak_doy=peak_doy,
        lapse_c_per_km=lapse_c_per_km,
        trend_c_per_year=trend_c_per_year,
        anomaly_sd_c=anomaly_sd_c,
        anomaly_phi=anomaly_phi,
        heatwaves=[dict(start=str(a), length_days=b, amplitude_c=c) for a, b, c in events],
        units="degC",
    )
    return SyntheticSeries(
        "temperature",
        "air_temperature",
        "degC",
        truth,
        meta,
        {"stations": stations, "tmax": tmax_df, "tmin": tmin_df, "tmean_daily": mean_df},
    )
