"""Synthetic suspended-sediment concentration, turbidity and load.

C = a (Q/Q50)^b x supply(t) x hysteresis(t) x lognormal noise

supply(t) is a seasonal cycle (first-flush peak early in the wet season) and
hysteresis(t) raises concentration on the rising limb (clockwise loop) when
`hysteresis` > 0, lowers it when negative. Noise is AR(1) in log space.
Turbidity follows C = k Tu^m with small independent noise, so turbidity is a
good but imperfect surrogate. Load (t/day) = C (mg/L) x Q (m3/s) x 0.0864.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .common import SyntheticSeries, ar1, rng_from, seasonal_cos


def sediment(
    discharge: pd.Series,
    seed: int = 0,
    c50_mgl: float = 80.0,
    b: float = 1.4,
    sigma_ln: float = 0.35,
    noise_phi: float = 0.5,
    supply_amp: float = 0.4,
    supply_peak_doy: float = 170.0,
    hysteresis: float = 0.5,
    turb_k: float = 1.8,
    turb_m: float = 0.95,
    turb_sigma_ln: float = 0.15,
) -> SyntheticSeries:
    rng = rng_from(seed)
    index = discharge.index
    q = discharge.to_numpy(dtype=float)
    q50 = float(np.median(q))
    dq = np.gradient(q)
    hyst = 1.0 + hysteresis * np.tanh(dq / (0.25 * q50))
    supply = 1.0 + supply_amp * seasonal_cos(index, supply_peak_doy)
    eps = ar1(rng, len(q), noise_phi, sigma_ln)
    conc = c50_mgl * (q / q50) ** b * supply * hyst * np.exp(eps - 0.5 * sigma_ln**2)
    conc = np.clip(conc, 0.5, 8000.0)
    turb = (conc / turb_k) ** (1.0 / turb_m) * np.exp(rng.normal(0.0, turb_sigma_ln, len(q)))
    load = conc * q * 0.0864
    truth = pd.DataFrame(
        {"concentration_mgl": conc, "turbidity_ntu": turb, "load_t_day": load, "discharge_m3s": q},
        index=index,
    )
    truth.index.name = "time"
    meta = dict(
        generator="sediment",
        seed=seed,
        c50_mgl=c50_mgl,
        b=b,
        sigma_ln=sigma_ln,
        noise_phi=noise_phi,
        supply_amp=supply_amp,
        hysteresis=hysteresis,
        turb_k=turb_k,
        turb_m=turb_m,
        units="mg/L, NTU, t/day, m3/s",
    )
    return SyntheticSeries("sediment", "suspended_sediment", "mg/L", truth, meta, {})
