"""Synthetic tidal water level with known constituents, surge and river effects.

level = tide + surge + meteorological noise + river effect

tide:  sum over constituents of f_k(t) A_k damp_k(t) cos(w_k t - phi_k + u_k(t)), where
       t is in hours since the first time step, w_k = speed_k (deg/hour) in
       radians, f_k(t) and u_k(t) are simplified nodal factor and phase
       correction (18.61 year cycle, real node longitude) for M2-type, K1, O1-type, K2 and M4 constituents, and damp_k(t) = 1 - river_damping * Qnorm(t) for the
       semidiurnal and shallow-water constituents when a river discharge series
       is supplied.
surge: asymmetric pulses (fast rise, slow decay) at random times, more often
       in the cyclone seasons (April-May, October-November).
river: river_gain_m * Qnorm(t)**1.5, a rise of the mean level with discharge.

Constituent speeds are the standard values in degrees per hour. Default
amplitudes and phases are plausible for a macro-tidal estuary, not a real site.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .common import SyntheticSeries, ar1, make_index, rng_from

# name: (speed deg/hour, amplitude m, phase deg)
DEFAULT_CONSTITUENTS = {
    "M2": (28.9841042, 1.20, 40.0),
    "S2": (30.0000000, 0.50, 75.0),
    "N2": (28.4397295, 0.25, 20.0),
    "K2": (30.0821373, 0.15, 70.0),
    "K1": (15.0410686, 0.35, 190.0),
    "O1": (13.9430356, 0.20, 160.0),
    "P1": (14.9589314, 0.12, 185.0),
    "Q1": (13.3986609, 0.04, 150.0),
    "M4": (57.9682084, 0.08, 120.0),
    "MS4": (58.9841042, 0.05, 150.0),
    "MSf": (1.0158958, 0.03, 30.0),
    "Mm": (0.5443747, 0.02, 80.0),
    "Sa": (0.0410686, 0.15, 220.0),
    "Ssa": (0.0821373, 0.05, 100.0),
}
DAMPED = ("M2", "S2", "N2", "K2", "M4", "MS4")


def harmonic_design(t_hours: np.ndarray, speeds_deg_per_hour) -> np.ndarray:
    """Design matrix [cos(w t), sin(w t)] per constituent for least-squares fitting."""
    w = np.radians(np.asarray(speeds_deg_per_hour, dtype=float))
    arg = np.outer(t_hours, w)
    return np.hstack([np.cos(arg), np.sin(arg)])


def node_longitude(index: pd.DatetimeIndex) -> np.ndarray:
    """Longitude of the moon's ascending node N in radians (mean value, 18.61-year cycle)."""
    d = ((index - pd.Timestamp("2000-01-01 12:00")) / pd.Timedelta(days=1)).to_numpy()
    return np.radians((125.04452 - 0.05295377 * d) % 360.0)


def _nodal(name: str, node_phase: np.ndarray):
    """Simplified nodal amplitude factor f and phase correction u (radians) for the main constituents."""
    c, sn = np.cos(node_phase), np.sin(node_phase)
    if name in ("M2", "N2", "MU2", "NU2", "2N2", "L2"):
        return 1.0004 - 0.0373 * c, np.radians(-2.14) * sn
    if name == "K1":
        return 1.006 + 0.115 * c, np.radians(-8.86) * sn
    if name in ("O1", "Q1", "J1"):
        return 1.009 + 0.187 * c, np.radians(10.80) * sn
    if name == "K2":
        return 1.024 + 0.286 * c, np.radians(-17.74) * sn
    if name == "M4":
        f, u = _nodal("M2", node_phase)
        return f**2, 2 * u
    if name == "MS4":
        return _nodal("M2", node_phase)
    return np.ones_like(node_phase), np.zeros_like(node_phase)


def tide(
    years: float = 2,
    start: str = "2000-01-01",
    seed: int = 0,
    freq: str = "h",
    constituents: dict | None = None,
    z0_m: float = 0.0,
    nodal: bool = True,
    surge_per_year: float = 3.0,
    surge_median_m: float = 0.5,
    met_sd_m: float = 0.07,
    met_phi: float = 0.985,
    river_discharge: pd.Series | None = None,
    river_gain_m: float = 0.6,
    river_damping: float = 0.25,
) -> SyntheticSeries:
    """Generate hourly (freq "h") tidal water level in metres.

    truth columns: level_m, tide_m, surge_m, met_m, river_m, residual_m
    (residual = level - tide = surge + met + river). extras: constituents
    (true speed, amplitude, phase) and surge events (start, peak).
    """
    rng = rng_from(seed)
    index = make_index(start, int(np.ceil(years)), freq)
    if years != int(years):
        index = index[: int(round(years * 365.25 * 24))]
    n = len(index)
    t_hours = (index - index[0]) / pd.Timedelta(1, "h")
    t_hours = np.asarray(t_hours, dtype=float)
    cons = dict(DEFAULT_CONSTITUENTS if constituents is None else constituents)

    # river discharge to hourly, normalised to 0..1
    if river_discharge is not None:
        q_h = river_discharge.reindex(index.union(river_discharge.index)).interpolate("time").reindex(index).ffill().bfill()
        qn = (q_h.to_numpy() / np.max(river_discharge.to_numpy())).clip(0.0, 1.0)
    else:
        qn = np.zeros(n)

    node_phase = node_longitude(index)
    tide_h = np.zeros(n)
    for name, (speed, amp, phase) in cons.items():
        f, u = _nodal(name, node_phase) if nodal else (np.ones(n), np.zeros(n))
        damp = (1.0 - river_damping * qn) if name in DAMPED else 1.0
        tide_h += f * amp * damp * np.cos(np.radians(speed) * t_hours - np.radians(phase) + u)

    # surge events
    surge = np.zeros(n)
    events = []
    n_target = rng.poisson(surge_per_year * n / (365.25 * 24))
    month_w = {4: 3.0, 5: 3.0, 10: 3.0, 11: 3.0}
    tries = 0
    while len(events) < n_target and tries < 100000:
        tries += 1
        p = int(rng.integers(0, n - 1))
        if rng.uniform() > month_w.get(index[p].month, 1.0) / 3.0:
            continue
        amp = float(np.clip(surge_median_m * np.exp(rng.normal(0.0, 0.7)), 0.2, 3.0))
        tau_r, tau_d = 10.0, 30.0
        k = np.arange(0, min(400, n - p), dtype=float)
        shape = np.exp(-k / tau_d) - np.exp(-k / tau_r)
        shape = shape / shape.max()
        surge[p : p + len(k)] += amp * shape
        events.append({"start": index[p], "peak_m": amp})
    met = ar1(rng, n, met_phi, met_sd_m)
    river = river_gain_m * qn**1.5
    level = z0_m + tide_h + surge + met + river
    truth = pd.DataFrame(
        {
            "level_m": level,
            "tide_m": z0_m + tide_h,
            "surge_m": surge,
            "met_m": met,
            "river_m": river,
            "residual_m": level - (z0_m + tide_h),
        },
        index=index,
    )
    truth.index.name = "time"
    cons_df = pd.DataFrame(
        [{"constituent": k, "speed_deg_h": v[0], "amplitude_m": v[1], "phase_deg": v[2]} for k, v in cons.items()]
    ).set_index("constituent")
    meta = dict(
        generator="tide",
        seed=seed,
        years=years,
        freq=freq,
        z0_m=z0_m,
        nodal=nodal,
        surge_per_year=surge_per_year,
        surge_median_m=surge_median_m,
        met_sd_m=met_sd_m,
        river_gain_m=river_gain_m,
        river_damping=river_damping,
        with_river=river_discharge is not None,
        n_surge_events=len(events),
        units="m",
    )
    return SyntheticSeries(
        "tide", "tidal_water_level", "m", truth, meta, {"constituents": cons_df, "surge_events": pd.DataFrame(sorted(events, key=lambda e: e["start"]), columns=["start", "peak_m"])}
    )
