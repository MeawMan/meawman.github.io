"""Shared helpers for the synthetic data generators.

Every generator returns a SyntheticSeries: a `truth` table (no gaps, known
values) plus metadata and extra tables (station coordinates, gaugings, ...).
All generators take a `seed` and use numpy's Generator, so a dataset is fully
reproducible from its configuration.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.signal import lfilter

DAYS_PER_YEAR = 365.25


@dataclass
class SyntheticSeries:
    """A synthetic variable with known truth.

    name:      short identifier, e.g. "rainfall"
    variable:  physical variable, e.g. "precipitation"
    units:     units of the truth columns (one string; details in meta)
    truth:     DataFrame indexed by time, one column per station or quantity
    meta:      JSON-serialisable parameters used to generate the data
    extras:    other DataFrames (coordinates, gaugings, constituents, events)
    """

    name: str
    variable: str
    units: str
    truth: pd.DataFrame
    meta: dict = field(default_factory=dict)
    extras: dict = field(default_factory=dict)

    def to_folder(self, folder) -> Path:
        """Write truth.csv, one csv per extra table and meta.json."""
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        self.truth.to_csv(folder / "truth.csv", index_label="time")
        for key, table in self.extras.items():
            if isinstance(table, pd.DataFrame):
                table.to_csv(folder / f"{key}.csv", index=table.index.name is not None)
        payload = {"name": self.name, "variable": self.variable, "units": self.units, "meta": self.meta}
        (folder / "meta.json").write_text(json.dumps(payload, indent=2, default=_json_default), encoding="utf-8")
        return folder


def _json_default(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    if isinstance(obj, pd.DataFrame):
        return obj.to_dict(orient="list")
    return str(obj)


def make_index(start="2000-01-01", years=10, freq="D") -> pd.DatetimeIndex:
    """Regular DatetimeIndex covering `years` calendar years from `start`."""
    start = pd.Timestamp(start)
    end = start + pd.DateOffset(years=int(years))
    return pd.date_range(start, end, freq=freq, inclusive="left")


def rng_from(seed) -> np.random.Generator:
    return np.random.default_rng(seed)


def doy_fraction(index: pd.DatetimeIndex) -> np.ndarray:
    """Day of year as a float (1.0 = 1 January 00:00)."""
    return index.dayofyear.to_numpy(dtype=float) + index.hour.to_numpy() / 24.0 + index.minute.to_numpy() / 1440.0


def seasonal_cos(index: pd.DatetimeIndex, peak_doy: float) -> np.ndarray:
    """cos(2 pi (doy - peak)/365.25): +1 at the peak day, -1 half a year later."""
    return np.cos(2.0 * np.pi * (doy_fraction(index) - peak_doy) / DAYS_PER_YEAR)


def ar1(rng, shape, phi: float, sigma: float = 1.0) -> np.ndarray:
    """Stationary AR(1) noise with marginal standard deviation `sigma`.

    `shape` is n or (n, k). A burn-in removes the start-up transient.
    """
    shape = (shape,) if np.isscalar(shape) else tuple(shape)
    n = shape[0]
    burn = int(min(5000, 8 / max(1.0 - phi, 1e-3)))
    full = (n + burn,) + shape[1:]
    eps = rng.standard_normal(full) * sigma * np.sqrt(1.0 - phi**2)
    out = lfilter([1.0], [1.0, -phi], eps, axis=0)
    return out[burn:]


def random_coords(rng, n: int, extent_km: float) -> np.ndarray:
    """n points uniformly placed in a square of side `extent_km`."""
    return rng.uniform(0.0, extent_km, size=(n, 2))


def spatial_cholesky(coords_km: np.ndarray, range_km: float) -> np.ndarray:
    """Lower Cholesky factor of an exponential spatial correlation matrix."""
    d = np.sqrt(((coords_km[:, None, :] - coords_km[None, :, :]) ** 2).sum(-1))
    corr = np.exp(-d / range_km) + 1e-9 * np.eye(len(coords_km))
    return np.linalg.cholesky(corr)


def station_names(prefix: str, n: int) -> list[str]:
    return [f"{prefix}{i + 1:02d}" for i in range(n)]
