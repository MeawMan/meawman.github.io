"""Synthetic groundwater head: delayed, smoothed response to recharge.

Recharge = max(precip - recharge_threshold_mm, 0). The head anomaly is a
first-order (exponential) response to recharge with time constant `tau_days`,
scaled to a requested seasonal range; a slow trend, a seasonal pumping drawdown
(dry-season months) and optional step changes (well deepened, pumping started)
are added, plus small logger noise.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.signal import lfilter

from .common import SyntheticSeries, ar1, rng_from


def groundwater(
    precip: pd.Series,
    seed: int = 0,
    baseline_m: float = 5.0,
    seasonal_range_m: float = 1.8,
    tau_days: float = 60.0,
    recharge_threshold_mm: float = 6.0,
    trend_m_per_year: float = -0.05,
    pumping_drawdown_m: float = 0.4,
    n_steps: int = 1,
    step_sd_m: float = 0.25,
    noise_sd_m: float = 0.01,
) -> SyntheticSeries:
    rng = rng_from(seed)
    index = precip.index
    n = len(index)
    r = np.maximum(precip.to_numpy(dtype=float) - recharge_threshold_mm, 0.0)
    alpha = np.exp(-1.0 / tau_days)
    x = lfilter([1.0 - alpha], [1.0, -alpha], r)
    spread = np.quantile(x, 0.95) - np.quantile(x, 0.05)
    response = (x - x.mean()) * (seasonal_range_m / max(spread, 1e-9))
    years_elapsed = np.arange(n) / 365.25
    dry = np.isin(index.month, [1, 2, 3, 4]).astype(float)
    pumping = -pumping_drawdown_m * lfilter([0.02], [1.0, -0.98], dry)
    steps = np.zeros(n)
    step_rows = []
    for _ in range(n_steps):
        p = int(rng.integers(int(0.2 * n), int(0.8 * n)))
        d = float(rng.normal(0.0, step_sd_m))
        steps[p:] += d
        step_rows.append({"date": index[p], "delta_m": d})
    head = baseline_m + response + trend_m_per_year * years_elapsed + pumping + steps + ar1(rng, n, 0.5, noise_sd_m)
    truth = pd.DataFrame({"head_m": head, "response_m": response, "pumping_m": pumping, "steps_m": steps}, index=index)
    truth.index.name = "time"
    meta = dict(
        generator="groundwater",
        seed=seed,
        baseline_m=baseline_m,
        seasonal_range_m=seasonal_range_m,
        tau_days=tau_days,
        recharge_threshold_mm=recharge_threshold_mm,
        trend_m_per_year=trend_m_per_year,
        pumping_drawdown_m=pumping_drawdown_m,
        units="m",
    )
    return SyntheticSeries("groundwater", "groundwater_head", "m", truth, meta, {"steps": pd.DataFrame(step_rows, columns=["date", "delta_m"])})
