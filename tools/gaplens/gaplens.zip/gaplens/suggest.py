"""Method suggestion (catalog section 2): a ranked shortlist with reasons and warnings, before any masked test is run.

    sg = suggest(profile, series, others, ctx)
    sg.table          rank, method, family, score, reasons, warnings
    sg.global_warnings
    sg.not_available  methods that cannot run and why
    print(sg.summary())

The score is a transparent sum of terms: the applicability matrix of the catalog (design defaults from the literature),
a match between the method's declared gap types and the gap types found, run-length fit, availability of donors inside the gaps,
and a few rules for special cases (network outages, extreme-linked gaps, thin overlap, tides, sparse samples).
The compare module replaces these defaults with results on the user's own data.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from .methods import REGISTRY, Ctx
from .methods.base import usable_donors

GOOD, FAIR, LIMITED, AVOID, NA = 3.0, 2.0, 1.0, 0.0, None

VARIABLE_COLUMN = {"rainfall": 0, "temperature": 1, "streamflow": 2, "stage": 3, "tide": 4, "groundwater": 5, "sediment": 6}
# rows: matrix family; columns: rainfall, temperature, streamflow, river stage, tide, groundwater, sediment  (catalog table 2.3)
MATRIX = {
    "interp": [AVOID, GOOD, FAIR, FAIR, AVOID, GOOD, AVOID],
    "clim": [AVOID, FAIR, LIMITED, LIMITED, GOOD, FAIR, AVOID],
    "tsmodel": [AVOID, GOOD, GOOD, GOOD, GOOD, GOOD, LIMITED],
    "neighbor": [GOOD, GOOD, GOOD, FAIR, FAIR, LIMITED, LIMITED],
    "multivar": [FAIR, GOOD, FAIR, FAIR, LIMITED, LIMITED, LIMITED],
    "hydrol": [NA, NA, GOOD, FAIR, NA, NA, GOOD],
    "process": [NA, NA, NA, NA, GOOD, GOOD, NA],
    "reanalysis": [GOOD, GOOD, FAIR, NA, NA, LIMITED, NA],
    "ml": [FAIR, GOOD, GOOD, GOOD, FAIR, FAIR, GOOD],
}
FAMILY_LABEL = {"interp": "interpolation", "clim": "climatology or harmonic regression", "tsmodel": "time-series model", "neighbor": "neighbour-station method",
                "multivar": "multivariate imputation", "hydrol": "hydrological relation", "process": "process model", "reanalysis": "reanalysis or satellite product", "ml": "machine learning"}
LEVEL_WORD = {3.0: "good", 2.0: "fair", 1.0: "limited", 0.0: "poor"}

METHOD_FAMILY = {}
for _m in ("locf", "linear", "pchip", "akima", "spline", "moving_mean", "moving_median"):
    METHOD_FAMILY[_m] = "interp"
for _m in ("climatology_mean", "climatology_median", "harmonic_regression", "stl_interp", "rain_weather_generator", "flow_seasonal_percentile", "gw_seasonal_ar"):
    METHOD_FAMILY[_m] = "clim"
for _m in ("arima_kalman", "state_space_uc", "ssa", "gp_local", "dynreg_arma"):
    METHOD_FAMILY[_m] = "tsmodel"
for _m in ("nearest_neighbor", "idw", "normal_ratio", "linear_regression", "linear_regression_resid", "kriging", "lagged_regression", "analog_knn", "rain_two_step", "rain_simolo",
           "temp_neighbor_elevation", "temp_diurnal_anomaly", "wl_slope_interpolation"):
    METHOD_FAMILY[_m] = "neighbor"
for _m in ("em_mvn", "mice", "pca_iterative", "matrix_completion"):
    METHOD_FAMILY[_m] = "multivar"
for _m in ("random_forest", "extra_trees", "xgboost", "lightgbm", "svr", "mlp", "hist_gradient_boosting", "sed_gbm"):
    METHOD_FAMILY[_m] = "ml"
for _m in ("rain_quantile_mapping", "rain_local_scaling", "rain_regression_merge"):
    METHOD_FAMILY[_m] = "reanalysis"
for _m in ("gw_exp_response", "gw_distributed_lag", "gw_pastas"):
    METHOD_FAMILY[_m] = "process"
for _id, _m in REGISTRY.items():
    if _id in METHOD_FAMILY:
        continue
    if _m.info.family in ("rating", "sediment", "streamflow"):
        METHOD_FAMILY[_id] = "hydrol"
    elif _m.info.family == "tidal":
        METHOD_FAMILY[_id] = "process"
    elif _m.info.family == "groundwater":
        METHOD_FAMILY[_id] = "process"
    else:
        METHOD_FAMILY[_id] = "neighbor"

PRIOR_FILE = Path(__file__).resolve().parent / "data" / "suggest_prior.json"


def load_prior(path=None) -> dict | None:
    """The empirical prior of the benchmark (experiment 3): a score adjustment per variable and method, fitted on held-out seeds.

    Returns None when no prior file exists, in which case the suggestion uses the literature defaults only (version v1).
    """
    p = Path(path) if path else PRIOR_FILE
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


SHORT_ONLY = {"interp"}  # families that only make sense for short gaps
DONOR_METHODS_NEED = ("neighbors", "neighbors>=2")


@dataclass
class Suggestion:
    variable: str
    target: str
    codes: list
    table: pd.DataFrame
    global_warnings: list = field(default_factory=list)
    not_available: dict = field(default_factory=dict)
    facts: dict = field(default_factory=dict)

    def top(self, n: int = 3) -> list:
        return list(self.table["method"].iloc[:n])

    def summary(self, n: int = 6) -> str:
        f = self.facts
        lines = [f"Suggestions for {self.target} ({self.variable}). Gap types found: {', '.join(self.codes) or 'none'}.",
                 f"Missing {100 * f.get('missing_frac', 0):.1f} %; {100 * f.get('long_share', 0):.0f} % of the missing steps are in long gaps; donors with data inside the gaps: {f.get('donors_in_gaps', 0)}."]
        for w in self.global_warnings:
            lines.append(f"  ! {w}")
        lines.append("")
        for _, r in self.table.head(n).iterrows():
            lines.append(f"{int(r['rank'])}. {r['method']} ({r['name']})")
            for x in r["reasons"]:
                lines.append(f"     + {x}")
            for x in r["warnings"]:
                lines.append(f"     ! {x}")
        return "\n".join(lines)


def _column_facts(profile, target: str, series: pd.Series, others, ctx: Ctx) -> dict:
    runs = profile.runs[profile.runs["column"] == target]
    interior = runs[runs["position"] == "interior"] if "position" in runs else runs
    miss_total = float(series.isna().mean())
    cfg = profile.config
    cells_long = float(runs.loc[runs["days"] > cfg.short_days, "length"].sum())
    cells_all = float(runs["length"].sum()) or 1.0
    donors = profile.donors[(profile.donors["column"] == target)] if len(profile.donors) else pd.DataFrame()
    prod = set(ctx.meta.get("product", []))
    donors = donors[~donors["donor"].isin(prod)] if len(donors) else donors
    good = donors[(donors["overlap_days"] >= cfg.donor_min_overlap_days) & (donors["r"] >= cfg.donor_min_corr)] if len(donors) else donors
    in_gaps = float((good["available_in_gaps"] > 0.5).sum()) if len(good) else 0.0
    dec = float(profile.columns.set_index("column").loc[target, "decorrelation_steps"]) if target in set(profile.columns["column"]) else np.nan
    return dict(
        missing_frac=miss_total, long_share=cells_long / cells_all, longest_days=float(runs["days"].max()) if len(runs) else 0.0,
        n_runs=len(runs), usable_donors=int(len(good)), donors_in_gaps=int(in_gaps), decorrelation_steps=dec,
        leading_trailing=bool((runs["position"] != "interior").any()) if "position" in runs else False,
        n_observed=int(series.notna().sum()),
        span_years=float((series.dropna().index[-1] - series.dropna().index[0]).days / 365.25) if series.notna().sum() > 1 else 0.0,
    )


def suggest(profile, series: pd.Series, others: pd.DataFrame | None = None, ctx: Ctx | None = None, target: str | None = None, include_slow: bool = True, prior="auto") -> Suggestion:
    """Ranked shortlist. `prior` is "auto" (use the benchmark prior if the file exists), None (literature defaults only, v1), a path, or a loaded dict."""
    ctx = ctx or Ctx()
    if isinstance(prior, str) and prior == "auto":
        prior = load_prior()
    elif isinstance(prior, (str, Path)):
        prior = load_prior(prior)
    adjust = (prior or {}).get("adjust", {}).get(ctx.variable, {})
    support = (prior or {}).get("support", {}).get(ctx.variable, {})
    target = target or ctx.target or series.name
    ctx.target = ctx.target or target
    f = _column_facts(profile, target, series, others, ctx)
    f_codes = profile.findings
    codes = sorted({c for c, s in zip(f_codes["code"], f_codes["scope"]) if s in (target, "network")}, key=lambda c: int(c[1:])) if len(f_codes) else []
    col = VARIABLE_COLUMN.get(ctx.variable)
    gwarn = []
    long_share = f["long_share"]
    mostly_long = long_share > 0.5
    mnar = any(c in codes for c in ("G10", "G14"))
    if mnar:
        gwarn.append("Gaps sit next to extreme values (G10 or G14): the missingness may depend on the value itself. Masked tests will be optimistic; report wide intervals and do not present one fill as the truth.")
    if "G11" in codes:
        gwarn.append("Clipped or stuck values (G11): values at the ceiling are censored, not measured. Fill methods will under-estimate the clipped peaks.")
    if "G12" in codes:
        gwarn.append("Sentinel codes (G12) were converted to missing before the analysis. Check that real zeros were not converted.")
    if "G13" in codes:
        gwarn.append("Accumulated totals (G13): a large value after a gap holds the sum of the missing days. Fill the gap so that the total is kept, or the volume will be double counted.")
    if "G15" in codes:
        gwarn.append("Sparse or isolated observations (G15): masked tests hide single samples; scores are noisy with few samples.")
    if "G7" in codes and f["donors_in_gaps"] == 0:
        gwarn.append("Network-wide outage (G7): the neighbours are missing in the same steps, so station donors cannot fill the gaps. A gridded or reanalysis product is the usual way out.")
    if f["usable_donors"] == 0 and (others is not None and others.shape[1] > 0):
        gwarn.append("No donor series with enough overlap and correlation: neighbour methods are not available.")
    thin = "G9" in codes
    prod_cols = ctx.meta.get("product", [])
    drv = ctx.meta.get("driver")
    drv_cov = float(others[drv][series.isna()].notna().mean()) if drv and others is not None and drv in others.columns and series.isna().any() else 0.0
    rows, na = [], {}
    for mid, m in REGISTRY.items():
        problems = m.check(series, others, ctx)
        if problems:
            na[mid] = problems
            continue
        if not include_slow and m.info.cost == "high":
            continue
        fam = METHOD_FAMILY.get(mid, "neighbor")
        reasons, warns = [], []
        score = 0.0
        # 1. applicability matrix
        lvl = MATRIX[fam][col] if col is not None else FAIR
        if lvl is None:
            lvl = LIMITED
            reasons.append(f"{FAMILY_LABEL[fam]}: not a standard choice for {ctx.variable}")
        else:
            reasons.append(f"{FAMILY_LABEL[fam]}: {LEVEL_WORD[lvl]} default for {ctx.variable}")
        score += lvl
        # 2. declared gap types vs found
        hit = [c for c in m.info.best_for if c in codes]
        if hit:
            score += min(len(hit), 2) * 0.7
            reasons.append("built for " + ", ".join(hit) + " which are in your series")
        # 3. gap length
        if fam in SHORT_ONLY:
            if mostly_long:
                score -= 1.5
                warns.append("interpolation across long gaps flattens the signal and invents no events")
            elif long_share < 0.15:
                score += 0.8
                reasons.append("most gaps are short, where interpolation is reliable")
        if fam == "clim" and mostly_long:
            score += 0.5
            reasons.append("long gaps: nothing better than the typical seasonal value without a donor")
        if mid in ("arima_kalman", "state_space_uc", "gp_local", "tide_harmonic_ar") and mostly_long:
            score -= 0.5
            warns.append("model memory fades in long gaps; the fill tends to the mean")
        # 4. donors
        needs_donor = any(n in m.info.needs for n in DONOR_METHODS_NEED)
        if needs_donor:
            if f["donors_in_gaps"] >= 1:
                score += 0.4
                reasons.append(f"{f['donors_in_gaps']} donor(s) observed during most of the gaps")
            else:
                score -= 1.5
                warns.append("donors are mostly missing when your gaps occur")
            if thin and m.info.id in ("linear_regression", "linear_regression_resid", "lagged_regression", "mice", "em_mvn", "flow_move"):
                score -= 1.0
                warns.append("thin overlap with the donor (G9): regression coefficients are unstable")
        if "product" in m.info.needs:
            if "G7" in codes or "G3" in codes or "G4" in codes:
                score += 0.8
                reasons.append("a gridded product exists for the whole record, also when stations are missing")
        # 5. variable-specific rules
        if ctx.variable == "rainfall":
            if fam == "interp" or mid in ("moving_mean", "moving_median"):
                warns.append("smooth filling gives the wrong wet-day frequency and dry-spell lengths")
                score -= 0.5
            if mid in ("rain_two_step", "rain_simolo") and f["usable_donors"] >= 2:
                score += 0.8
                reasons.append("keeps wet-day frequency and the distribution of daily amounts")
            if mid in ("normal_ratio", "idw") and ({"G1", "G2"} & set(codes)):
                score += 0.5
        if ctx.variable == "temperature" and mid in ("temp_neighbor_elevation", "temp_diurnal_anomaly"):
            score += 0.6
            reasons.append("respects the lapse rate and the daily cycle")
        if ctx.variable == "streamflow":
            if mid in ("flow_dar", "flow_move", "flow_fdc_transfer", "lagged_regression") and f["donors_in_gaps"] >= 1:
                score += 0.6
                reasons.append("donor-gauge transfer for flow gaps")
            if mid.startswith("flow_gr4j"):
                score += 0.4
                reasons.append("rainfall-runoff model uses the rain that fell during the gap")
                warns.append("flow error follows rainfall error; slow to run")
            if mid.startswith("rating_"):
                if drv_cov >= 0.8:
                    score += 1.6
                    reasons.append(f"stage is recorded during {100 * drv_cov:.0f} % of the gaps and gaugings are available: use the rating curve")
                else:
                    score += 0.2
                    warns.append(f"stage is recorded in only {100 * drv_cov:.0f} % of the gaps")
        if ctx.variable == "stage" and mid.startswith("rating_inv"):
            score += 1.6 if drv_cov >= 0.8 else 0.2
            if drv_cov >= 0.8:
                reasons.append(f"discharge is recorded during {100 * drv_cov:.0f} % of the gaps: invert the rating")
        if ctx.variable == "tide":
            if mid.startswith("tide_"):
                score += 1.0
                reasons.append("tide from fitted constituents; interpolation cannot reproduce a 12.4 h oscillation")
            if fam == "interp":
                warns.append("a straight line across tidal cycles removes the tide")
            if fam == "tsmodel":
                score -= 1.5
                warns.append("no tidal harmonic terms: the 12.4 h cycle is not carried across the gap")
            if fam == "clim" and not mid.startswith("tide_"):
                score -= 2.0  # annual and daily harmonics or a daily climatology contain no tidal frequencies (benchmark e6: error equal to the spread of the tide)
                warns.append("no tidal frequencies: annual and daily harmonics cannot carry the 12.4 h cycle across the gap")
            if mid == "tide_harmonic_river" and mostly_long:
                score += 0.4
                reasons.append("river discharge explains changes in amplitude and mean level over long gaps")
        if ctx.variable == "sediment":
            if mid in ("sed_rating", "sed_rating_smear", "sed_wrtds", "sed_rating_seasonal", "sed_rating_limb"):
                score += 0.5
            if mid == "sed_rating":
                score -= 0.8
                warns.append("log-log rating without bias correction under-estimates loads")
            if mid == "sed_rating_smear":
                score += 0.4
                reasons.append("smearing corrects the retransformation bias of the log fit")
            if mid == "sed_turbidity":
                reasons.append("turbidity is a continuous surrogate")
                score += 0.8
            if mid == "sed_gbm":
                warns.append("cannot extrapolate above the sampled flows")
            if f["n_observed"] < 60 and mid in ("sed_wrtds", "sed_gbm"):
                score -= 1.0
                warns.append("too few samples for this method")
        if ctx.variable == "groundwater" and mid in ("gw_exp_response", "gw_distributed_lag", "gw_pastas"):
            score += 0.6
            reasons.append("slow response to recharge is modelled from rainfall")
        # 6. empirical record on the benchmark cases (experiment 3)
        if mid in adjust:
            adj = float(adjust[mid])
            score += adj
            k, n = support.get(mid, [None, None])
            if adj >= 0.4 and n:
                reasons.append(f"benchmark record: in the better third of the methods on {k} of {n} synthetic {ctx.variable} cases")
            elif adj <= -0.4 and n:
                warns.append(f"benchmark record: in the better third of the methods on only {k} of {n} synthetic {ctx.variable} cases")
        # 7. general warnings
        if m.info.family == "ml":
            warns.append("cannot extrapolate beyond the range it was trained on")
        if mnar and fam not in ("hydrol",):
            warns.append("MNAR suspect: peaks will be under-estimated")
        if m.info.cost == "high":
            score -= 0.3
        if m.info.uncertainty:
            reasons.append("returns uncertainty bands")
            score += 0.2
        rows.append(dict(method=mid, name=m.info.name, family=m.info.family, score=round(score, 2), reasons=reasons, warnings=list(dict.fromkeys(warns)), cost=m.info.cost))
    table = pd.DataFrame(rows, columns=["method", "name", "family", "score", "reasons", "warnings", "cost"]).sort_values(["score", "method"], ascending=[False, True]).reset_index(drop=True)
    table.insert(0, "rank", np.arange(1, len(table) + 1))
    if ctx.variable in ("rainfall",) and {"G1", "G2"} & set(codes) and "linear" in set(table["method"]):
        gwarn.append("Linear interpolation is not recommended for rainfall: it invents drizzle and distorts wet-day frequency.")
    f["prior"] = (prior or {}).get("version")
    return Suggestion(ctx.variable, target, codes, table, gwarn, na, f)
