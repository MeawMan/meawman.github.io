"""Local web app: upload a table, diagnose the gaps, get method suggestions, compare methods on your own data, fill, and validate.

    python -m gaplens.webapp            # opens http://127.0.0.1:8765
    python -m gaplens.webapp --port 9000 --no-browser

Only the Python standard library is used for the server; the page is one HTML file with no outside scripts or fonts, so it works offline.
The server listens on 127.0.0.1 only. Uploaded data stay in the memory of the process.
"""

from __future__ import annotations

import argparse
import io
import json
import math
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import numpy as np
import pandas as pd

from . import __version__, calval, samples, service
from .gaps import NAMES as GAP_NAMES
from .methods import REGISTRY
from .methods.rating import fit_rating, normalise_gaugings

STATIC = Path(__file__).parent / "static"
MAX_UPLOAD = 60 * 1024 * 1024

DATASETS: dict = {}
JOBS: dict = {}
FILLS: dict = {}
LOCK = threading.Lock()


# ------------------------------------------------------------------------------------------------ json helpers


def clean(obj):
    """Make anything JSON-safe: NaN to null, numpy to python, frames to records."""
    if obj is None or isinstance(obj, (str, bool)):
        return obj
    if isinstance(obj, (int,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        v = float(obj)
        return v if math.isfinite(v) else None
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, (pd.Timestamp, np.datetime64)):
        return str(pd.Timestamp(obj))
    if isinstance(obj, pd.Timedelta):
        return str(obj)
    if isinstance(obj, pd.DataFrame):
        frame = obj if isinstance(obj.index, pd.RangeIndex) else obj.reset_index()
        return [clean(r) for r in frame.to_dict("records")]
    if isinstance(obj, pd.Series):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [clean(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [clean(v) for v in obj.tolist()]
    return str(obj)


def thin(series: pd.Series, max_points: int = 1600) -> dict:
    """Bins of the series for plotting: time, mean, min and max per bin (null where the whole bin is missing) and the share of missing steps per bin."""
    n = len(series)
    v = series.to_numpy(float)
    if n <= max_points:
        return dict(t=[str(t) for t in series.index], mean=clean(v), lo=clean(v), hi=clean(v), miss=clean(np.isnan(v).astype(float)))
    stride = int(math.ceil(n / max_points))
    m = int(math.ceil(n / stride)) * stride
    pad = np.concatenate([v, np.full(m - n, np.nan)]).reshape(-1, stride)
    with np.errstate(all="ignore"):
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mean, lo, hi = np.nanmean(pad, axis=1), np.nanmin(pad, axis=1), np.nanmax(pad, axis=1)
    t = [str(series.index[min(i * stride, n - 1)]) for i in range(pad.shape[0])]
    count = np.concatenate([np.ones(n), np.zeros(m - n)]).reshape(-1, stride).sum(axis=1)
    miss = np.concatenate([np.isnan(v).astype(float), np.zeros(m - n)]).reshape(-1, stride).sum(axis=1) / count
    return dict(t=t, mean=clean(mean), lo=clean(lo), hi=clean(hi), miss=clean(miss))


def missing_by_month(df: pd.DataFrame, cols) -> dict:
    out = {}
    for c in cols:
        m = df[c].isna().groupby([df.index.year, df.index.month]).mean()
        out[c] = [[f"{y}-{mo:02d}", float(v)] for (y, mo), v in m.items()]
    return out


# ------------------------------------------------------------------------------------------------ jobs


SYNC_JOBS = False  # True in the browser build (Pyodide has no threads): jobs wait in PENDING until run_pending() is called
PENDING: list = []
PROGRESS_HOOK = None  # callable(job_id, done, total, message) used by the browser build to show progress while a job runs


class _Job(dict):
    """A job record; every update is passed to PROGRESS_HOOK when one is set."""

    def update(self, *a, **kw):
        super().update(*a, **kw)
        if PROGRESS_HOOK is not None and ("done" in kw or "message" in kw):
            try:
                PROGRESS_HOOK(self["id"], self.get("done", 0), self.get("total", 0), str(self.get("message", "")))
            except Exception:  # noqa: BLE001 - a display hook must never stop the job
                pass


def _run_job(jid, fn, args, kw):
    try:
        JOBS[jid]["result"] = fn(JOBS[jid], *args, **kw)
        JOBS[jid]["status"] = "done"
    except Exception as e:  # noqa: BLE001
        JOBS[jid]["status"] = "error"
        JOBS[jid]["error"] = f"{type(e).__name__}: {e}"
        JOBS[jid]["trace"] = traceback.format_exc()[-1500:]
    JOBS[jid]["seconds"] = time.time() - JOBS[jid]["t0"]


def start_job(fn, *args, **kw) -> str:
    jid = uuid.uuid4().hex[:10]
    JOBS[jid] = _Job(id=jid, status="running", done=0, total=0, message="starting", t0=time.time(), result=None, error=None)
    if SYNC_JOBS:
        PENDING.append((jid, fn, args, kw))
    else:
        threading.Thread(target=_run_job, args=(jid, fn, args, kw), daemon=True).start()
    return jid


def run_pending() -> list:
    """Run the jobs queued in SYNC_JOBS mode, one after another. Returns their ids."""
    done = []
    while PENDING:
        jid, fn, args, kw = PENDING.pop(0)
        JOBS[jid]["t0"] = time.time()
        _run_job(jid, fn, args, kw)
        done.append(jid)
    return done


# ------------------------------------------------------------------------------------------------ task handling


def get_task(p: dict):
    ds = DATASETS.get(p.get("id"))
    if ds is None:
        raise KeyError("dataset not found: upload the file again")
    kw = {k: p.get(k) for k in ("driver", "surrogate", "precip", "pet", "latitude") if p.get(k) not in (None, "")}
    if "latitude" in kw:
        kw["latitude"] = float(kw["latitude"])
    gaug = None
    if p.get("gaugings_id"):
        gaug = DATASETS[p["gaugings_id"]]["df"]
    stations = DATASETS[p["stations_id"]]["df"] if p.get("stations_id") else None
    series, others, ctx = service.build_task(ds["df"], p["target"], p.get("variable") or "auto", product=p.get("product") or [], exclude=p.get("exclude") or [], gaugings=gaug, stations=stations, **kw)
    if p.get("manual_rating"):  # curve set in the rating-curve editor: used by the rating_manual methods
        ctx.meta["manual_rating"] = p["manual_rating"]
    if p.get("yearly_rating"):  # options of the year-by-year rating (start month, minimum gaugings, borrowing rule)
        ctx.meta["yearly_rating"] = p["yearly_rating"]
    return ds, series, others, ctx


def register_dataset(name: str, df: pd.DataFrame, info: dict, kind: str = "data", **extra) -> dict:
    did = uuid.uuid4().hex[:8]
    DATASETS[did] = dict(id=did, name=name, df=df, info=info, kind=kind, **extra)
    return dict(id=did, name=name, kind=kind, **{k: v for k, v in info.items()})


# ------------------------------------------------------------------------------------------------ api


def api_methods(_p=None):
    rows = []
    for mid, m in REGISTRY.items():
        i = m.info
        rows.append(dict(id=mid, name=i.name, family=i.family, variables=list(i.variables), best_for=list(i.best_for), limits=i.limits, library=i.library, section=i.section, status=i.status, cost=i.cost, uncertainty=i.uncertainty, needs=list(i.needs)))
    return dict(methods=rows, gap_types=GAP_NAMES, version=__version__)


def api_sample(p):
    name = p.get("name")
    if name not in samples.NAMES:
        raise KeyError(f"unknown sample; choose from {sorted(samples.NAMES)}")
    s = samples.sample(name)
    info = dict(date_col="date", step=str(pd.Series(s["df"].index).diff().median()), n=len(s["df"]), start=str(s["df"].index[0]), end=str(s["df"].index[-1]), warnings=[],
                columns=[{"name": c, "missing_frac": float(s["df"][c].isna().mean()), "guess": service.guess_variable(c, s["df"][c]), "min": float(s["df"][c].min()), "max": float(s["df"][c].max())} for c in s["df"].columns])
    out = register_dataset(name + ".csv", s["df"], info, truth=s["truth"])
    out["settings"] = s["settings"]
    out["note"] = s["note"]
    if s["gaugings"] is not None:
        g = s["gaugings"].copy()
        g.index = pd.to_datetime(g["date"])
        gi = dict(n=len(g), columns=[{"name": c} for c in g.columns], warnings=[])
        did = uuid.uuid4().hex[:8]
        DATASETS[did] = dict(id=did, name="gaugings.csv", df=g.reset_index(drop=True), info=gi, kind="gaugings")
        out["gaugings_id"] = did
    if s["stations"] is not None:
        did = uuid.uuid4().hex[:8]
        DATASETS[did] = dict(id=did, name="stations.csv", df=s["stations"].reset_index(), info=dict(n=len(s["stations"])), kind="stations")
        out["stations_id"] = did
    return out


def api_series(p):
    ds, series, others, ctx = get_task(p)
    return dict(series=thin(series), missing_frac=float(series.isna().mean()))


def api_profile(p):
    ds, series, others, ctx = get_task(p)
    prof = service.run_profile(ds["df"], ctx, others)
    f = prof.findings.copy()
    f["name"] = f["code"].map(GAP_NAMES)
    f["detail"] = f["detail"].map(lambda d: json.dumps(clean(d)) if isinstance(d, dict) else str(d))
    runs = prof.runs[prof.runs["column"] == ctx.target]
    bins = [0, 1, 3, 7, 30, 90, 365, 1e9]
    labels = ["1 day", "2-3 days", "4-7 days", "8-30 days", "31-90 days", "91-365 days", "over a year"]
    hist = []
    if len(runs):
        cat = pd.cut(runs["days"].clip(lower=1e-9), bins=[0, 1.0001, 3.0001, 7.0001, 30.0001, 90.0001, 365.0001, 1e12], labels=labels)
        for lab in labels:
            sel = runs[cat == lab]
            hist.append(dict(label=lab, runs=int(len(sel)), steps=int(sel["length"].sum())))
    cols = [c for c in prof.cleaned.columns]
    return dict(summary=prof.summary(), findings=f, verdict=prof.verdict(), mechanism=prof.mechanism, columns=prof.columns, run_hist=hist, series=thin(prof.cleaned[ctx.target]),
                monthly=missing_by_month(prof.cleaned, cols[:8]), codes=prof.codes, step=prof.freq, sentinels=clean(prof.meta.get("sentinels")))


def api_suggest(p):
    ds, series, others, ctx = get_task(p)
    prof = service.run_profile(ds["df"], ctx, others)
    sg = service.run_suggest(prof, series, others, ctx, include_slow=bool(p.get("include_slow", True)))
    rows = sg.table.head(int(p.get("top", 25))).copy()
    return dict(codes=sg.codes, warnings=sg.global_warnings, facts=sg.facts, table=rows, not_available=sg.not_available, summary=sg.summary(8))


def _job_compare(job, p):
    ds, series, others, ctx = get_task(p)
    methods = p.get("methods") or None

    def progress(done, total, mid):
        job.update(done=done, total=total, message=mid)

    res = service.run_compare(series, others, ctx, methods=methods, n_rep=int(p.get("n_rep", 4)), frac=float(p.get("frac", 0.10)), design=p.get("design", "auto"), seed=int(p.get("seed", 0)), progress=progress)
    job["res"], job["ctx"], job["settings"] = res, ctx, p
    preset = p.get("preset", "balanced")
    tabs = service.comparison_tables(res, preset)
    best = res.best(preset, n=3)
    return dict(
        design=res.design, n_hidden=res.n_hidden, preset=preset, presets=sorted(__import__("gaplens").metrics.PRESETS), best=best,
        ranking=tabs["ranking"], summary=tabs["summary"], by_length=tabs["by_length"], rmse_ci=tabs["rmse_ci"], timing=tabs["timing"].round(3),
        errors=tabs["errors"], skipped=tabs["skipped"],
    )


def api_compare(p):
    return dict(job=start_job(_job_compare, p))


def api_rank(p):
    job = JOBS.get(p.get("job"))
    if not job or job.get("res") is None:
        raise KeyError("comparison not found")
    preset = p.get("preset", "balanced")
    tabs = service.comparison_tables(job["res"], preset)
    return dict(preset=preset, ranking=tabs["ranking"], best=job["res"].best(preset, n=3))


def _job_fill(job, p):
    ds, series, others, ctx = get_task(p)
    methods = p["methods"]
    job.update(total=len(methods), message="filling")
    out = service.run_fill(series, others, ctx, methods)
    fid = uuid.uuid4().hex[:8]
    table = pd.DataFrame({p["target"]: series, f"{p['target']}_filled": out["value"], "flag": out["flag"], "method": out["method"], "lower": out["lo"], "upper": out["hi"]})
    FILLS[fid] = table
    counts = out.loc[out["flag"] == "filled", "method"].value_counts().to_dict()
    truth = ds.get("truth")
    check = None
    if truth is not None:
        m = (out["flag"] == "filled") & truth.notna()
        if m.sum() > 3:
            e = (out.loc[m, "value"] - truth[m]).to_numpy(float)
            check = dict(n=int(m.sum()), rmse=float(np.sqrt(np.nanmean(e**2))), bias=float(np.nanmean(e)))
    return dict(fill_id=fid, observed=thin(series), filled=thin(out["value"].where(out["flag"] == "filled")), lo=thin(out["lo"]) if out["lo"].notna().any() else None, hi=thin(out["hi"]) if out["hi"].notna().any() else None,
                counts=counts, notes=out.attrs.get("notes", []), n_missing=int((out["flag"] == "missing").sum()), n_filled=int((out["flag"] == "filled").sum()), truth_check=check)


def api_fill(p):
    return dict(job=start_job(_job_fill, p))


def api_calval(p):
    ds = DATASETS[p["id"]]
    df = ds["df"]
    al, rep, corr = service.run_calval(df[p["obs"]], df[p["sim"]], variable=p.get("variable", "generic"), how=p.get("how", "mean"), apply_lag=bool(p.get("apply_lag", False)),
                                        scheme=p.get("scheme", "blocked_kfold"), thresholds=p.get("thresholds", "moriasi2015"))
    pair = pd.concat([al.obs.rename("obs"), al.sim.rename("sim")], axis=1)
    ok = pair.dropna()
    scatter = ok.iloc[:: max(1, len(ok) // 1500)]
    return dict(align=al.summary(), lag_curve=al.lag_curve, lag_steps=al.lag_steps, notes=al.notes, validation=rep.table, summary=rep.summary(), val_notes=rep.notes, corrections=corr,
                obs=thin(pair["obs"]), sim=thin(pair["sim"]), scatter=dict(obs=clean(scatter["obs"].to_numpy()), sim=clean(scatter["sim"].to_numpy())), thresholds_source=rep.source)


def api_calibrate(p):
    ds = DATASETS[p["id"]]
    df = ds["df"]
    obs = df[p["obs"]]
    name = p.get("model", "rating")
    if name == "rating":
        model, forcing = calval.rating_power_law(), {"x": df[p["x"]].to_numpy(float)}
    elif name == "linear_reservoir":
        model, forcing = calval.linear_reservoir(), {"P": df[p["x"]].to_numpy(float)}
    elif name == "gr4j":
        pet = df[p["pet"]].to_numpy(float) if p.get("pet") else None
        if pet is None:
            from .methods.streamflow import _pet_default

            pet = _pet_default(df.index)
        model, forcing = calval.gr4j_model(), {"P": df[p["x"]].fillna(0).to_numpy(float), "E": np.asarray(pet, float)}
    else:
        raise KeyError("model must be rating, linear_reservoir or gr4j")

    def run(job):
        job.update(message="calibrating", total=1)
        out = calval.run_calval(model, forcing, obs, scheme=p.get("scheme", "split_sample"), objective=p.get("objective", "kge"), method=p.get("method", "de"), budget=int(p.get("budget", 1200)), warmup=int(p.get("warmup", 0)))
        sim = out.sim
        rep = calval.validate(obs, sim, n_boot=100) if sim is not None else None
        return dict(summary=out.summary(), table=out.table, params=out.params, warnings=out.warnings, final=out.final.params if out.final else None, spread=out.final.spread if out.final else None,
                    validation=rep.table if rep else None, obs=thin(obs), sim=thin(sim) if sim is not None else None)

    return dict(job=start_job(run))


def api_rating(p):
    g = normalise_gaugings(DATASETS[p["gaugings_id"]]["df"])
    fit = fit_rating(g, segmented=bool(p.get("segmented", False)), shifts=bool(p.get("shifts", False)))
    last = g["date"].iloc[-1]
    h = np.linspace(max(g["h"].min() * 0.9, fit.h0[-1] + 1e-3), g["h"].max() * 1.35, 80)
    q = fit.steady(h, pd.DatetimeIndex([last] * len(h)))
    fitted = fit.steady(g["h"].to_numpy(), pd.DatetimeIndex(g["date"]))
    resid = pd.DataFrame({"date": g["date"], "stage": g["h"], "gauged": g["q"], "fitted": fitted, "rel_error_pct": 100 * (fitted - g["q"]) / g["q"]})
    out = dict(kind=fit.kind, n=fit.n, rmse_ln=fit.rmse_ln, ln_a=fit.ln_a, a=float(np.exp(fit.ln_a)), b1=fit.b1, b2=fit.b2, hb=fit.hb, h0=fit.h0.tolist(), breaks=[str(b) for b in fit.breaks], notes=fit.notes,
               gauged_range=dict(h=[fit.h_min, fit.h_max], q=[fit.q_min, fit.q_max]), curve=dict(h=clean(h), q=clean(q)), residuals=resid)
    if p.get("yearly_rating"):
        from .methods.rating import YEARLY_DEFAULTS, fit_yearly_info

        opt = {**YEARLY_DEFAULTS, **p["yearly_rating"]}
        out["yearly"], out["yearly_info"] = fit_yearly_info(g, **opt)
        out["yearly_options"] = opt
    if p.get("id") and p.get("stage_col"):
        stage = DATASETS[p["id"]]["df"][p["stage_col"]]
        out["flags"] = clean(fit.flags(stage).iloc[:: max(1, len(stage) // 400)])
        out["discharge"] = thin(fit.discharge(stage))
        if p.get("yearly_rating"):  # the year-by-year curves, applied to the whole stage series
            from .methods.rating import YEARLY_DEFAULTS, fit_yearly, yearly_discharge

            opt = {**YEARLY_DEFAULTS, **p["yearly_rating"]}
            qy, src = yearly_discharge(stage, fit_yearly(g, **opt), **opt)
            out["discharge_yearly"] = thin(qy)
            out["yearly_sources"] = {str(k): v for k, v in src.items()}
        if p.get("manual_rating"):  # the curve set in the editor, applied to the whole stage series
            from .methods.rating import manual_discharge, normalise_manual

            qm = pd.Series(manual_discharge(stage.to_numpy(float), normalise_manual(p["manual_rating"])), index=stage.index)
            qm[stage.isna()] = np.nan
            out["discharge_manual"] = thin(qm)
            out["above_gauged_pct"] = float(100 * (stage > fit.h_max).mean())
    return out


# ------------------------------------------------------------------------------------------------ http


def _json_bytes(obj) -> bytes:
    return json.dumps(clean(obj), allow_nan=False).encode("utf-8")


JSON = "application/json; charset=utf-8"


def dispatch(method: str, path: str, query: dict, body: bytes = b""):
    """Answer one API request without a network: returns (status, content type, body bytes, extra headers).
    The local server and the browser build (Pyodide) both call this."""
    q = {k: (v[0] if isinstance(v, list) else v) for k, v in (query or {}).items()}
    try:
        if method == "GET":
            if path in ("/", "/index.html"):
                return 200, "text/html; charset=utf-8", (STATIC / "index.html").read_bytes(), {}
            if path == "/api/methods":
                return 200, JSON, _json_bytes(api_methods()), {}
            if path == "/api/samples":
                return 200, JSON, _json_bytes(dict(samples=samples.NAMES)), {}
            if path == "/api/job":
                j = JOBS.get(q.get("id"))
                if j is None:
                    return 404, JSON, _json_bytes(dict(error="job not found")), {}
                keep = {k: v for k, v in j.items() if k not in ("res", "ctx", "settings", "t0")}
                keep["elapsed"] = time.time() - j["t0"]
                return 200, JSON, _json_bytes(keep), {}
            if path == "/api/download":
                t = FILLS.get(q.get("id"))
                if t is None:
                    return 404, JSON, _json_bytes(dict(error="fill not found")), {}
                buf = io.StringIO()
                t.to_csv(buf, index_label="date")
                return 200, "text/csv; charset=utf-8", buf.getvalue().encode("utf-8"), {"Content-Disposition": f'attachment; filename="filled_{q.get("id")}.csv"'}
            if path == "/api/report":
                from .report import make_report

                j = JOBS.get(q.get("job"))
                if j is None or j.get("res") is None:
                    return 404, JSON, _json_bytes(dict(error="comparison not found")), {}
                html = make_report(j["settings"], DATASETS[j["settings"]["id"]], j["res"], FILLS.get(q.get("fill")))
                return 200, "text/html; charset=utf-8", html.encode("utf-8"), {"Content-Disposition": 'attachment; filename="gaplens_report.html"'}
            return 404, JSON, _json_bytes(dict(error="not found")), {}
        if len(body) > MAX_UPLOAD:
            return 413, JSON, _json_bytes(dict(error="file too large (limit 60 MB)")), {}
        if path == "/api/upload":
            kind = q.get("kind", "data")
            name = q.get("name", "upload.csv")
            if kind == "data":
                df, info = service.read_table(body, date_col=q.get("date_col") or None)
                return 200, JSON, _json_bytes(register_dataset(name, df, info, "data")), {}
            raw = pd.read_csv(io.BytesIO(body), sep=None, engine="python")  # gaugings or stations: plain tables
            raw.columns = [str(c).strip() for c in raw.columns]
            return 200, JSON, _json_bytes(register_dataset(name, raw, dict(n=len(raw), columns=[{"name": c} for c in raw.columns], warnings=[]), kind)), {}
        p = json.loads(body.decode("utf-8")) if body else {}
        route = {"/api/sample": api_sample, "/api/series": api_series, "/api/profile": api_profile, "/api/suggest": api_suggest, "/api/compare": api_compare, "/api/rank": api_rank, "/api/fill": api_fill,
                 "/api/calval": api_calval, "/api/calibrate": api_calibrate, "/api/rating": api_rating}.get(path)
        if route is None:
            return 404, JSON, _json_bytes(dict(error="not found")), {}
        return 200, JSON, _json_bytes(route(p)), {}
    except Exception as e:  # noqa: BLE001
        return (500 if method == "GET" else 400), JSON, _json_bytes(dict(error=f"{type(e).__name__}: {e}", trace=traceback.format_exc()[-1200:])), {}


class Handler(BaseHTTPRequestHandler):
    server_version = "gaplens"

    def log_message(self, fmt, *args):  # quiet
        pass

    def _send(self, code: int, body: bytes, ctype: str, headers: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _answer(self, method: str, body: bytes = b""):
        u = urlparse(self.path)
        code, ctype, out, headers = dispatch(method, u.path, parse_qs(u.query), body)
        self._send(code, out, ctype, headers)

    def do_GET(self):  # noqa: N802
        self._answer("GET")

    def do_POST(self):  # noqa: N802
        n = int(self.headers.get("Content-Length", 0))
        if n > MAX_UPLOAD:
            return self._send(413, _json_bytes(dict(error="file too large (limit 60 MB)")), JSON)
        self._answer("POST", self.rfile.read(n) if n else b"")


def make_server(port: int = 8765, host: str = "127.0.0.1") -> ThreadingHTTPServer:
    return ThreadingHTTPServer((host, port), Handler)


def main(argv=None):
    ap = argparse.ArgumentParser(description="gaplens web app")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args(argv)
    srv = make_server(a.port)
    url = f"http://127.0.0.1:{a.port}/"
    print(f"gaplens {__version__} running at {url}  (Ctrl+C to stop)", flush=True)
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
