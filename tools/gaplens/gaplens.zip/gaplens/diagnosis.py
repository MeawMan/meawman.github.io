"""Score the profiler against the 22 named cases, where the true gap types are known.

A gap type can legitimately imply another one: a 90-day seasonal window (G4) is also a set of long gaps (G3);
a network outage (G7) leaves long gaps (G3) in every station. Those are counted as "explained extras".
G10 (gaps at extremes, mechanism) and G14 (QC removal of extremes) cannot be told apart from the values alone,
so a hit on either counts for both.
"""

from __future__ import annotations

import warnings

import pandas as pd

from .gaps import build_cases
from .gaps.mechanisms import NAMES
from .profile import ProfileConfig, profile

IMPLIED = {
    "G4": {"G3"},
    "G7": {"G3", "G2"},
    "G8": {"G3"},
    "G9": {"G5", "G6"},
    "G10": {"G2", "G3", "G7", "G14"},
    "G14": {"G2", "G3", "G7", "G10"},
    "G12": {"G2"},
    "G13": {"G2"},
    "G15": {"G3"},
}
SAME_GROUP = [{"G10", "G14"}]


def _canon(code: str) -> str:
    for g in SAME_GROUP:
        if code in g:
            return "/".join(sorted(g, key=lambda c: int(c[1:])))
    return code


def score_case(want, got) -> dict:
    """want, got: iterables of codes. Returns hits, misses, explained and unexplained extras."""
    want, got = set(want), set(got)
    got_c = {_canon(c) for c in got}
    hit = {c for c in want if _canon(c) in got_c}
    miss = want - hit
    implied = set().union(*[IMPLIED.get(c, set()) for c in want]) if want else set()
    want_c = {_canon(c) for c in want}
    extras = {c for c in got if _canon(c) not in want_c}
    explained = {c for c in extras if c in implied}
    return dict(hit=sorted(hit, key=lambda c: int(c[1:])), miss=sorted(miss, key=lambda c: int(c[1:])),
                explained=sorted(explained, key=lambda c: int(c[1:])), unexplained=sorted(extras - explained, key=lambda c: int(c[1:])))


def run_benchmark(basin: dict, seed: int = 0, config: ProfileConfig | None = None, cases=None) -> pd.DataFrame:
    """Profile every case and score the result. One row per case."""
    rows = []
    built = build_cases(basin, seed=seed, cases=cases)
    for cid, (res, case) in built.items():
        variable = case["variable"] if case["variable"] in ("rainfall", "streamflow") else "generic"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            p = profile(res.observed, variable=variable, config=config)
        want = sorted({c for c, _ in case["spec"]}, key=lambda c: int(c[1:]))
        s = score_case(want, p.codes)
        rows.append(dict(case=cid, want="+".join(want), got="+".join(p.codes), hit="+".join(s["hit"]), miss="+".join(s["miss"]),
                         explained="+".join(s["explained"]), unexplained="+".join(s["unexplained"]), verdict=p.verdict()))
    return pd.DataFrame(rows)


def summarise(table: pd.DataFrame) -> dict:
    n_want = n_hit = n_extra_unexplained = n_got = 0
    for _, r in table.iterrows():
        w = [c for c in r["want"].split("+") if c]
        h = [c for c in r["hit"].split("+") if c]
        g = [c for c in r["got"].split("+") if c]
        u = [c for c in r["unexplained"].split("+") if c]
        n_want += len(w)
        n_hit += len(h)
        n_got += len(g)
        n_extra_unexplained += len(u)
    return dict(recall=n_hit / max(n_want, 1), unexplained_per_case=n_extra_unexplained / max(len(table), 1),
                exact_cases=int(((table["miss"] == "") & (table["unexplained"] == "")).sum()), n_cases=len(table))


def names(codes) -> str:
    return ", ".join(f"{c} {NAMES[c]}" for c in codes)
