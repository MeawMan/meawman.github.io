"""Compare module (catalog section 13): test every applicable method on masked copies of the user's own data.

    res = compare(series, others, ctx, config=CompareConfig(n_rep=5))
    res.table("pointwise")            mean of each metric by method
    res.by_length("pointwise.rmse")   method x gap length
    res.ranking("flood_frequency")    rank-based ordering for a use case
    res.errors, res.timing            what failed and how long each method took

How a test runs: values that are really observed are hidden in blocks of several lengths (the length ladder),
or in blocks copied from the real gaps; every applicable method fills the masked series; the filled values are
scored against the hidden truth. Real gaps are never scored. Several random placements (repetitions) give
bootstrap intervals.
"""

from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import metrics as M
from .gaps.result import find_runs
from .methods import REGISTRY, Ctx
from .methods.base import steps_per_day


@dataclass
class CompareConfig:
    ladder: tuple = (1, 3, 7, 30, 90)  # block lengths in steps
    frac: float = 0.10  # share of observed values hidden in one repetition (all lengths together)
    n_rep: int = 5
    design: str = "auto"  # auto | ladder | match | mnar_upper | sample (hide single samples: for sparse series)
    sample_frac: float = 0.25  # share of observed samples hidden in one repetition of the "sample" design
    groups: tuple | None = None  # metric groups; None = defaults of the variable
    seed: int = 0
    n_jobs: int = 1
    methods: tuple | None = None  # ids; None = every applicable method
    exclude: tuple = ()
    margin: int = 1  # free steps between blocks


# ----------------------------------------------------------------------------- hold-out design


def real_gap_lengths(series: pd.Series) -> np.ndarray:
    s, ln = find_runs(series.isna().to_numpy())
    # ignore leading and trailing gaps: they cannot be placed inside the record
    keep = [(a, b) for a, b in zip(s, ln) if a > 0 and a + b < len(series)]
    return np.array([b for _, b in keep], dtype=int)


def _free_starts(obs: np.ndarray, length: int) -> np.ndarray:
    n = len(obs)
    if length > n:
        return np.array([], dtype=int)
    c = np.concatenate([[0], np.cumsum(obs.astype(int))])
    win = c[length:] - c[:-length]
    return np.flatnonzero(win == length)


def resolve_design(series: pd.Series, design: str) -> str:
    """"auto" picks the sample design for sparse, isolated observations (G15) and the length ladder otherwise."""
    if design != "auto":
        return design
    obs = series.notna().to_numpy()
    if obs.mean() < 0.30:
        s, ln = find_runs(obs)
        if len(ln) and float(np.median(ln)) <= 2:
            return "sample"
    return "ladder"


def make_holdout(series: pd.Series, rng, ladder, frac, design="ladder", real_lengths=None, margin=1, sample_frac=0.25):
    """Return (hidden boolean array, class array) for one repetition. class = block length (int), 0 = not hidden."""
    y = series.to_numpy(float)
    n = len(y)
    obs = np.isfinite(y)
    n_obs = int(obs.sum())
    if design == "auto":
        design = resolve_design(series, design)
    if design == "sample":
        idx = np.flatnonzero(obs)
        k = min(max(int(round(sample_frac * len(idx))), 3), max(len(idx) - 8, 0))
        cls = np.zeros(n, dtype=int)
        if k > 0:
            cls[rng.choice(idx, size=k, replace=False)] = 1
        return cls > 0, cls
    taken = np.zeros(n, dtype=bool)  # hidden or in a margin
    cls = np.zeros(n, dtype=int)
    if design == "match" and real_lengths is not None and len(real_lengths):
        lengths_plan = []
        budget = frac * n_obs
        while budget > 0:
            L = int(rng.choice(real_lengths))
            lengths_plan.append(L)
            budget -= L
    else:
        per_class = frac * n_obs / len(ladder)
        lengths_plan = []
        for L in ladder:
            lengths_plan += [int(L)] * max(1, int(round(per_class / L)))
    weights_src = None
    if design == "mnar_upper":
        r = pd.Series(y).rank(pct=True).fillna(0.5).to_numpy()
        weights_src = r
    order = sorted(lengths_plan, reverse=True)  # long blocks first: they are hardest to place
    for L in order:
        free = obs & ~taken
        starts = _free_starts(free, L)
        if len(starts) == 0:
            continue
        if weights_src is not None:
            peak = pd.Series(weights_src).rolling(L, min_periods=1).max().shift(-(L - 1)).fillna(0).to_numpy()
            w = np.exp(8.0 * peak[starts])
            w = w / w.sum()
            s = int(rng.choice(starts, p=w))
        else:
            s = int(rng.choice(starts))
        cls[s : s + L] = L if design != "match" else _bin(L, ladder)
        lo, hi = max(0, s - margin), min(n, s + L + margin)
        taken[lo:hi] = True
    return cls > 0, cls


def _bin(L, ladder):
    """Assign a real gap length to the nearest ladder class (for reporting)."""
    lad = np.asarray(ladder)
    return int(lad[np.argmin(np.abs(np.log(lad) - np.log(max(L, 1))))])


# ----------------------------------------------------------------------------- one task


def driver_range(masked: pd.Series, others, ctx: Ctx):
    """Range of the paired driver (stage, discharge ...) for which calibration data exist; outside it a method extrapolates."""
    if "driver_range" in ctx.meta:
        return tuple(ctx.meta["driver_range"])
    g = ctx.meta.get("gaugings")
    if g is not None:
        from .methods.rating import normalise_gaugings

        gg = normalise_gaugings(g)
        col = "h" if ctx.variable == "streamflow" else "q"
        return float(gg[col].min()), float(gg[col].max())
    d = others[ctx.meta["driver"]]
    both = masked.notna() & d.notna()
    if both.sum() < 5:
        return None
    return float(d[both].min()), float(d[both].max())


def _metric_ctx(masked, others, ctx):
    spd = steps_per_day(masked.index)
    mctx = {"wet_threshold": ctx.wet_threshold, "steps_per_day": spd, "step_days": 1.0 / spd}
    drv = ctx.meta.get("driver")
    if drv is not None and others is not None and drv in others.columns:
        mctx["driver_full"] = others[drv].to_numpy(float)
        rng_ = driver_range(masked, others, ctx)
        if rng_ is not None:
            mctx["driver_range"] = rng_
    return mctx


def _run_task(mid, rep, series, others, ctx, hidden, cls, groups, params):
    t0 = time.time()
    out = {"rows": [], "error": None, "seconds": 0.0, "n_filled": 0}
    try:
        warnings.simplefilter("ignore")
        masked = series.where(~pd.Series(hidden, index=series.index))
        fo = REGISTRY[mid].run(masked, others, ctx, **params)
        mctx = _metric_ctx(masked, others, ctx)
        filled = fo.values
        out["seconds"] = fo.seconds
        h = pd.Series(hidden, index=series.index)
        out["n_filled"] = int(filled[h].notna().sum())
        # hidden values a method leaves empty (a spline limited to short gaps, a rating where the driver is missing) are
        # scored as they would be filled in a fill cascade: by linear interpolation. fill.share reports what it filled itself.
        left = h & filled.isna()
        if left.any():
            fallback = masked.interpolate(method="time", limit_direction="both")
            filled = filled.where(~left, fallback)
        groups_h = list(groups)
        has_int = fo.lo is not None
        if has_int and "probabilistic" not in groups_h:
            groups_h.append("probabilistic")
        for c in sorted(set(cls[hidden])):
            hc = pd.Series(cls == c, index=series.index)
            sc = M.score(series, filled, hc, groups=[g for g in groups_h if M.GROUPS[g][0] == "hidden"], variable=ctx.variable, ctx=dict(mctx), lo=fo.lo, hi=fo.hi)
            out["rows"] += [(mid, rep, int(c), k, v) for k, v in sc.items()]
        sc = M.score(series, filled, h, groups=groups_h, variable=ctx.variable, ctx=dict(mctx), lo=fo.lo, hi=fo.hi)
        out["rows"] += [(mid, rep, 0, k, v) for k, v in sc.items()]
        # share of the hidden values the method filled: the metrics above only see the filled ones
        n_h = int(h.sum())
        out["rows"].append((mid, rep, 0, "fill.share", out["n_filled"] / n_h if n_h else np.nan))
    except Exception as e:  # a failing method must not stop the comparison
        out["error"] = f"{type(e).__name__}: {e}"
    out["seconds_total"] = time.time() - t0
    return mid, rep, out


# ----------------------------------------------------------------------------- result


def summary_losses(s: pd.DataFrame) -> pd.DataFrame:
    """Loss (smaller is better) of every metric column of a method x 'group.metric' table; columns without a direction are left out."""
    out = pd.DataFrame(index=s.index)
    for c in s.columns:
        if M.direction_of(c) is not None:
            out[c] = [M.loss_of(c, v) for v in s[c]]
    return out


def summary_group_ranks(s: pd.DataFrame) -> pd.DataFrame:
    loss = summary_losses(s)
    ranks = loss.rank(axis=0, method="average", na_option="keep")
    groups = sorted({c.split(".", 1)[0] for c in ranks.columns})
    return pd.DataFrame({g: ranks[[c for c in ranks.columns if c.startswith(g + ".")]].mean(axis=1) for g in groups})


def rank_summary(s: pd.DataFrame, preset: str | dict = "balanced") -> pd.DataFrame:
    """Rank-based ordering of methods from a method x 'group.metric' table (used for the hold-out test and for the oracle scores alike)."""
    w = M.PRESETS[preset] if isinstance(preset, str) else preset
    gr = summary_group_ranks(s)
    used = [g for g in gr.columns if g in w]
    wt = np.array([w[g] for g in used], float)
    score = (gr[used] * wt).sum(axis=1, min_count=1) / np.where(gr[used].notna(), wt, 0).sum(axis=1)
    out = gr.copy()
    out["weighted_rank"] = score
    if "fill.share" in s.columns:
        out["fill_share"] = s["fill.share"]  # what the method filled itself; the rest was scored with linear interpolation
    return out.sort_values("weighted_rank")


@dataclass
class CompareResult:
    long: pd.DataFrame  # method, rep, cls, metric, value   (cls 0 = all hidden values)
    errors: pd.DataFrame
    timing: pd.DataFrame
    skipped: dict
    config: CompareConfig
    variable: str
    n_hidden: dict = field(default_factory=dict)
    design: str = ""

    def summary(self, cls: int = 0, how: str = "mean") -> pd.DataFrame:
        d = self.long[self.long["cls"] == cls]
        piv = d.pivot_table(index="method", columns="metric", values="value", aggfunc=how)
        return piv

    def table(self, group: str, cls: int = 0) -> pd.DataFrame:
        s = self.summary(cls)
        cols = [c for c in s.columns if c.startswith(group + ".")]
        return s[cols].rename(columns=lambda c: c.split(".", 1)[1])

    def by_length(self, metric: str, how: str = "mean") -> pd.DataFrame:
        d = self.long[(self.long["metric"] == metric) & (self.long["cls"] > 0)]
        return d.pivot_table(index="method", columns="cls", values="value", aggfunc=how)

    def ci(self, metric: str, cls: int = 0, level: float = 0.95, n_boot: int = 500, seed: int = 0) -> pd.DataFrame:
        """Bootstrap interval of the mean over repetitions."""
        d = self.long[(self.long["metric"] == metric) & (self.long["cls"] == cls)]
        rng = np.random.default_rng(seed)
        rows = []
        for m, g in d.groupby("method"):
            v = g["value"].dropna().to_numpy()
            if len(v) == 0:
                continue
            boots = [rng.choice(v, size=len(v)).mean() for _ in range(n_boot)] if len(v) > 1 else [v[0]]
            a = (1 - level) / 2
            rows.append({"method": m, "mean": v.mean(), "lo": np.quantile(boots, a), "hi": np.quantile(boots, 1 - a), "n": len(v)})
        return pd.DataFrame(rows).set_index("method")

    def losses(self, cls: int = 0) -> pd.DataFrame:
        return summary_losses(self.summary(cls))

    def group_ranks(self, cls: int = 0) -> pd.DataFrame:
        """Mean rank (1 = best) of each method within each metric group."""
        return summary_group_ranks(self.summary(cls))

    def ranking(self, preset: str | dict = "balanced", cls: int = 0) -> pd.DataFrame:
        return rank_summary(self.summary(cls), preset)

    def best(self, preset="balanced", n=3, cls: int = 0) -> list:
        return list(self.ranking(preset, cls).index[:n])

    def to_frame(self) -> pd.DataFrame:
        return self.long.copy()


def compare(series: pd.Series, others: pd.DataFrame | None = None, ctx: Ctx | None = None, config: CompareConfig | None = None, params: dict | None = None, progress=None) -> CompareResult:
    """Run the comparison. `params` = {method id: dict of parameters}. `progress(done, total, method_id)` is called after each task (serial runs)."""
    cfg = config or CompareConfig()
    ctx = ctx or Ctx()
    params = params or {}
    groups = list(cfg.groups) if cfg.groups else list(M.DEFAULT_GROUPS.get(ctx.variable, M.DEFAULT_GROUPS["generic"]))
    if not cfg.groups:
        if ctx.meta.get("driver") is not None:
            groups.append("extrapolation")
            if ctx.variable == "sediment":
                groups.append("load")
        if ctx.variable == "tide":
            groups += ["tidal", "constituents"]
    if ctx.variable != "rainfall":
        groups = [g for g in groups if g not in ("occurrence", "spells")]
    if ctx.variable not in ("streamflow", "generic", "stage", "groundwater", "sediment", "tide", "salinity", "temperature", "rainfall") and "signatures" in groups:
        groups.remove("signatures")
    avail = {}
    skipped = {}
    ids = cfg.methods if cfg.methods else list(REGISTRY.keys())
    for mid in ids:
        if mid in cfg.exclude or mid not in REGISTRY:
            continue
        problems = REGISTRY[mid].check(series, others, ctx)
        if problems:
            skipped[mid] = problems
        else:
            avail[mid] = REGISTRY[mid]
    lengths = real_gap_lengths(series)
    design = resolve_design(series, cfg.design)
    holdouts = []
    n_hidden = {}
    for rep in range(cfg.n_rep):
        rng = np.random.default_rng(cfg.seed + 1000 * rep)
        hidden, cls = make_holdout(series, rng, cfg.ladder, cfg.frac, design, lengths, cfg.margin, cfg.sample_frac)
        holdouts.append((hidden, cls))
        n_hidden[rep] = int(hidden.sum())
    tasks = [(mid, rep) for rep in range(cfg.n_rep) for mid in avail]
    results = []
    if cfg.n_jobs and cfg.n_jobs != 1:
        from joblib import Parallel, delayed

        results = Parallel(n_jobs=cfg.n_jobs)(
            delayed(_run_task)(mid, rep, series, others, ctx, holdouts[rep][0], holdouts[rep][1], groups, params.get(mid, {})) for mid, rep in tasks
        )
    else:
        for i, (mid, rep) in enumerate(tasks):
            results.append(_run_task(mid, rep, series, others, ctx, holdouts[rep][0], holdouts[rep][1], groups, params.get(mid, {})))
            if progress is not None:
                progress(i + 1, len(tasks), mid)
    rows, err_rows, time_rows = [], [], []
    for mid, rep, out in results:
        rows += out["rows"]
        if out["error"]:
            err_rows.append({"method": mid, "rep": rep, "error": out["error"]})
        time_rows.append({"method": mid, "rep": rep, "seconds": out["seconds"], "n_filled": out["n_filled"], "n_hidden": n_hidden[rep]})
    long = pd.DataFrame(rows, columns=["method", "rep", "cls", "metric", "value"])
    return CompareResult(long, pd.DataFrame(err_rows, columns=["method", "rep", "error"]), pd.DataFrame(time_rows), skipped, cfg, ctx.variable, n_hidden, design)
