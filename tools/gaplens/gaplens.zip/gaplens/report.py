"""Self-contained HTML report of one analysis: data, gap diagnosis, suggestions, comparison, filled series and the settings needed to repeat it."""

from __future__ import annotations

import html
import json
import platform
from datetime import datetime

import numpy as np
import pandas as pd

from . import __version__, service
from .gaps import NAMES as GAP_NAMES

CSS = """
:root{--bg:#eef2ef;--fg:#11303a;--mute:#566b72;--line:#c9d6d1;--acc:#1f5f94;--soft:#e3eae7;--display:Bahnschrift,"DIN Alternate","Avenir Next Condensed","Roboto Condensed","Arial Narrow",system-ui,sans-serif}
@media (prefers-color-scheme:dark){:root{--bg:#0f1a1d;--fg:#dce8e5;--mute:#8fa4a9;--line:#2a3c41;--acc:#74b3e8;--soft:#1a2a2f}}
body{font:15px/1.55 "Segoe UI Variable Text","Segoe UI",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif;font-variant-numeric:tabular-nums;background:var(--bg);color:var(--fg);max-width:960px;margin:0 auto;padding:28px 18px}
h1{font:600 2rem/1.1 var(--display);margin:.2em 0}h2{font:600 1.2rem/1.3 var(--display);margin:2em 0 .5em;border-bottom:1px solid var(--fg);padding-bottom:.25em}
table{border-collapse:collapse;width:100%;font-size:.86rem;margin:.6em 0}th,td{border-bottom:1px solid var(--line);padding:5px 9px;text-align:right}
th:first-child,td:first-child{text-align:left}th{color:var(--mute);font-size:.8rem;font-weight:600;border-bottom:1px solid var(--fg)}
.mute{color:var(--mute)}.warn{border-left:3px solid #94600a;background:var(--soft);padding:7px 12px;margin:.5em 0}
pre{background:var(--soft);padding:10px;overflow:auto;font-size:.8rem}svg{max-width:100%;height:auto}
.wrap{overflow-x:auto}
"""


def _table(df: pd.DataFrame, digits: int = 3, max_rows: int = 30) -> str:
    if df is None or len(df) == 0:
        return '<p class="mute">Nothing to show.</p>'
    d = df.head(max_rows).copy()
    return '<div class="wrap">' + d.to_html(classes="t", border=0, float_format=lambda v: f"{v:.{digits}g}" if np.isfinite(v) else "", na_rep="", escape=True) + "</div>"


def svg_series(observed: pd.Series, filled: pd.Series | None = None, w: int = 900, h: int = 240, unit: str = "") -> str:
    """Line chart: observed in blue, filled values in orange. Long series are drawn as min-max bins."""
    n = len(observed)
    stride = max(1, int(np.ceil(n / 900)))
    def bins(s):
        v = s.to_numpy(float)
        m = int(np.ceil(len(v) / stride)) * stride
        pad = np.concatenate([v, np.full(m - len(v), np.nan)]).reshape(-1, stride)
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return np.nanmin(pad, axis=1), np.nanmax(pad, axis=1)
    lo, hi = bins(observed)
    flo, fhi = bins(filled) if filled is not None else (None, None)
    allv = np.concatenate([x[np.isfinite(x)] for x in (lo, hi, flo, fhi) if x is not None] or [np.array([0.0, 1.0])])
    ymin, ymax = (float(allv.min()), float(allv.max())) if allv.size else (0.0, 1.0)
    if ymax - ymin < 1e-12:
        ymax = ymin + 1.0
    L, R, T, B = 52, 10, 10, 26
    x = lambda i: L + (w - L - R) * i / max(len(lo) - 1, 1)  # noqa: E731
    y = lambda v: T + (h - T - B) * (1 - (v - ymin) / (ymax - ymin))  # noqa: E731

    def path(a, b, color, width=1.0):
        segs, cur = [], []
        for i, (u, v) in enumerate(zip(a, b)):
            if np.isfinite(u) and np.isfinite(v):
                cur.append((x(i), y(u), y(v)))
            elif cur:
                segs.append(cur)
                cur = []
        if cur:
            segs.append(cur)
        out = []
        for s in segs:
            top = " ".join(f"{px:.1f},{py2:.1f}" for px, py1, py2 in s)
            bot = " ".join(f"{px:.1f},{py1:.1f}" for px, py1, py2 in reversed(s))
            out.append(f'<polygon points="{top} {bot}" fill="{color}" stroke="{color}" stroke-width="{width}" fill-opacity=".35"/>')
        return "".join(out)

    parts = [f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="time series">', f'<rect width="{w}" height="{h}" fill="none"/>']
    for k in range(5):
        v = ymin + (ymax - ymin) * k / 4
        parts.append(f'<line x1="{L}" x2="{w - R}" y1="{y(v):.1f}" y2="{y(v):.1f}" stroke="currentColor" stroke-opacity=".12"/><text x="{L - 6}" y="{y(v) + 4:.1f}" text-anchor="end" font-size="11" fill="currentColor" fill-opacity=".7">{v:.3g}</text>')
    t0, t1 = observed.index[0], observed.index[-1]
    for k in range(5):
        frac = k / 4
        tt = t0 + (t1 - t0) * frac
        parts.append(f'<text x="{L + (w - L - R) * frac:.1f}" y="{h - 8}" text-anchor="middle" font-size="11" fill="currentColor" fill-opacity=".7">{tt:%Y-%m-%d}</text>')
    parts.append(path(lo, hi, "#2a7fc0"))
    if flo is not None:
        parts.append(path(flo, fhi, "#e07b00", 1.4))
    parts.append(f'<text x="{L + 6}" y="{T + 12}" font-size="11" fill="#2a7fc0">observed</text><text x="{L + 70}" y="{T + 12}" font-size="11" fill="#e07b00">filled</text>')
    if unit:
        parts.append(f'<text x="4" y="{T + 12}" font-size="11" fill="currentColor" fill-opacity=".7">{html.escape(unit)}</text>')
    parts.append("</svg>")
    return "".join(parts)


def make_report(settings: dict, dataset: dict, res, fill_table: pd.DataFrame | None = None, title: str = "Gap-filling report") -> str:
    from .webapp import get_task

    ds, series, others, ctx = get_task(settings)
    prof = service.run_profile(ds["df"], ctx, others)
    sg = service.run_suggest(prof, series, others, ctx)
    tabs = service.comparison_tables(res, settings.get("preset", "balanced"))
    f = prof.findings.copy()
    if len(f):
        f["type"] = f["code"].map(GAP_NAMES)
        f = f[["code", "type", "scope", "strength", "evidence"]]
    out = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{html.escape(title)}</title><style>{CSS}</style></head><body>"]
    out.append(f"<h1>{html.escape(title)}</h1><p class='mute'>Target <b>{html.escape(ctx.target)}</b> ({ctx.variable}) · {html.escape(dataset['name'])} · {datetime.now():%Y-%m-%d %H:%M} · gaplens {__version__}</p>")
    miss = series.isna().mean()
    out.append(f"<p>{len(series)} steps from {series.index[0]:%Y-%m-%d} to {series.index[-1]:%Y-%m-%d} ({prof.freq}); <b>{100 * miss:.1f} %</b> missing. Gap types found: <b>{', '.join(prof.codes) or 'none'}</b>.</p>")
    out.append("<h2>1. Observed series</h2>" + svg_series(series, fill_table[f"{ctx.target}_filled"].where(fill_table["flag"] == "filled") if fill_table is not None else None))
    out.append("<h2>2. Gap diagnosis</h2>")
    out.append(_table(f) if len(f) else "<p>No gaps found.</p>")
    out.append(f"<p><b>Mechanism.</b> {html.escape(prof.verdict())}</p>")
    out.append("<p class='mute'>MCAR, MAR and MNAR are not decided from the data alone: MNAR can be suspected from the edge and neighbour tests but not proven.</p>")
    for w in sg.global_warnings:
        out.append(f"<div class='warn'>{html.escape(w)}</div>")
    out.append("<h2>3. Suggested methods (before testing)</h2>")
    t = sg.table.head(10)[["rank", "method", "name", "score"]].copy()
    t["why"] = [" · ".join(r) for r in sg.table.head(10)["reasons"]]
    out.append(_table(t, max_rows=10))
    out.append("<h2>4. Comparison on your data</h2>")
    out.append(f"<p>Hold-out design: <b>{res.design}</b>; {res.config.n_rep} repetitions; hidden values per repetition: {sorted(set(res.n_hidden.values()))[:3]}. Real gaps are never scored. Preset: {settings.get('preset', 'balanced')}.</p>")
    out.append("<h3>Ranking (mean rank in each metric group, 1 = best)</h3>" + _table(tabs["ranking"].round(2)))
    out.append("<h3>Selected metrics (mean of repetitions)</h3>" + _table(tabs["summary"].round(3)))
    if len(tabs["by_length"]):
        out.append("<h3>RMSE by gap length (steps)</h3>" + _table(tabs["by_length"]))
    if len(tabs["rmse_ci"]):
        out.append("<h3>RMSE with 95 % bootstrap interval</h3>" + _table(tabs["rmse_ci"]))
    if len(tabs["errors"]):
        out.append("<h3>Methods that failed</h3>" + _table(tabs["errors"]))
    if fill_table is not None:
        c = fill_table.loc[fill_table["flag"] == "filled", "method"].value_counts()
        out.append("<h2>5. Filled series</h2><p>" + ", ".join(f"{html.escape(str(k))}: {v} steps" for k, v in c.items()) + f"; still missing: {int((fill_table['flag'] == 'missing').sum())}.</p>")
    out.append("<h2>Repeat this analysis</h2><pre>" + html.escape(json.dumps({k: v for k, v in settings.items()}, indent=2, default=str)) + "</pre>")
    out.append(f"<p class='mute'>Python {platform.python_version()}, pandas {pd.__version__}, numpy {np.__version__}. Fills are estimates: keep the flag column and report the uncertainty of any quantity computed from them.</p></body></html>")
    return "".join(out)
