"""Glue between a user's tables and the library: read a file, build the task, then diagnose, suggest, compare and fill.

    df, info = read_table("my_data.csv")
    series, others, ctx = build_task(df, target="Q", variable="streamflow", precip="P")
    prof = run_profile(df, ctx, others)            # diagnosis of the gaps
    sg = run_suggest(prof, series, others, ctx)
    res = run_compare(series, others, ctx, methods=sg.top(8))
    out = run_fill(series, others, ctx, methods=res.best(n=3))
The web app and the command-line scripts both use these functions.
"""

from __future__ import annotations

import io
import warnings

import numpy as np
import pandas as pd

from . import calval as CV
from .compare import CompareConfig, compare
from .methods import REGISTRY, Ctx
from .profile import profile as _profile
from .suggest import suggest as _suggest

VARIABLES = ("rainfall", "temperature", "streamflow", "stage", "groundwater", "tide", "sediment", "salinity", "generic")

# Word stems that may appear inside a longer column name ("Rainfall_mm" -> rain). Checked in this order.
KEYWORDS = {
    "rainfall": ("rain", "precip", "prcp", "imerg", "chirps", "trmm", "persiann", "gsmap", "mswep"),
    "temperature": ("temp", "tmax", "tmin", "tmean", "tair", "airt"),
    "tide": ("tide", "tidal", "sea_level", "sealevel"),
    "groundwater": ("groundwater", "piezo", "water_table", "watertable", "borehole"),
    "streamflow": ("flow", "discharge", "runoff", "streamflow", "cumec"),
    "stage": ("stage", "level", "gauge_height", "waterlevel", "height"),
    "sediment": ("sediment", "suspended", "turbid", "concentration"),
    "salinity": ("salin", "conductiv"),
}
# Short codes that only count as a whole part of the name: "Q01", "P_Q02", "WL_up", "H 3", "16_1 (mPWD)".
# The first part decides ("P_Q02" is rainfall for gauge Q02), otherwise any part.
TOKENS = {
    "rainfall": ("p", "r", "pr", "ppt", "rr", "rf", "mm"),
    "temperature": ("t", "ta", "tx", "tn"),
    "streamflow": ("q", "qobs", "qsim", "m3s", "cms", "cumecs"),
    "stage": ("wl", "h", "mpwd", "mmsl", "pwd", "msl", "masl"),
    "tide": ("ssh",),
    "groundwater": ("gw", "gwl", "gwt", "head", "well"),
    "sediment": ("ssc", "tss", "ssl", "load", "mgl"),
    "salinity": ("ec", "psu", "sal", "tds"),
}
DATE_NAMES = ("date", "datetime", "time", "timestamp", "day", "dt", "date_time")


def _name_tokens(name: str) -> list:
    """'P_Q02' -> ['p', 'q', '02'];  'Discharge (m3/s)' -> ['discharge', 'm3s'];  'WL_Upstream_m' -> ['wl', 'upstream', 'm']."""
    import re
    n = name.lower().replace("m3/s", "m3s").replace("m³/s", "m3s").replace("m^3/s", "m3s")
    out = []
    for part in re.split(r"[^a-z0-9]+", n):
        out += re.findall(r"[a-z]+\d*s?|\d+", part)
    return out


def _guess_from_name(name: str) -> str:
    n = name.lower().replace(" ", "_")
    for var, keys in KEYWORDS.items():
        if any(k in n for k in keys):
            return var
    toks = _name_tokens(name)
    alpha = [t.rstrip("0123456789") for t in toks if t[:1].isalpha()]
    for pos in ([alpha[0]] if alpha else []), alpha:  # the first part decides; then any part
        for var, keys in TOKENS.items():
            if any(t in keys for t in pos):
                return var
    return "generic"


def _guess_from_values(values) -> str:
    """Only clear cases, for a non-negative series:
    many exact zeros, or skewed and not persistent from step to step -> rainfall;
    skewed and persistent (lag-1 autocorrelation of log values above 0.8, as rivers are) -> streamflow."""
    s = pd.to_numeric(pd.Series(values), errors="coerce") if values is not None else pd.Series(dtype=float)
    v = s.dropna().to_numpy(float)
    if len(v) < 30 or not np.isfinite(v).all() or v.min() < 0:
        return "generic"
    if float(np.mean(v == 0)) >= 0.3:
        return "rainfall"
    pos = v[v > 0]
    if len(pos) < 30:
        return "generic"
    med, p99, sd = float(np.median(pos)), float(np.quantile(pos, 0.99)), float(pos.std())
    skew = float(np.mean(((pos - pos.mean()) / sd) ** 3)) if sd > 0 else 0.0
    if not (skew > 1.5 and med > 0 and p99 / med > 5):
        return "generic"
    lg = np.log(s.where(s > 0))  # keeps the time order; gaps stay NaN
    r1 = lg.autocorr(lag=1) if lg.notna().sum() > 30 else np.nan
    if np.isfinite(r1) and r1 > 0.8:
        return "streamflow"
    if np.isfinite(r1) and r1 < 0.5:
        return "rainfall"
    return "generic"


def guess_variable(name: str, values=None) -> str:
    """Kind of variable from the column name; when the name gives no clue, from the values (clear cases only)."""
    g = _guess_from_name(str(name))
    return g if g != "generic" else _guess_from_values(values)


# ------------------------------------------------------------------------------------------------ reading


def read_table(source, date_col: str | None = None, dayfirst: bool | None = None) -> tuple[pd.DataFrame, dict]:
    """Read a CSV (path, bytes or text) with one date column. Returns (numeric table on a regular time index, info)."""
    if isinstance(source, bytes):
        text = source.decode("utf-8-sig", errors="replace")
    elif isinstance(source, str) and "\n" in source:
        text = source
    else:
        with open(source, "rb") as fh:
            text = fh.read().decode("utf-8-sig", errors="replace")
    raw = pd.read_csv(io.StringIO(text), sep=None, engine="python", skip_blank_lines=True)
    raw.columns = [str(c).strip() for c in raw.columns]
    info = {"warnings": []}
    cols = list(raw.columns)
    lower = {c.lower(): c for c in cols}
    dc = date_col if date_col in cols else next((lower[n] for n in DATE_NAMES if n in lower), None)
    if dc is None and {"year", "month", "day"} <= set(lower):
        raw["date"] = pd.to_datetime(dict(year=raw[lower["year"]], month=raw[lower["month"]], day=raw[lower["day"]]), errors="coerce")
        dc = "date"
        raw = raw.drop(columns=[lower["year"], lower["month"], lower["day"]])
    if dc is None:
        dc = cols[0]
        info["warnings"].append(f"No column called date or time was found; the first column ({dc}) was used.")
    ok_frac = 0.0
    parsed = None
    for df_ in ([dayfirst] if dayfirst is not None else [False, True]):
        p = pd.to_datetime(raw[dc], errors="coerce", dayfirst=df_)
        frac = float(p.notna().mean())
        if frac > ok_frac + 1e-9:
            ok_frac, parsed, used_dayfirst = frac, p, df_
    if parsed is None or ok_frac < 0.8:
        raise ValueError(f"Column {dc!r} could not be read as dates ({100 * ok_frac:.0f} % parsed).")
    if ok_frac < 1.0:
        info["warnings"].append(f"{int((~parsed.notna()).sum())} rows with unreadable dates were dropped.")
    df = raw.drop(columns=[dc]).apply(pd.to_numeric, errors="coerce")
    df.index = pd.DatetimeIndex(parsed)
    df = df[df.index.notna()]
    df = df.loc[:, df.notna().any()]
    dup = int(df.index.duplicated().sum())
    if dup:
        info["warnings"].append(f"{dup} duplicated timestamps; the first row of each was kept.")
    df = df[~df.index.duplicated(keep="first")].sort_index()
    step = pd.Series(df.index).diff().median()
    if pd.isna(step) or step <= pd.Timedelta(0):
        raise ValueError("The table needs at least two different timestamps.")
    full = pd.date_range(df.index[0], df.index[-1], freq=step)
    if len(full) != len(df):
        info["warnings"].append(f"Missing timestamps were added so the record is regular at {step} ({len(full) - len(df)} rows).")
    df = df.reindex(full)
    df.index.name = "date"
    info.update(date_col=dc, step=str(step), n=len(df), start=str(df.index[0]), end=str(df.index[-1]), dayfirst=bool(used_dayfirst),
                columns=[{"name": c, "missing_frac": float(df[c].isna().mean()), "guess": guess_variable(c, df[c]), "min": _f(df[c].min()), "max": _f(df[c].max())} for c in df.columns])
    return df, info


def _f(v):
    return None if v is None or not np.isfinite(v) else float(v)


# ------------------------------------------------------------------------------------------------ building the task


def build_task(df: pd.DataFrame, target: str, variable: str = "auto", driver: str | None = None, surrogate: str | None = None, precip: str | None = None, pet: str | None = None,
               product=(), latitude: float | None = None, exclude=(), stations: pd.DataFrame | None = None, gaugings: pd.DataFrame | None = None, areas: dict | None = None, seed: int = 0):
    """Return (series, others, ctx). Columns named as roles (driver, surrogate, precip, pet, product) are taken out of the donor set where they are not donors."""
    if target not in df.columns:
        raise ValueError(f"column {target!r} is not in the table")
    var = guess_variable(target, df[target]) if variable in (None, "", "auto") else variable
    if var not in VARIABLES:
        raise ValueError(f"unknown variable {var!r}")
    series = df[target].astype(float)
    ctx = Ctx(variable=var, target=target, seed=seed)
    skip = set(exclude) | {target}
    roles = {c for c in (driver, surrogate, precip, pet) if c}
    ctx.meta["covariates"] = sorted(c for c in roles if c in df.columns)  # not stations: kept out of substitution / averaging methods
    prod = [c for c in product if c in df.columns and c != target]
    if precip and precip in df.columns:
        ctx.meta["precip"] = df[precip].astype(float)
    if pet and pet in df.columns:
        ctx.meta["pet"] = df[pet].astype(float)
    if var in ("sediment", "tide", "groundwater"):
        keep = [c for c in (driver, surrogate) if c and c in df.columns]
        others = df[keep].astype(float) if keep else None
        if var == "groundwater" and driver is None and precip:
            others = df[[precip]].astype(float)
            driver = precip
        if driver:
            ctx.meta["driver"] = driver
        if surrogate:
            ctx.meta["surrogate"] = surrogate
        if var == "tide":
            ctx.meta["latitude"] = latitude if latitude is not None else 0.0
        if var == "groundwater" and precip:
            ctx.meta.setdefault("precip", df[precip].astype(float))
    else:
        donors = [c for c in df.columns if c not in skip and c not in roles - set(prod)]
        if driver and driver in df.columns:
            donors = sorted(set(donors) | {driver})
        others = df[donors].astype(float) if donors else None
        if driver:
            ctx.meta["driver"] = driver
        if prod:
            ctx.meta["product"] = prod
    if latitude is not None:
        ctx.meta["latitude"] = latitude
    if stations is not None:
        st = stations.copy()
        if "station" in st.columns:
            st = st.set_index("station")
        ctx.coords = st
        # catchment areas may come with the station table (column area_km2): the drainage-area ratio method needs them
        acol = next((c for c in st.columns if str(c).lower() in ("area_km2", "area", "catchment_area_km2", "drainage_area_km2")), None)
        if acol is not None and not areas:
            a = pd.to_numeric(st[acol], errors="coerce").dropna()
            areas = {str(k): float(v) for k, v in a.items() if v > 0}
    if areas:
        ctx.meta["areas_km2"] = areas
    if gaugings is not None:
        ctx.meta["gaugings"] = gaugings
    return series, others, ctx


# ------------------------------------------------------------------------------------------------ steps


def run_profile(df: pd.DataFrame, ctx: Ctx, others: pd.DataFrame | None = None):
    """Diagnose the gaps of the target and of its donor columns. Covariates (driver, surrogate, rainfall forcing) are left out:
    rainfall zeros would read as clipping."""
    roles = {ctx.meta.get("driver"), ctx.meta.get("surrogate")}
    donors = [c for c in (others.columns if others is not None else []) if c not in roles]
    sub = df[[ctx.target] + [c for c in donors if c in df.columns]]
    var = ctx.variable if ctx.variable in ("rainfall", "temperature", "streamflow") else "generic"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return _profile(sub, variable=var)


def run_suggest(prof, series, others, ctx, include_slow: bool = True):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return _suggest(prof, series, others, ctx, target=ctx.target, include_slow=include_slow)


def run_compare(series, others, ctx, methods=None, n_rep: int = 4, ladder=None, frac: float = 0.10, design: str = "auto", seed: int = 0, progress=None, exclude_cost=("high",)):
    """Masked-hold-out comparison on the user's own data. By default the slow (cost 'high') methods are left out unless named in `methods`."""
    ids = list(methods) if methods else [m for m, v in REGISTRY.items() if v.info.cost not in exclude_cost]
    steps = ladder or _default_ladder(series)
    cfg = CompareConfig(ladder=steps, frac=frac, n_rep=n_rep, design=design, methods=tuple(ids), seed=seed)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return compare(series, others, ctx, cfg, progress=progress)


def _default_ladder(series: pd.Series) -> tuple:
    from .methods.base import steps_per_day

    spd = steps_per_day(series.index)
    base = (1, 3, 7, 30, 90)
    if spd >= 12:
        base = tuple(int(round(spd * d)) for d in (0.25, 1, 3, 10, 30))
    elif spd < 0.5:
        base = (1, 2, 4, 8, 12)
    n_obs = int(series.notna().sum())
    return tuple(L for L in base if L * 8 < n_obs) or (1,)


def run_fill(series, others, ctx, methods, params=None, intervals: bool = True) -> pd.DataFrame:
    """Fill with a cascade: the first method fills what it can, the next fills the rest. Returns value, flag, method, lo, hi."""
    params = params or {}
    value = series.copy()
    used = pd.Series("", index=series.index, dtype=object)
    lo = pd.Series(np.nan, index=series.index)
    hi = pd.Series(np.nan, index=series.index)
    notes = []
    for mid in methods:
        miss = value.isna()
        if not miss.any():
            break
        if mid not in REGISTRY:
            notes.append(f"{mid}: unknown method")
            continue
        problems = REGISTRY[mid].check(series, others, ctx)
        if problems:
            notes.append(f"{mid}: skipped ({'; '.join(problems)})")
            continue
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                fo = REGISTRY[mid].run(value, others, ctx, **params.get(mid, {}))
        except Exception as e:  # noqa: BLE001
            notes.append(f"{mid}: failed ({type(e).__name__}: {str(e)[:120]})")
            continue
        got = miss & fo.values.notna()
        value[got] = fo.values[got]
        used[got] = mid
        if intervals and fo.lo is not None:
            lo[got], hi[got] = fo.lo[got], fo.hi[got]
    flag = np.where(series.notna(), "observed", np.where(value.notna(), "filled", "missing"))
    out = pd.DataFrame({"value": value, "flag": flag, "method": used, "lo": lo, "hi": hi})
    out.attrs["notes"] = notes
    return out


def comparison_tables(res, preset: str = "balanced") -> dict:
    """The tables a report or the web app shows for a CompareResult."""
    rank = res.ranking(preset)
    summ = res.summary()
    keep = [c for c in ("pointwise.rmse", "pointwise.mae", "pointwise.bias", "efficiency.nse", "efficiency.kge", "correlation.pearson", "volume.total_err_pct", "distribution.ks") if c in summ.columns]
    by_len = res.by_length("pointwise.rmse") if "pointwise.rmse" in summ.columns else pd.DataFrame()
    ci = res.ci("pointwise.rmse") if "pointwise.rmse" in summ.columns else pd.DataFrame()
    timing = res.timing.groupby("method")["seconds"].mean() if len(res.timing) else pd.Series(dtype=float)
    return dict(ranking=rank, summary=summ[keep], by_length=by_len, rmse_ci=ci, timing=timing, errors=res.errors, skipped=res.skipped)


# ------------------------------------------------------------------------------------------------ calibration and validation


CORRECTION_TOLERANCE = 0.02  # KGE units; a gain smaller than this does not justify a more flexible correction (experiment 7, part F)


def run_calval(obs: pd.Series, sim: pd.Series, variable: str = "generic", how: str = "mean", apply_lag: bool = False, scheme: str = "blocked_kfold", thresholds: str = "moriasi2015", n_boot: int = 150):
    """Two series: align, validate, and test which correction helps under cross-validation."""
    al = CV.align(obs, sim, how=how, apply_lag=apply_lag)
    rep = CV.validate(al.obs, al.sim, variable=variable, thresholds=thresholds, n_boot=n_boot)
    try:
        corr = CV.compare_corrections(al.obs, al.sim, scheme=scheme, tolerance=CORRECTION_TOLERANCE)
    except Exception as e:  # noqa: BLE001
        corr = pd.DataFrame({"note": [f"corrections not tested: {e}"]})
    return al, rep, corr
