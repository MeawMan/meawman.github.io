"""Metric groups for scoring a filled series against the hidden truth (catalog section 13.2).

Entry point:  score(truth, filled, hidden, groups=None, variable="generic", ctx=None) -> dict

    truth   Series, the true values (NaN where the truth itself is unknown; those steps are never scored)
    filled  Series, the series after filling (observed values kept, hidden values filled)
    hidden  boolean Series, True where a value was hidden and then filled
    groups  names from GROUPS; default depends on the variable

Names of the returned metrics are "<group>.<metric>". DIRECTION says how to read each one:
    "min"   smaller is better            "max"   larger is better
    "zero"  closest to 0 is best (signed errors)   "one"  closest to 1 is best (ratios)

Groups that judge the filled values themselves use only the hidden steps ("hidden" scope):
pointwise, efficiency, correlation, distribution, extremes, occurrence, volume, probabilistic.
Groups that judge the whole record after filling use the "full" scope:
temporal, trend, signatures, spells.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

EPS = 1e-12

# --------------------------------------------------------------------------- basic helpers


def _pairs(obs, sim):
    o = np.asarray(obs, dtype=float)
    s = np.asarray(sim, dtype=float)
    ok = np.isfinite(o) & np.isfinite(s)
    return o[ok], s[ok]


def rmse(o, s):
    return float(np.sqrt(np.mean((s - o) ** 2))) if len(o) else np.nan


def mae(o, s):
    return float(np.mean(np.abs(s - o))) if len(o) else np.nan


def bias(o, s):
    return float(np.mean(s - o)) if len(o) else np.nan


def pbias(o, s):
    d = np.sum(o)
    return float(100.0 * np.sum(s - o) / d) if len(o) and abs(d) > EPS else np.nan


def nse(o, s):
    den = np.sum((o - o.mean()) ** 2) if len(o) else 0.0
    return float(1.0 - np.sum((s - o) ** 2) / den) if len(o) > 1 and den > EPS else np.nan


def _corr(o, s):
    if len(o) < 3 or np.std(o) < EPS or np.std(s) < EPS:
        return np.nan
    return float(np.corrcoef(o, s)[0, 1])


def kge_parts(o, s, modified=False):
    """Return (kge, r, alpha_or_gamma, beta) following Gupta et al. 2009 or Kling et al. 2012 (modified)."""
    if len(o) < 3 or np.std(o) < EPS or abs(np.mean(o)) < EPS:
        return np.nan, np.nan, np.nan, np.nan
    r = _corr(o, s)
    beta = np.mean(s) / np.mean(o)
    if modified:
        a = (np.std(s) / np.mean(s)) / (np.std(o) / np.mean(o)) if abs(np.mean(s)) > EPS else np.nan
    else:
        a = np.std(s) / np.std(o)
    if not np.isfinite(r) or not np.isfinite(a):
        return np.nan, r, a, beta
    return float(1.0 - np.sqrt((r - 1) ** 2 + (a - 1) ** 2 + (beta - 1) ** 2)), float(r), float(a), float(beta)


def npkge(o, s):
    """Non-parametric KGE (Pool et al. 2018): Spearman r, flow-duration-curve alpha, bias beta."""
    if len(o) < 5 or abs(np.mean(o)) < EPS:
        return np.nan
    r = stats.spearmanr(o, s)[0]
    fo = np.sort(o) / (len(o) * np.mean(o))
    fs = np.sort(s) / (len(s) * max(np.mean(s), EPS))
    alpha = 1.0 - 0.5 * np.sum(np.abs(fs - fo))
    beta = np.mean(s) / np.mean(o)
    if not np.isfinite(r):
        return np.nan
    return float(1.0 - np.sqrt((r - 1) ** 2 + (alpha - 1) ** 2 + (beta - 1) ** 2))


def willmott_d(o, s):
    if len(o) < 2:
        return np.nan
    om = o.mean()
    den = np.sum((np.abs(s - om) + np.abs(o - om)) ** 2)
    return float(1.0 - np.sum((s - o) ** 2) / den) if den > EPS else np.nan


def log_nse(o, s, eps=None):
    if len(o) < 3 or np.any(o < 0) or np.any(s < 0):
        return np.nan
    e = eps if eps is not None else 0.01 * np.mean(o)
    return nse(np.log(o + e), np.log(s + e))


def sen_slope(y):
    """Sen slope of an evenly spaced series (units per step)."""
    y = np.asarray(y, float)
    y = y[np.isfinite(y)]
    if len(y) < 4:
        return np.nan
    i, j = np.triu_indices(len(y), 1)
    return float(np.median((y[j] - y[i]) / (j - i)))


def acf(x, nlags):
    x = np.asarray(x, float)
    x = x - np.nanmean(x)
    x = np.where(np.isfinite(x), x, 0.0)
    den = np.sum(x * x)
    if den < EPS:
        return np.full(nlags, np.nan)
    return np.array([np.sum(x[k:] * x[:-k]) / den for k in range(1, nlags + 1)])


def spell_lengths(wet: np.ndarray):
    """Mean wet and dry spell length of a boolean wet series."""
    wet = np.asarray(wet, bool)
    if wet.size == 0:
        return np.nan, np.nan
    change = np.flatnonzero(np.diff(wet.astype(int)) != 0) + 1
    edges = np.r_[0, change, wet.size]
    lens = np.diff(edges)
    vals = wet[edges[:-1]]
    w = lens[vals]
    d = lens[~vals]
    return (float(w.mean()) if len(w) else np.nan), (float(d.mean()) if len(d) else np.nan)


def lyne_hollick_bfi(q, alpha=0.925, passes=3):
    """Baseflow index from the Lyne-Hollick filter (forward-backward-forward)."""
    q = np.asarray(q, float)
    q = q[np.isfinite(q)]
    if len(q) < 30 or q.sum() <= 0:
        return np.nan
    qf = np.zeros_like(q)
    base = q.copy()
    cur = q.copy()
    for p in range(passes):
        src = cur if p % 2 == 0 else cur[::-1]
        quick = np.zeros_like(src)
        for t in range(1, len(src)):
            quick[t] = alpha * quick[t - 1] + 0.5 * (1 + alpha) * (src[t] - src[t - 1])
            if quick[t] < 0:
                quick[t] = 0.0
            if quick[t] > src[t]:
                quick[t] = src[t]
        b = src - quick
        cur = b if p % 2 == 0 else b[::-1]
    return float(np.clip(cur.sum() / q.sum(), 0, 1))


def richards_baker(q):
    q = np.asarray(q, float)
    q = q[np.isfinite(q)]
    return float(np.sum(np.abs(np.diff(q))) / np.sum(q)) if len(q) > 2 and q.sum() > 0 else np.nan


# --------------------------------------------------------------------------- groups (hidden scope)


def g_pointwise(o, s, ctx):
    rng_ = (np.max(o) - np.min(o)) if len(o) else np.nan
    return {
        "rmse": rmse(o, s),
        "mae": mae(o, s),
        "bias": bias(o, s),
        "pbias": pbias(o, s),
        "nrmse": rmse(o, s) / rng_ if len(o) and rng_ > EPS else np.nan,
        "max_error": float(np.max(np.abs(s - o))) if len(o) else np.nan,
    }


def g_efficiency(o, s, ctx):
    k09, r, a, b = kge_parts(o, s, modified=False)
    k12, _, g, _ = kge_parts(o, s, modified=True)
    return {
        "nse": nse(o, s),
        "kge": k09,
        "kge_r": r,
        "kge_alpha": a,
        "kge_beta": b,
        "kge2012": k12,
        "kge2012_gamma": g,
        "npkge": npkge(o, s),
        "d": willmott_d(o, s),
        "log_nse": log_nse(o, s),
    }


def g_correlation(o, s, ctx):
    if len(o) < 4 or np.std(o) < EPS or np.std(s) < EPS:
        return {"pearson": np.nan, "spearman": np.nan, "kendall": np.nan}
    return {
        "pearson": float(np.corrcoef(o, s)[0, 1]),
        "spearman": float(stats.spearmanr(o, s)[0]),
        "kendall": float(stats.kendalltau(o, s)[0]),
    }


def g_distribution(o, s, ctx):
    out = {}
    if len(o) < 5:
        return out
    out["ks"] = float(stats.ks_2samp(o, s).statistic)
    scale = max(float(np.std(o)), EPS)
    for q in (0.05, 0.25, 0.5, 0.75, 0.95, 0.99):
        out[f"q{int(q * 100):02d}_err"] = float((np.quantile(s, q) - np.quantile(o, q)) / scale)
    so, ss = np.sort(o)[::-1], np.sort(s)[::-1]
    n = len(so)
    hi, lo = slice(0, max(1, int(0.02 * n))), slice(int(0.7 * n), n)
    mid = slice(int(0.2 * n), int(0.7 * n))
    out["fhv"] = float(100 * (ss[hi].sum() - so[hi].sum()) / so[hi].sum()) if so[hi].sum() > EPS else np.nan
    out["fmv"] = float(100 * (ss[mid].sum() - so[mid].sum()) / so[mid].sum()) if so[mid].sum() > EPS else np.nan
    out["flv"] = float(100 * (ss[lo].sum() - so[lo].sum()) / so[lo].sum()) if so[lo].sum() > EPS else np.nan
    out["var_ratio"] = float(np.var(s) / np.var(o)) if np.var(o) > EPS else np.nan
    if np.std(o) > EPS and np.std(s) > EPS and n > 8:
        out["skew_diff"] = float(stats.skew(s) - stats.skew(o))
    return out


def g_extremes(o, s, ctx, hidden_blocks=None):
    out = {}
    if len(o) < 5:
        return out
    scale = max(abs(float(np.max(o))), EPS)
    out["peak_err"] = float((np.max(s) - np.max(o)) / scale)
    out["min_err"] = float((np.min(s) - np.min(o)) / max(abs(float(np.mean(o))), EPS))
    if hidden_blocks:
        pe, te = [], []
        for bo, bs in hidden_blocks:
            if len(bo) >= 2 and np.max(bo) > EPS:
                pe.append((np.max(bs) - np.max(bo)) / np.max(bo))
                te.append(int(np.argmax(bs)) - int(np.argmax(bo)))
        if pe:
            out["block_peak_err"] = float(np.mean(pe))
            out["block_peak_abs_err"] = float(np.mean(np.abs(pe)))
            out["block_peak_timing"] = float(np.mean(np.abs(te)))
    thr = ctx.get("high_threshold")
    if thr is not None:
        out["exceed_count_err"] = float(np.sum(s > thr) - np.sum(o > thr))
    return out


def g_volume(o, s, ctx):
    if len(o) == 0 or abs(np.sum(o)) < EPS:
        return {}
    return {"total_err_pct": float(100 * (np.sum(s) - np.sum(o)) / abs(np.sum(o)))}


def g_occurrence(o, s, ctx):
    thr = ctx.get("wet_threshold", 0.1)
    if len(o) < 5:
        return {}
    wo, ws = o >= thr, s >= thr
    hits = float(np.sum(wo & ws))
    miss = float(np.sum(wo & ~ws))
    fa = float(np.sum(~wo & ws))
    cn = float(np.sum(~wo & ~ws))
    out = {"wetfreq_err": float(ws.mean() - wo.mean())}
    out["pod"] = hits / (hits + miss) if hits + miss > 0 else np.nan
    out["far"] = fa / (hits + fa) if hits + fa > 0 else np.nan
    out["csi"] = hits / (hits + miss + fa) if hits + miss + fa > 0 else np.nan
    den = (hits + miss) * (miss + cn) + (hits + fa) * (fa + cn)
    out["hss"] = 2 * (hits * cn - miss * fa) / den if den > 0 else np.nan
    wet_mean_o = float(o[wo].mean()) if wo.any() else np.nan
    wet_mean_s = float(s[ws].mean()) if ws.any() else np.nan
    out["wet_amount_err"] = float((wet_mean_s - wet_mean_o) / wet_mean_o) if wo.any() and ws.any() and wet_mean_o > EPS else np.nan
    return out


def g_probabilistic(o, s, ctx, lo=None, hi=None):
    if lo is None or hi is None:
        return {}
    ok = np.isfinite(lo) & np.isfinite(hi)
    if ok.sum() < 5:
        return {}
    inside = (o[ok] >= lo[ok]) & (o[ok] <= hi[ok])
    return {"coverage": float(inside.mean()), "width": float(np.mean(hi[ok] - lo[ok]))}


# --------------------------------------------------------------------------- paired-driver groups (rating, sediment, any covariate model)


def g_extrapolation(o, s, ctx):
    """Error inside and outside the range of the driver (stage, discharge ...) for which the method had calibration data."""
    d, rng_ = ctx.get("driver_h"), ctx.get("driver_range")
    if d is None or rng_ is None or len(d) != len(o) or len(o) == 0:
        return {}
    lo, hi = rng_
    out_ = (d > hi) | (d < lo)
    res = {"outside_share": float(out_.mean())}
    for name, m in (("outside", out_), ("inside", ~out_)):
        if m.sum() >= 3:
            res[f"{name}_rmse"] = rmse(o[m], s[m])
            res[f"{name}_pbias"] = pbias(o[m], s[m])
    return res


def g_load(o, s, ctx):
    """Sediment or solute load from concentration (mg/L) and discharge (m3/s): t/day = C Q 0.0864."""
    d = ctx.get("driver_h")
    if d is None or len(d) != len(o) or len(o) == 0:
        return {}
    k = 0.0864 * ctx.get("step_days", 1.0)
    lo_, ls_ = o * d * k, s * d * k
    tot = float(lo_.sum())
    if abs(tot) < EPS:
        return {}
    return {"total_load_err_pct": float(100.0 * (ls_.sum() - tot) / abs(tot)), "load_rmse_t": rmse(lo_, ls_)}


MAIN_TIDE_SPEEDS = {"M2": 28.9841042, "S2": 30.0, "N2": 28.4397295, "K1": 15.0410686, "O1": 13.9430356}


def g_tidal(o, s, ctx, hidden_blocks=None):
    """High and low water height and timing, and daily tidal range, on hidden blocks that span at least one tidal cycle."""
    from scipy.signal import find_peaks

    if not hidden_blocks:
        return {}
    spd = ctx.get("steps_per_day", 24.0)
    sph = spd / 24.0
    cyc = 12.42 * sph
    w = max(int(round(0.25 * cyc)), 1)
    hw_h, lw_h, hw_t, lw_t, rng_e = [], [], [], [], []
    for bo, bs in hidden_blocks:
        if len(bo) < cyc * 1.1:
            continue
        span = max(float(np.ptp(bo)), 1e-6)
        for sign, hs, ts in ((1.0, hw_h, hw_t), (-1.0, lw_h, lw_t)):
            pk, _ = find_peaks(sign * bo, distance=max(int(0.5 * cyc), 1), prominence=0.05 * span)
            for i in pk:
                a, b = max(i - w, 0), min(i + w + 1, len(bs))
                seg = sign * bs[a:b]
                j = int(np.argmax(seg))
                hs.append(sign * seg[j] - bo[i])
                ts.append((a + j - i) / sph)
        day = max(int(round(24.84 * sph)), 2)
        for k in range(0, len(bo) - day + 1, day):
            rng_e.append(float(np.ptp(bs[k : k + day]) - np.ptp(bo[k : k + day])))
    out = {}
    if hw_h:
        out["hw_height_mae"], out["hw_height_bias"] = float(np.mean(np.abs(hw_h))), float(np.mean(hw_h))
        out["hw_timing_mae_h"] = float(np.mean(np.abs(hw_t)))
    if lw_h:
        out["lw_height_mae"], out["lw_height_bias"] = float(np.mean(np.abs(lw_h))), float(np.mean(lw_h))
        out["lw_timing_mae_h"] = float(np.mean(np.abs(lw_t)))
    if rng_e:
        out["range_mae"], out["range_bias"] = float(np.mean(np.abs(rng_e))), float(np.mean(rng_e))
    return out


def _harmonic_fit(y, t_hours, speeds):
    ok = np.isfinite(y)
    w = np.radians(np.asarray(speeds, float))
    arg = np.outer(t_hours, w)
    X = np.hstack([np.ones((len(y), 1)), np.cos(arg), np.sin(arg)])
    beta, *_ = np.linalg.lstsq(X[ok], y[ok], rcond=None)
    k = len(speeds)
    c, sn = beta[1 : 1 + k], beta[1 + k :]
    return np.hypot(c, sn), np.degrees(np.arctan2(sn, c))


def g_constituents(t, f, ctx):
    """Amplitude and phase of the main constituents fitted to the whole record, before (truth) and after filling."""
    spd = ctx.get("steps_per_day", 24.0)
    n = len(t)
    if n < 15 * spd:
        return {}
    th = np.arange(n) / spd * 24.0
    names = list(MAIN_TIDE_SPEEDS)
    sp = [MAIN_TIDE_SPEEDS[k] for k in names]
    a_t, p_t = _harmonic_fit(t, th, sp)
    a_f, p_f = _harmonic_fit(f, th, sp)
    out = {}
    for i, k in enumerate(names):
        out[f"{k}_amp_err"] = float(a_f[i] - a_t[i])
        out[f"{k}_phase_err_deg"] = float((p_f[i] - p_t[i] + 180.0) % 360.0 - 180.0)
    return out


# --------------------------------------------------------------------------- groups (full scope)


def g_temporal(t, f, ctx):
    ok = np.isfinite(t) & np.isfinite(f)
    if ok.sum() < 30:
        return {}
    tt, ff = t.copy(), f.copy()
    tt[~ok] = np.nan
    ff[~ok] = np.nan
    out = {"var_ratio_full": float(np.nanvar(ff) / np.nanvar(tt)) if np.nanvar(tt) > EPS else np.nan}
    lags = (1, 2, 3, 7)
    a_t, a_f = acf(tt, max(lags)), acf(ff, max(lags))
    for k in lags:
        out[f"acf{k}_err"] = float(a_f[k - 1] - a_t[k - 1])
    return out


def g_trend(t_series: pd.Series, f_series: pd.Series, ctx):
    ok = t_series.notna() & f_series.notna()
    ann_t = t_series.where(ok).groupby(t_series.index.year).mean()
    ann_f = f_series.where(ok).groupby(f_series.index.year).mean()
    if len(ann_t) < 6:
        return {}
    st, sf = sen_slope(ann_t.to_numpy()), sen_slope(ann_f.to_numpy())
    out = {"sen_slope_diff": float(sf - st)}
    tau_t = stats.kendalltau(np.arange(len(ann_t)), ann_t)[0]
    tau_f = stats.kendalltau(np.arange(len(ann_f)), ann_f)[0]
    out["mk_tau_diff"] = float(tau_f - tau_t)
    out["annual_var_ratio"] = float(ann_f.var() / ann_t.var()) if ann_t.var() > EPS else np.nan
    return out


def g_signatures(t, f, ctx):
    ok = np.isfinite(t) & np.isfinite(f)
    if ok.sum() < 100:
        return {}
    tt, ff = t[ok], f[ok]
    out = {}
    bt, bf = lyne_hollick_bfi(tt), lyne_hollick_bfi(ff)
    out["bfi_diff"] = float(bf - bt) if np.isfinite(bt) and np.isfinite(bf) else np.nan
    rt, rf = richards_baker(tt), richards_baker(ff)
    out["flashiness_diff"] = float((rf - rt) / rt) if np.isfinite(rt) and rt > EPS and np.isfinite(rf) else np.nan
    if (tt > 0).all() and (ff > 0).all():
        st = np.log(np.quantile(tt, 0.33)) - np.log(np.quantile(tt, 0.66))
        sf = np.log(np.quantile(ff, 0.33)) - np.log(np.quantile(ff, 0.66))
        out["fdc_slope_diff"] = float(sf - st)
    return out


def g_spells(t, f, ctx):
    thr = ctx.get("wet_threshold", 0.1)
    ok = np.isfinite(t) & np.isfinite(f)
    if ok.sum() < 100:
        return {}
    wt, wf = spell_lengths(t[ok] >= thr), spell_lengths(f[ok] >= thr)
    return {
        "wet_spell_err": float(wf[0] - wt[0]) if np.isfinite(wt[0]) and np.isfinite(wf[0]) else np.nan,
        "dry_spell_err": float(wf[1] - wt[1]) if np.isfinite(wt[1]) and np.isfinite(wf[1]) else np.nan,
        "wetfreq_full_err": float(np.mean(f[ok] >= thr) - np.mean(t[ok] >= thr)),
    }


GROUPS = {
    "pointwise": ("hidden", g_pointwise),
    "efficiency": ("hidden", g_efficiency),
    "correlation": ("hidden", g_correlation),
    "distribution": ("hidden", g_distribution),
    "extremes": ("hidden", g_extremes),
    "volume": ("hidden", g_volume),
    "occurrence": ("hidden", g_occurrence),
    "probabilistic": ("hidden", g_probabilistic),
    "temporal": ("full", g_temporal),
    "trend": ("full", g_trend),
    "signatures": ("full", g_signatures),
    "spells": ("full", g_spells),
    "extrapolation": ("hidden", g_extrapolation),
    "load": ("hidden", g_load),
    "tidal": ("hidden", g_tidal),
    "constituents": ("full", g_constituents),
}

DEFAULT_GROUPS = {
    "rainfall": ["pointwise", "efficiency", "correlation", "distribution", "extremes", "volume", "occurrence", "spells", "temporal", "trend"],
    "streamflow": ["pointwise", "efficiency", "correlation", "distribution", "extremes", "volume", "temporal", "trend", "signatures"],
    "generic": ["pointwise", "efficiency", "correlation", "distribution", "extremes", "volume", "temporal", "trend"],
}
for _v in ("temperature", "stage", "groundwater", "tide", "sediment", "salinity"):
    DEFAULT_GROUPS[_v] = DEFAULT_GROUPS["generic"]

# Metric direction for ranking (see direction_of). Anything not listed is reported but not ranked.
_MIN = ["rmse", "mae", "nrmse", "max_error", "ks", "far", "block_peak_abs_err", "block_peak_timing",
        "outside_rmse", "inside_rmse", "load_rmse_t", "hw_height_mae", "lw_height_mae", "hw_timing_mae_h", "lw_timing_mae_h", "range_mae"]
_ZERO = [
    "bias", "pbias", "q05_err", "q25_err", "q50_err", "q75_err", "q95_err", "q99_err", "fhv", "fmv", "flv", "skew_diff",
    "peak_err", "min_err", "block_peak_err", "exceed_count_err", "total_err_pct", "wetfreq_err", "wet_amount_err",
    "sen_slope_diff", "mk_tau_diff", "bfi_diff", "flashiness_diff", "fdc_slope_diff", "wet_spell_err", "dry_spell_err",
    "wetfreq_full_err", "acf1_err", "acf2_err", "acf3_err", "acf7_err",
    "outside_pbias", "inside_pbias", "total_load_err_pct", "hw_height_bias", "lw_height_bias", "range_bias",
    "M2_amp_err", "S2_amp_err", "N2_amp_err", "K1_amp_err", "O1_amp_err",
    "M2_phase_err_deg", "S2_phase_err_deg", "N2_phase_err_deg", "K1_phase_err_deg", "O1_phase_err_deg",
]
_MAX = ["nse", "kge", "kge_r", "kge2012", "npkge", "d", "log_nse", "pearson", "spearman", "kendall", "pod", "csi", "hss", "coverage"]
_ONE = ["kge_alpha", "kge_beta", "kge2012_gamma", "var_ratio", "var_ratio_full", "annual_var_ratio"]

def direction_of(metric: str) -> str | None:
    name = metric.split(".", 1)[-1]
    if name in _MIN:
        return "min"
    if name in _ZERO:
        return "zero"
    if name in _MAX:
        return "max"
    if name in _ONE:
        return "one"
    return None


def loss_of(metric: str, value: float) -> float:
    """Convert a metric to a loss (lower is better) according to its direction."""
    d = direction_of(metric)
    if d is None or not np.isfinite(value):
        return np.nan
    if d == "min":
        return float(value)
    if d == "zero":
        return abs(float(value))
    if d == "one":
        return abs(float(value) - 1.0)
    return float(-value)


# --------------------------------------------------------------------------- score


def _hidden_blocks(truth: pd.Series, filled: pd.Series, hidden: pd.Series):
    blocks = []
    h = hidden.to_numpy(bool)
    if not h.any():
        return blocks
    padded = np.concatenate([[False], h, [False]])
    change = np.flatnonzero(padded[1:] != padded[:-1])
    for s, e in zip(change[0::2], change[1::2]):
        bo = truth.to_numpy(float)[s:e]
        bs = filled.to_numpy(float)[s:e]
        ok = np.isfinite(bo) & np.isfinite(bs)
        if ok.sum() >= 2:
            blocks.append((bo[ok], bs[ok]))
    return blocks


def score(truth: pd.Series, filled: pd.Series, hidden: pd.Series, groups=None, variable="generic", ctx=None, lo=None, hi=None) -> dict:
    """Score `filled` against `truth` on the `hidden` steps (and, for full-scope groups, on the whole record)."""
    ctx = dict(ctx or {})
    ctx.setdefault("wet_threshold", 0.1)
    groups = list(groups) if groups is not None else list(DEFAULT_GROUPS.get(variable, DEFAULT_GROUPS["generic"]))
    t_arr, f_arr = truth.to_numpy(float), filled.to_numpy(float)
    h = hidden.to_numpy(bool)
    o, s = _pairs(t_arr[h], f_arr[h])
    ok_h = np.isfinite(t_arr[h]) & np.isfinite(f_arr[h])
    if ctx.get("driver_full") is not None:
        ctx["driver_h"] = np.asarray(ctx["driver_full"], float)[h][ok_h]
    if "high_threshold" not in ctx and np.isfinite(t_arr).sum() > 20:
        ctx["high_threshold"] = float(np.nanquantile(t_arr, 0.95))
    out = {}
    for g in groups:
        scope, fn = GROUPS[g]
        if g in ("extremes", "tidal"):
            res = fn(o, s, ctx, hidden_blocks=_hidden_blocks(truth, filled, hidden))
        elif g == "probabilistic":
            lo_a = None if lo is None else np.asarray(lo, float)[h]
            hi_a = None if hi is None else np.asarray(hi, float)[h]
            ok = np.isfinite(t_arr[h]) & np.isfinite(f_arr[h])
            res = fn(t_arr[h][ok], s, ctx, lo=None if lo_a is None else lo_a[ok], hi=None if hi_a is None else hi_a[ok])
        elif scope == "hidden":
            res = fn(o, s, ctx)
        elif g == "trend":
            res = fn(truth, filled, ctx)
        else:
            res = fn(t_arr, f_arr, ctx)
        for k, v in res.items():
            out[f"{g}.{k}"] = float(v) if v is not None and np.isfinite(v) else np.nan
    out["n_hidden"] = float(len(o))
    return out


# --------------------------------------------------------------------------- presets (catalog 13.3)

PRESETS = {
    "balanced": {"pointwise": 1, "efficiency": 1, "correlation": 0.5, "distribution": 1, "extremes": 1, "volume": 1, "occurrence": 1, "spells": 0.5, "temporal": 0.5, "trend": 0.5, "signatures": 0.5,
                 "extrapolation": 0.5, "load": 1, "tidal": 1, "constituents": 0.5},
    "flood_frequency": {"extremes": 3, "distribution": 2, "efficiency": 1, "pointwise": 0.5},
    "water_balance": {"volume": 3, "pointwise": 2, "efficiency": 1, "distribution": 0.5},
    "drought": {"occurrence": 2, "spells": 2, "extremes": 2, "distribution": 2, "volume": 1},
    "climate_trend": {"trend": 3, "temporal": 2, "distribution": 1, "pointwise": 1},
    "model_calibration": {"efficiency": 3, "signatures": 2, "distribution": 1, "volume": 1, "temporal": 1},
    "sediment_load": {"load": 3, "volume": 2, "pointwise": 1, "distribution": 1, "efficiency": 1, "extrapolation": 1},
    "tidal": {"tidal": 3, "constituents": 2, "pointwise": 2, "extremes": 1, "temporal": 1, "efficiency": 1},
    "rating_use": {"extrapolation": 2, "pointwise": 2, "volume": 2, "efficiency": 1, "distribution": 1, "extremes": 1},
}
