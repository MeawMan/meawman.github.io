"""GapResult: what a user receives after gaps and data faults were applied to a truth table."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


def find_runs(flags: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Start positions and lengths of consecutive True runs in a 1-D boolean array."""
    flags = np.asarray(flags, dtype=bool)
    if flags.size == 0:
        return np.array([], dtype=int), np.array([], dtype=int)
    padded = np.concatenate([[False], flags, [False]])
    change = np.flatnonzero(padded[1:] != padded[:-1])
    starts = change[0::2]
    ends = change[1::2]
    return starts, ends - starts


@dataclass
class GapResult:
    """Truth, observed values, and one boolean layer per gap code.

    truth:     the complete series (known only in synthetic or masked tests)
    observed:  what the user would see: NaN for missing values, wrong values
               for faults such as clipping, sentinel codes or accumulated totals
    layers:    {code: bool DataFrame}; True marks cells affected by that gap type
    meta:      parameters used, per code
    """

    truth: pd.DataFrame
    observed: pd.DataFrame
    layers: dict = field(default_factory=dict)
    meta: dict = field(default_factory=dict)

    @property
    def mask(self) -> pd.DataFrame:
        """True where the value is missing or not trustworthy (any layer)."""
        out = pd.DataFrame(False, index=self.truth.index, columns=self.truth.columns)
        for layer in self.layers.values():
            out = out | layer
        return out

    @property
    def missing(self) -> pd.DataFrame:
        """True where the observed value is NaN."""
        return self.observed.isna()

    def missing_fraction(self) -> pd.Series:
        return self.missing.mean()

    def kind(self) -> pd.DataFrame:
        """Per-cell string of the gap codes that hit the cell, joined with '+' ('' = clean)."""
        arr = np.full(self.truth.shape, "", dtype=object)
        for code in sorted(self.layers, key=lambda c: int(c[1:])):
            m = self.layers[code].reindex(index=self.truth.index, columns=self.truth.columns).to_numpy(bool)
            arr = np.where(m, np.where(arr == "", code, arr + "+" + code), arr)
        return pd.DataFrame(arr, index=self.truth.index, columns=self.truth.columns)

    def runs(self, column=None, flawed: bool = False) -> pd.DataFrame:
        """Table of NaN runs (or, with flawed=True, runs of any affected cells)."""
        rows = []
        flags = self.mask if flawed else self.missing
        cols = [column] if column is not None else list(self.truth.columns)
        kinds = self.kind()
        for col in cols:
            starts, lengths = find_runs(flags[col].to_numpy())
            for s, ln in zip(starts, lengths):
                codes = sorted({c for v in kinds[col].iloc[s : s + ln] for c in str(v).split("+") if c}, key=lambda c: int(c[1:]))
                rows.append(
                    {
                        "column": col,
                        "start": self.truth.index[s],
                        "end": self.truth.index[s + ln - 1],
                        "length": int(ln),
                        "codes": "+".join(codes),
                    }
                )
        return pd.DataFrame(rows, columns=["column", "start", "end", "length", "codes"])


def new_result(truth: pd.DataFrame) -> GapResult:
    return GapResult(truth=truth.copy(), observed=truth.copy(), layers={}, meta={})


def add_layer(res: GapResult, code: str, mask: pd.DataFrame, values: pd.DataFrame | None = None, **meta) -> GapResult:
    """Add a gap layer. If `values` is None the masked cells become NaN, else they take `values`."""
    mask = mask.reindex(index=res.truth.index, columns=res.truth.columns).fillna(False).astype(bool)
    if values is None:
        res.observed = res.observed.mask(mask)
    else:
        res.observed = res.observed.mask(mask, values)
    prev = res.layers.get(code)
    res.layers[code] = mask if prev is None else (prev | mask)
    res.meta.setdefault(code, {}).update(meta)
    return res


def combine(truth: pd.DataFrame, *results: GapResult) -> GapResult:
    """Merge several results made from the same truth into one."""
    out = new_result(truth)
    nan_any = pd.DataFrame(False, index=truth.index, columns=truth.columns)
    for res in results:
        for code, layer in res.layers.items():
            prev = out.layers.get(code)
            out.layers[code] = layer if prev is None else (prev | layer)
        out.meta.update(res.meta)
        changed = res.mask & res.observed.notna()
        out.observed = out.observed.mask(changed, res.observed)
        nan_any = nan_any | (res.observed.isna() & truth.notna())
    out.observed = out.observed.mask(nan_any)
    return out
