"""Gap simulation: G1-G15 mechanisms applied to a complete truth table."""

from .mechanisms import (
    MECHANISMS,
    NAMES,
    POST,
    PRIMARY,
    accumulated_totals,
    clip_flatline,
    describe,
    extreme_linked,
    irregular_sampling,
    isolated_station,
    leading_trailing,
    long_blocks,
    monotone_dropout,
    network_outage,
    qc_removal,
    random_points,
    seasonal_windows,
    sentinel_coded,
    short_runs,
    simulate,
    thin_overlap,
)
from .cases import CASES, build_cases, write_cases
from .result import GapResult, add_layer, combine, find_runs, new_result

__all__ = [
    "CASES", "build_cases", "write_cases",
    "GapResult", "add_layer", "combine", "find_runs", "new_result",
    "MECHANISMS", "NAMES", "POST", "PRIMARY", "describe", "simulate",
    "random_points", "short_runs", "long_blocks", "seasonal_windows", "leading_trailing",
    "monotone_dropout", "network_outage", "isolated_station", "thin_overlap", "extreme_linked",
    "clip_flatline", "sentinel_coded", "accumulated_totals", "qc_removal", "irregular_sampling",
]
