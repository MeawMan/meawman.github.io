"""Gap and fault generators G1-G15 (see the scope and method catalog, section 1).

Every function takes a complete `truth` DataFrame (DatetimeIndex, one column per
station or variable) and returns a `GapResult`. Functions marked "post" take a
`GapResult` and work on the gaps already there (G12 and G13).

Code  Name
G1    isolated points (MCAR)
G2    short runs
G3    long blocks
G4    seasonal windows (same season missing in several years)
G5    leading and trailing gaps
G6    monotone dropout (stations stop one after another)
G7    network outage (many stations, same dates)
G8    isolated station (only the least-connected station has gaps)
G9    thin overlap (target and reference share only a short period)
G10   extreme-linked missingness (MNAR suspects: peaks fail, floods missing)
G11   clipped and flat-lined values (wrong values, not NaN)
G12   sentinel-coded gaps (-999, 0) hiding as numbers (post)
G13   accumulated totals after a gap (post)
G14   QC removal of values outside bounds
G15   irregular sparse sampling (weekly, monthly, storm-biased)
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .result import GapResult, add_layer, combine, find_runs, new_result

NAMES = {
    "G1": "isolated points",
    "G2": "short runs",
    "G3": "long blocks",
    "G4": "seasonal windows",
    "G5": "leading and trailing gaps",
    "G6": "monotone dropout",
    "G7": "network outage",
    "G8": "isolated station",
    "G9": "thin overlap",
    "G10": "extreme-linked missingness",
    "G11": "clipped and flat-lined values",
    "G12": "sentinel-coded gaps",
    "G13": "accumulated totals",
    "G14": "QC removal",
    "G15": "irregular sparse sampling",
}


# ----------------------------------------------------------------------------- helpers


def _rng(seed):
    return np.random.default_rng(seed)


def _cols(truth: pd.DataFrame, columns) -> list:
    if columns is None:
        return list(truth.columns)
    if isinstance(columns, (str, int)) and columns in truth.columns:
        return [columns]
    return list(columns)


def _blank(truth: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame(False, index=truth.index, columns=truth.columns)


def _rows_per_day(index: pd.DatetimeIndex) -> float:
    if len(index) < 2:
        return 1.0
    step = pd.Series(index).diff().median()
    return float(pd.Timedelta(days=1) / step)


def _place_runs(rng, n: int, target: int, mean_len: float, max_len: int | None = None, min_len: int = 1) -> np.ndarray:
    """Boolean flags with runs of geometric length until `target` cells are flagged."""
    flags = np.zeros(n, dtype=bool)
    if target <= 0 or n == 0:
        return flags
    p = 1.0 / max(mean_len, 1.0)
    tries = 0
    while flags.sum() < target and tries < 50 * max(target, 10):
        tries += 1
        ln = int(rng.geometric(p))
        ln = max(min_len, ln)
        if max_len is not None:
            ln = min(ln, max_len)
        ln = min(ln, n)
        start = int(rng.integers(0, n - ln + 1))
        flags[start : start + ln] = True
    return flags


def _dilate(flags: np.ndarray, k: int) -> np.ndarray:
    if k <= 0:
        return flags
    return np.convolve(flags.astype(int), np.ones(2 * k + 1, dtype=int), mode="same") > 0


def _expit(x):
    return 1.0 / (1.0 + np.exp(-x))


def _place_blocks(rng, n: int, lengths, margin: int = 1, tries: int = 400):
    """Non-overlapping random blocks; returns flags and list of (start, length)."""
    flags = np.zeros(n, dtype=bool)
    placed = []
    for ln in lengths:
        ln = int(min(ln, n))
        for _ in range(tries):
            s = int(rng.integers(0, n - ln + 1))
            lo, hi = max(0, s - margin), min(n, s + ln + margin)
            if not flags[lo:hi].any():
                flags[s : s + ln] = True
                placed.append((s, ln))
                break
    return flags, placed


# ----------------------------------------------------------------------------- G1 - G11, G14, G15


def random_points(truth, frac=0.05, seed=0, columns=None) -> GapResult:
    """G1: each value is lost independently with probability `frac`."""
    rng = _rng(seed)
    mask = _blank(truth)
    for c in _cols(truth, columns):
        mask[c] = rng.random(len(truth)) < frac
    return add_layer(new_result(truth), "G1", mask, frac=frac, seed=seed)


def short_runs(truth, frac=0.05, mean_len=3.0, max_len=10, seed=0, columns=None) -> GapResult:
    """G2: runs of a few steps (geometric length, mean `mean_len`, capped at `max_len`)."""
    rng = _rng(seed)
    mask = _blank(truth)
    n = len(truth)
    for c in _cols(truth, columns):
        mask[c] = _place_runs(rng, n, int(round(frac * n)), mean_len, max_len)
    return add_layer(new_result(truth), "G2", mask, frac=frac, mean_len=mean_len, max_len=max_len, seed=seed)


def long_blocks(truth, lengths=(60, 120), seed=0, columns=None, shared=False) -> GapResult:
    """G3: a few long blocks per series; `lengths` in time steps. shared=True puts them at the same dates."""
    rng = _rng(seed)
    mask = _blank(truth)
    n = len(truth)
    cols = _cols(truth, columns)
    blocks = {}
    if shared:
        flags, placed = _place_blocks(rng, n, lengths)
        for c in cols:
            mask[c] = flags
            blocks[c] = placed
    else:
        for c in cols:
            flags, placed = _place_blocks(rng, n, lengths)
            mask[c] = flags
            blocks[c] = placed
    return add_layer(new_result(truth), "G3", mask, lengths=list(lengths), shared=shared, blocks=blocks, seed=seed)


def seasonal_windows(truth, start_doy=152, width_days=90, frac_years=1.0, seed=0, columns=None) -> GapResult:
    """G4: the same calendar window is missing in many years (for example every wet season)."""
    rng = _rng(seed)
    doy = truth.index.dayofyear.to_numpy()
    end = start_doy + width_days - 1
    if end <= 366:
        inwin = (doy >= start_doy) & (doy <= end)
    else:
        inwin = (doy >= start_doy) | (doy <= end - 366)
    years = np.unique(truth.index.year)
    if frac_years < 1.0:
        k = max(1, int(round(frac_years * len(years))))
        chosen = rng.choice(years, size=k, replace=False)
    else:
        chosen = years
    yr_ok = np.isin(truth.index.year.to_numpy(), chosen)
    flags = inwin & yr_ok
    mask = _blank(truth)
    for c in _cols(truth, columns):
        mask[c] = flags
    return add_layer(
        new_result(truth), "G4", mask, start_doy=start_doy, width_days=width_days, years=[int(y) for y in chosen], seed=seed
    )


def leading_trailing(truth, lead_frac=0.1, trail_frac=0.1, columns=None, seed=0) -> GapResult:
    """G5: the series starts late and/or ends early. Fractions may be dicts {column: fraction}."""
    n = len(truth)
    mask = _blank(truth)
    for c in _cols(truth, columns):
        lf = lead_frac[c] if isinstance(lead_frac, dict) else lead_frac
        tf = trail_frac[c] if isinstance(trail_frac, dict) else trail_frac
        flags = np.zeros(n, dtype=bool)
        flags[: int(round(lf * n))] = True
        if tf > 0:
            flags[n - int(round(tf * n)) :] = True
        mask[c] = flags
    return add_layer(new_result(truth), "G5", mask, lead_frac=lead_frac, trail_frac=trail_frac)


def monotone_dropout(truth, n_drop=None, start_fracs=None, seed=0) -> GapResult:
    """G6: stations stop reporting one after another and never return (nested pattern).

    start_fracs: {column: fraction of the record after which the column stops}.
    Default: half of the columns (at least one column always survives) with random stop points.
    """
    rng = _rng(seed)
    cols = list(truth.columns)
    k = len(cols)
    n = len(truth)
    if start_fracs is None:
        if n_drop is None:
            n_drop = max(1, k // 2)
        n_drop = min(n_drop, k - 1) if k > 1 else 1
        chosen = rng.choice(k, size=n_drop, replace=False)
        fr = np.sort(rng.uniform(0.35, 0.9, size=n_drop))
        start_fracs = {cols[int(i)]: float(f) for i, f in zip(chosen, fr)}
    mask = _blank(truth)
    for c, f in start_fracs.items():
        flags = np.zeros(n, dtype=bool)
        flags[int(round(f * n)) :] = True
        mask[c] = flags
    return add_layer(new_result(truth), "G6", mask, start_fracs=dict(start_fracs), seed=seed)


def network_outage(truth, length=30, n_events=3, share_hit=0.8, min_cols=2, seed=0) -> GapResult:
    """G7: the same dates are missing in most stations (power, telemetry, flood damage)."""
    rng = _rng(seed)
    n = len(truth)
    cols = list(truth.columns)
    k = len(cols)
    flags, placed = _place_blocks(rng, n, [length] * n_events, margin=length // 2)
    mask = _blank(truth)
    events = []
    for s, ln in placed:
        hit = rng.random(k) < share_hit
        need = min(min_cols, k)
        if hit.sum() < need:
            hit[rng.choice(k, size=need, replace=False)] = True
        hit_cols = [cols[i] for i in np.flatnonzero(hit)]
        mask.iloc[s : s + ln, [i for i in np.flatnonzero(hit)]] = True
        events.append({"start": truth.index[s], "end": truth.index[s + ln - 1], "columns": hit_cols})
    return add_layer(new_result(truth), "G7", mask, length=length, n_events=n_events, share_hit=share_hit, events=events, seed=seed)


def isolated_station(truth, station=None, frac=0.2, mean_len=45.0, seed=0) -> GapResult:
    """G8: one station, the least correlated with the rest, has gaps; all others are complete."""
    rng = _rng(seed)
    cols = list(truth.columns)
    n = len(truth)
    if station is None:
        if len(cols) == 1:
            station = cols[0]
        else:
            corr = truth.corr(numeric_only=True).to_numpy().copy()
            np.fill_diagonal(corr, np.nan)
            station = cols[int(np.nanargmin(np.nanmean(corr, axis=0)))]
    mask = _blank(truth)
    mask[station] = _place_runs(rng, n, int(round(frac * n)), mean_len)
    return add_layer(new_result(truth), "G8", mask, station=station, frac=frac, mean_len=mean_len, seed=seed)


def thin_overlap(truth, target=None, reference=None, tail_frac=0.4, overlap_len=30, seed=0) -> GapResult:
    """G9: the target stops at (1 - tail_frac) of the record; the reference starts only `overlap_len` steps before.

    The relation between the two series must then be learned from a very short common period.
    """
    cols = list(truth.columns)
    if len(cols) < 2:
        raise ValueError("thin_overlap needs at least two columns")
    n = len(truth)
    target = cols[0] if target is None else target
    if reference is None:
        corr = truth.corr(numeric_only=True)[target].drop(target)
        reference = corr.idxmax()
    t_end = int(round(n * (1 - tail_frac)))
    ref_start = max(t_end - int(overlap_len), 0)
    mask = _blank(truth)
    flags_t = np.zeros(n, dtype=bool)
    flags_t[t_end:] = True
    mask[target] = flags_t
    flags_r = np.zeros(n, dtype=bool)
    flags_r[:ref_start] = True
    mask[reference] = flags_r
    return add_layer(
        new_result(truth),
        "G9",
        mask,
        target=target,
        reference=reference,
        overlap_len=int(overlap_len),
        overlap_start=truth.index[ref_start],
        overlap_end=truth.index[max(t_end - 1, 0)],
        tail_frac=tail_frac,
        seed=seed,
    )


def extreme_linked(truth, frac=0.05, strength=4.0, tail="upper", dilate=1, seed=0, columns=None) -> GapResult:
    """G10: probability of loss depends on the value itself (MNAR suspect).

    tail: "upper" (peaks fail, floods missing), "lower" (low readings dropped) or "both".
    The logistic intercept is solved so that the final fraction (after `dilate` neighbours
    on each side are also lost) is close to `frac`.
    """
    rng = _rng(seed)
    n = len(truth)
    mask = _blank(truth)
    for c in _cols(truth, columns):
        x = truth[c].to_numpy(float)
        r = pd.Series(x).rank(pct=True).to_numpy()
        r = np.where(np.isfinite(r), r, 0.5)
        if tail == "upper":
            s = r - 0.5
        elif tail == "lower":
            s = 0.5 - r
        elif tail == "both":
            s = 2.0 * np.abs(r - 0.5) - 0.5
        else:
            raise ValueError("tail must be 'upper', 'lower' or 'both'")
        score = strength * 2.0 * s
        u = rng.random(n)

        def final(a):
            return _dilate(u < _expit(a + score), dilate).mean()

        lo, hi = -40.0, 40.0
        for _ in range(50):
            mid = 0.5 * (lo + hi)
            if final(mid) < frac:
                lo = mid
            else:
                hi = mid
        mask[c] = _dilate(u < _expit(0.5 * (lo + hi) + score), dilate)
    return add_layer(new_result(truth), "G10", mask, frac=frac, strength=strength, tail=tail, dilate=dilate, seed=seed)


def clip_flatline(truth, ceil_q=0.98, floor_q=None, stuck_runs=0, stuck_len=12, seed=0, columns=None) -> GapResult:
    """G11: values above/below a sensor limit are recorded at the limit; a stuck sensor repeats one value.

    The affected cells keep numbers (they are wrong, not NaN). Only cells whose value really changed
    are flagged.
    """
    rng = _rng(seed)
    n = len(truth)
    mask = _blank(truth)
    vals = truth.copy()
    limits = {}
    for c in _cols(truth, columns):
        x = truth[c].to_numpy(float)
        v = x.copy()
        if ceil_q is not None:
            hi = float(np.nanquantile(x, ceil_q))
            v = np.where(v > hi, hi, v)
        else:
            hi = None
        if floor_q is not None:
            lo = float(np.nanquantile(x, floor_q))
            v = np.where(v < lo, lo, v)
        else:
            lo = None
        for _ in range(int(stuck_runs)):
            s = int(rng.integers(1, max(2, n - stuck_len)))
            v[s : s + stuck_len] = v[s - 1]
        changed = ~np.isclose(v, x, equal_nan=True)
        mask[c] = changed
        vals[c] = v
        limits[c] = {"ceiling": hi, "floor": lo}
    return add_layer(
        new_result(truth), "G11", mask, values=vals, ceil_q=ceil_q, floor_q=floor_q, stuck_runs=stuck_runs, stuck_len=stuck_len, limits=limits, seed=seed
    )


def qc_removal(truth, upper_q=0.995, lower_q=None, upper_abs=None, lower_abs=None, dilate=0, columns=None, seed=0) -> GapResult:
    """G14: values beyond QC bounds are deleted (bounds by quantile or absolute value)."""
    mask = _blank(truth)
    bounds = {}
    for c in _cols(truth, columns):
        x = truth[c].to_numpy(float)
        flags = np.zeros(len(x), dtype=bool)
        hi = upper_abs if upper_abs is not None else (float(np.nanquantile(x, upper_q)) if upper_q is not None else None)
        lo = lower_abs if lower_abs is not None else (float(np.nanquantile(x, lower_q)) if lower_q is not None else None)
        with np.errstate(invalid="ignore"):
            if hi is not None:
                flags |= x > hi
            if lo is not None:
                flags |= x < lo
        mask[c] = _dilate(flags, dilate)
        bounds[c] = {"upper": hi, "lower": lo}
    return add_layer(new_result(truth), "G14", mask, bounds=bounds, dilate=dilate)


def irregular_sampling(truth, schedule="monthly", n_per_year=12, step_days=7, driver=None, strength=2.0, seed=0, columns=None) -> GapResult:
    """G15: only a sparse set of times is observed.

    schedule: "weekly" (every `step_days` days), "monthly" (one random day per month),
              "random" (`n_per_year` random times per year),
              "storm_biased" (`n_per_year` times per year, favouring high values of `driver`).
    """
    rng = _rng(seed)
    n = len(truth)
    rpd = _rows_per_day(truth.index)
    years = truth.index.year.to_numpy()
    months = truth.index.month.to_numpy()
    mask = _blank(truth)
    counts = {}
    for c in _cols(truth, columns):
        keep = np.zeros(n, dtype=bool)
        if schedule == "weekly":
            step_rows = max(1, int(round(step_days * rpd)))
            off = int(rng.integers(step_rows))
            keep[off::step_rows] = True
        elif schedule == "monthly":
            for y in np.unique(years):
                for m in range(1, 13):
                    idx = np.flatnonzero((years == y) & (months == m))
                    if idx.size:
                        keep[int(rng.choice(idx))] = True
        elif schedule in ("random", "storm_biased"):
            if schedule == "storm_biased":
                d = truth[c] if driver is None else pd.Series(np.asarray(driver, float), index=truth.index)
                r = d.rank(pct=True).fillna(0.5).to_numpy()
                w = np.exp(strength * 2.0 * (r - 0.5))
            else:
                w = np.ones(n)
            for y in np.unique(years):
                idx = np.flatnonzero(years == y)
                k = min(int(n_per_year), idx.size)
                p = w[idx] / w[idx].sum()
                keep[rng.choice(idx, size=k, replace=False, p=p)] = True
        else:
            raise ValueError("schedule must be weekly, monthly, random or storm_biased")
        mask[c] = ~keep
        counts[c] = int(keep.sum())
    return add_layer(new_result(truth), "G15", mask, schedule=schedule, n_per_year=n_per_year, step_days=step_days, strength=strength, counts=counts, seed=seed)


# ----------------------------------------------------------------------------- post-processors


def accumulated_totals(res: GapResult, share=0.7, min_len=1, seed=0, columns=None) -> GapResult:
    """G13 (post): after a gap, the first reading holds the total of the missing steps plus its own.

    The gap itself stays NaN. The reading after the gap is flagged, since it is not a daily value.
    """
    rng = _rng(seed)
    truth = res.truth
    miss = res.missing
    vals = res.observed.copy()
    mask = _blank(truth)
    events = []
    n = len(truth)
    for c in _cols(truth, columns):
        starts, lengths = find_runs(miss[c].to_numpy())
        for s, ln in zip(starts, lengths):
            e = s + ln
            if e >= n or ln < min_len or rng.random() >= share:
                continue
            t_seg = truth[c].iloc[s : e + 1]
            if t_seg.isna().any():
                continue
            total = float(t_seg.sum())
            vals.iloc[e, vals.columns.get_loc(c)] = total
            mask.iloc[e, mask.columns.get_loc(c)] = True
            events.append({"column": c, "gap_start": truth.index[s], "gap_end": truth.index[e - 1], "reading": truth.index[e], "total": total})
    return add_layer(res, "G13", mask, values=vals, share=share, min_len=min_len, events=events, seed=seed)


def sentinel_coded(res: GapResult, codes=(-999.0,), share=0.5, zero_share=0.0, seed=0, columns=None) -> GapResult:
    """G12 (post): a share of the NaN cells is written as a sentinel number (-999) or as 0."""
    rng = _rng(seed)
    truth = res.truth
    nan_cells = (res.missing & truth.notna()).to_numpy()
    cols_sel = _cols(truth, columns)
    col_ok = np.array([c in cols_sel for c in truth.columns])[None, :]
    pick = nan_cells & col_ok & (rng.random(nan_cells.shape) < share)
    pick_zero = nan_cells & col_ok & ~pick & (rng.random(nan_cells.shape) < zero_share)
    codes = np.asarray(codes, float)
    code_vals = codes[rng.integers(0, len(codes), size=nan_cells.shape)]
    arr = np.where(pick, code_vals, np.where(pick_zero, 0.0, np.nan))
    vals = pd.DataFrame(arr, index=truth.index, columns=truth.columns)
    mask = pd.DataFrame(pick | pick_zero, index=truth.index, columns=truth.columns)
    return add_layer(res, "G12", mask, values=vals, codes=list(map(float, codes)), share=share, zero_share=zero_share, seed=seed)


# ----------------------------------------------------------------------------- registry and driver

PRIMARY = {
    "G1": random_points,
    "G2": short_runs,
    "G3": long_blocks,
    "G4": seasonal_windows,
    "G5": leading_trailing,
    "G6": monotone_dropout,
    "G7": network_outage,
    "G8": isolated_station,
    "G9": thin_overlap,
    "G10": extreme_linked,
    "G11": clip_flatline,
    "G14": qc_removal,
    "G15": irregular_sampling,
}
POST = {"G13": accumulated_totals, "G12": sentinel_coded}  # order matters: totals first, then sentinels
MECHANISMS = {**PRIMARY, **POST}


def simulate(truth: pd.DataFrame, spec, seed: int = 0) -> GapResult:
    """Apply several mechanisms to one truth table.

    spec: list of (code, params) tuples or {"code": "G3", ...params} dicts, for example
        [("G2", {"frac": 0.03}), ("G3", {"lengths": [90]}), ("G13", {"share": 0.8})]
    Primary mechanisms (G1-G11, G14, G15) are all applied to the truth and merged (NaN wins);
    post-processors then act on the merged result, always in the order G13, G12.
    Each step gets its own seed (seed + 1000 * position) unless params carry a seed.
    """
    items = []
    for i, entry in enumerate(spec):
        if isinstance(entry, dict):
            entry = dict(entry)
            code = entry.pop("code")
            params = entry
        else:
            code, params = entry
            params = dict(params)
        if code not in MECHANISMS:
            raise KeyError(f"unknown gap code {code}")
        params.setdefault("seed", seed + 1000 * i)
        items.append((code, params))
    primaries = [PRIMARY[c](truth, **p) for c, p in items if c in PRIMARY]
    res = combine(truth, *primaries) if primaries else new_result(truth)
    for code in POST:
        for c, p in items:
            if c == code:
                res = POST[code](res, **p)
    return res


def describe() -> pd.DataFrame:
    """Table of codes, names and whether the generator needs a finished result (post)."""
    return pd.DataFrame(
        [{"code": k, "name": v, "post": k in POST} for k, v in NAMES.items()]
    )
