"""Named test cases: one synthetic variable plus a gap recipe, with the truth known.

Each case is a dict:
    id, variable (key of build_basin), columns (None = all), spec (for simulate), note.
`build_cases(basin, seed)` applies the recipes; `write_cases(folder, basin)` saves them as
folders with truth.csv, observed.csv, kind.csv, runs.csv, case.json.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .mechanisms import NAMES, simulate

CASES = [
    dict(id="c01_rain_isolated_points", variable="rainfall", columns=None, spec=[("G1", {"frac": 0.05})], note="MCAR single days"),
    dict(id="c02_rain_short_runs", variable="rainfall", columns=None, spec=[("G2", {"frac": 0.06, "mean_len": 3})], note="runs of a few days"),
    dict(id="c03_rain_long_blocks", variable="rainfall", columns=None, spec=[("G3", {"lengths": [60, 150]})], note="two long blocks per station"),
    dict(id="c04_rain_seasonal_window", variable="rainfall", columns=None, spec=[("G4", {"start_doy": 152, "width_days": 90, "frac_years": 0.6})], note="monsoon season missing in 6 of 10 years"),
    dict(id="c05_rain_leading_trailing", variable="rainfall", columns=None, spec=[("G5", {"lead_frac": 0.12, "trail_frac": 0.08})], note="record starts late and ends early"),
    dict(id="c06_rain_monotone_dropout", variable="rainfall", columns=None, spec=[("G6", {"n_drop": 3})], note="three stations stop at different times"),
    dict(id="c07_rain_network_outage", variable="rainfall", columns=None, spec=[("G7", {"length": 30, "n_events": 3, "share_hit": 0.8})], note="telemetry failure, same dates in most stations"),
    dict(id="c08_rain_isolated_station", variable="rainfall", columns=None, spec=[("G8", {"frac": 0.25, "mean_len": 45})], note="only the most isolated station has gaps"),
    dict(id="c09_rain_thin_overlap", variable="rainfall", columns=["R01", "R02"], spec=[("G9", {"tail_frac": 0.4, "overlap_len": 45})], note="a replacement gauge overlaps the old one by 45 days; only one neighbour station exists"),
    dict(id="c10_flow_extreme_linked", variable="streamflow", columns=None, spec=[("G10", {"frac": 0.06, "strength": 4.0, "dilate": 2})], note="gauge fails during floods"),
    dict(id="c11_flow_clipped_stuck", variable="streamflow", columns=None, spec=[("G11", {"ceil_q": 0.97, "stuck_runs": 4, "stuck_len": 12})], note="sensor ceiling and stuck readings"),
    dict(id="c12_rain_sentinel_codes", variable="rainfall", columns=None, spec=[("G2", {"frac": 0.05}), ("G12", {"codes": [-999.0], "share": 0.7, "zero_share": 0.3})], note="gaps written as -999 or 0"),
    dict(id="c13_rain_accumulated", variable="rainfall", columns=None, spec=[("G2", {"frac": 0.06, "mean_len": 3}), ("G13", {"share": 0.8})], note="reading after a gap holds the total"),
    dict(id="c14_flow_qc_removed", variable="streamflow", columns=None, spec=[("G14", {"upper_q": 0.99, "dilate": 1})], note="QC deleted the highest flows"),
    dict(id="c15_sediment_monthly", variable="sediment", columns=["concentration_mgl", "discharge_m3s"], spec=[("G15", {"schedule": "monthly", "columns": ["concentration_mgl"]})], note="monthly grab samples, discharge complete"),
    dict(id="c16_sediment_storm_biased", variable="sediment", columns=["concentration_mgl", "discharge_m3s"], spec=[("G15", {"schedule": "storm_biased", "n_per_year": 30, "strength": 2.5, "columns": ["concentration_mgl"]})], note="sampling favours high flow"),
    dict(id="c17_temp_short_long", variable="temperature", columns=None, spec=[("G2", {"frac": 0.03}), ("G3", {"lengths": [45, 100]})], note="short runs and two long blocks"),
    dict(id="c18_tide_short_long", variable="tide", columns=["level_m"], spec=[("G2", {"frac": 0.03, "mean_len": 6}), ("G3", {"lengths": [24 * 10, 24 * 40]})], note="hourly gauge: short runs, a 10-day and a 40-day block"),
    dict(id="c19_tide_surge_missing", variable="tide", columns=["level_m"], spec=[("G10", {"frac": 0.03, "strength": 5.0, "dilate": 6})], note="gauge fails near the highest levels (surges)"),
    dict(id="c20_groundwater_blocks", variable="groundwater", columns=["head_m"], spec=[("G3", {"lengths": [60, 180]}), ("G15", {"schedule": "weekly", "columns": ["head_m"]})], note="logger blocks over weekly manual readings"),
    dict(id="c21_rain_mixed_realistic", variable="rainfall", columns=None, spec=[("G2", {"frac": 0.03}), ("G3", {"lengths": [40, 90]}), ("G4", {"start_doy": 100, "width_days": 40, "frac_years": 0.3}), ("G13", {"share": 0.6}), ("G12", {"share": 0.4, "zero_share": 0.2})], note="several problems at once"),
    dict(id="c22_flow_mixed_realistic", variable="streamflow", columns=None, spec=[("G2", {"frac": 0.02}), ("G3", {"lengths": [30, 120]}), ("G10", {"frac": 0.03})], note="short runs, long blocks and flood-linked gaps"),
]


def build_cases(basin: dict, seed: int = 0, cases=None) -> dict:
    """Apply every recipe. Returns {case id: (GapResult, case dict)}."""
    out = {}
    for i, case in enumerate(cases or CASES):
        truth = basin[case["variable"]].truth
        if case["columns"] is not None:
            truth = truth[list(case["columns"])]
        res = simulate(truth, case["spec"], seed=seed + 100 * i)
        out[case["id"]] = (res, case)
    return out


def _jsonable(obj):
    if isinstance(obj, (pd.Timestamp,)):
        return str(obj)
    if hasattr(obj, "item"):
        try:
            return obj.item()
        except Exception:
            pass
    return str(obj)


def write_cases(folder, basin: dict, seed: int = 0, cases=None) -> pd.DataFrame:
    """Write each case to <folder>/<id>/. Returns a summary table (also saved as summary.csv)."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    rows = []
    for cid, (res, case) in build_cases(basin, seed, cases).items():
        d = folder / cid
        d.mkdir(parents=True, exist_ok=True)
        res.truth.to_csv(d / "truth.csv", index_label="time")
        res.observed.to_csv(d / "observed.csv", index_label="time")
        res.kind().to_csv(d / "kind.csv", index_label="time")
        res.runs().to_csv(d / "runs.csv", index=False)
        info = {
            "id": cid,
            "variable": case["variable"],
            "note": case["note"],
            "spec": [[c, p] for c, p in case["spec"]],
            "codes": sorted(res.layers, key=lambda c: int(c[1:])),
            "code_names": {c: NAMES[c] for c in res.layers},
            "missing_fraction": res.missing_fraction().round(5).to_dict(),
            "flagged_fraction": res.mask.mean().round(5).to_dict(),
            "meta": res.meta,
        }
        (d / "case.json").write_text(json.dumps(info, indent=2, default=_jsonable), encoding="utf-8")
        rows.append(
            {
                "id": cid,
                "variable": case["variable"],
                "codes": "+".join(info["codes"]),
                "n_rows": len(res.truth),
                "n_cols": res.truth.shape[1],
                "missing_pct": round(100 * float(res.missing.to_numpy().mean()), 2),
                "flagged_pct": round(100 * float(res.mask.to_numpy().mean()), 2),
                "note": case["note"],
            }
        )
    summary = pd.DataFrame(rows)
    summary.to_csv(folder / "summary.csv", index=False)
    return summary
