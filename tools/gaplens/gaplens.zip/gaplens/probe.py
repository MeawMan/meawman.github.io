"""Run each method once in its own process with a time limit.

Used to find methods that fail or hang on a given machine or data set (statsmodels, numba, xgboost ...) before a long comparison,
and by the web app so that a slow method cannot freeze the page.
"""

from __future__ import annotations

import multiprocessing as mp
import time
import warnings

import numpy as np
import pandas as pd

from .compare import make_holdout
from .methods import REGISTRY, Ctx


def _worker(q, mid, series, others, ctx, hidden, truth, params):
    try:
        warnings.simplefilter("ignore")
        from .methods import REGISTRY as R

        t0 = time.time()
        fo = R[mid].run(series.where(~hidden), others, ctx, **params)
        h = hidden.to_numpy(bool)
        est = fo.values.to_numpy(float)[h]
        obs = truth.to_numpy(float)[h]
        ok = np.isfinite(est) & np.isfinite(obs)
        rmse = float(np.sqrt(np.mean((est[ok] - obs[ok]) ** 2))) if ok.any() else float("nan")
        q.put(dict(status="ok", seconds=time.time() - t0, rmse=rmse, filled=float(ok.sum() / max(h.sum(), 1)), message=""))
    except BaseException as e:  # noqa: BLE001 - report any failure to the parent
        q.put(dict(status="error", seconds=0.0, rmse=float("nan"), filled=0.0, message=f"{type(e).__name__}: {e}"[:300]))


def probe(series: pd.Series, others: pd.DataFrame | None = None, ctx: Ctx | None = None, ids=None, timeout: float = 300.0, frac: float = 0.10,
          seed: int = 0, ladder=(1, 7, 30), params: dict | None = None, isolate: bool = True) -> pd.DataFrame:
    """One masked test per method. Returns a table: method, status (ok/error/timeout/skipped), seconds, rmse, filled, message."""
    ctx = ctx or Ctx()
    params = params or {}
    hidden_arr, _ = make_holdout(series, np.random.default_rng(seed), ladder, frac, design="auto")
    hidden = pd.Series(hidden_arr, index=series.index)
    rows = []
    for mid in ids or list(REGISTRY):
        m = REGISTRY[mid]
        problems = m.check(series, others, ctx)
        if problems:
            rows.append(dict(method=mid, status="skipped", seconds=0.0, rmse=np.nan, filled=0.0, message="; ".join(problems)))
            continue
        if isolate:
            mpc = mp.get_context("spawn")
            q = mpc.Queue()
            proc = mpc.Process(target=_worker, args=(q, mid, series, others, ctx, hidden, series, params.get(mid, {})))
            proc.start()
            t0 = time.time()
            res = None
            while time.time() - t0 < timeout:
                try:
                    res = q.get(timeout=1.0)
                    break
                except Exception:
                    if not proc.is_alive():
                        try:
                            res = q.get(timeout=1.0)
                        except Exception:
                            res = dict(status="error", seconds=0.0, rmse=np.nan, filled=0.0, message="process ended without a result")
                        break
            if res is None:
                res = dict(status="timeout", seconds=float(timeout), rmse=np.nan, filled=0.0, message=f"stopped after {timeout:.0f} s")
            proc.join(5)
            if proc.is_alive():
                proc.terminate()
                proc.join(5)
        else:
            import queue as _q

            q = _q.Queue()
            _worker(q, mid, series, others, ctx, hidden, series, params.get(mid, {}))
            res = q.get()
        rows.append(dict(method=mid, **res))
    return pd.DataFrame(rows)
