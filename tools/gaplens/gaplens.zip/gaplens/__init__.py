"""gaplens: gap profiling, filling and comparison for hydroclimate time series."""

__version__ = "0.0.1"
